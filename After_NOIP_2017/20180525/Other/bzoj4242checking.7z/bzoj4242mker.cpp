#include<bits/stdc++.h>
using namespace std;
const int maxn=2e3+1e2;

char mp[maxn][maxn];

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int h = 2000 , w = 1000 , n = 200000 , m = 200000;
    printf("%d %d %d %d\n",h,w,n,m);
    for(int i=1;i<=h;i++) {
        for(int j=1;j<=w;j++) putchar(mp[i][j]=(_(4)==1?'#':'.'));
        puts("");
    }
    for(int i=1,x,y;i<=n;i++) {
        x = _(h) , y = _(w);
        while( mp[x][y] == '#' ) x = _(h) , y = _(w);
        printf("%d %d\n",x,y) , mp[x][y] = '#';
    }
    for(int i=1;i<=m;i++) printf("%d %d\n",_(n),_(n));
    return 0;
}