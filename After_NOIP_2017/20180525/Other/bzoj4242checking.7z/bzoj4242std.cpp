#include <cstdio>
#include <algorithm>
#define K 2010
#define N 200010
using namespace std;
int first[K * K] , px[K * K * 2] , py[K * K * 2] , last[K * K * 2] , tot;
int mp[K][K] , vis[K][K] , dis[K][K] , f[N] , qx[K * K] , qy[K * K] , l = 1 , r , head[N] , to[N << 1] , len[N << 1] , nxt[N << 1] , cnt , fa[19][N] , val[19][N] , deep[N] , log[N];
char str[K];
struct data
{
    int x , y;
    data() {}
    data(int x0 , int y0) {x = x0 , y = y0;}
}tmp[5];
bool cmp(data a , data b)
{
    return mp[a.x][a.y] && mp[b.x][b.y] ? vis[a.x][a.y] && vis[b.x][b.y] ? dis[a.x][a.y] < dis[b.x][b.y] : vis[a.x][a.y] : mp[a.x][a.y];
}
int find(int x)
{
    return x == f[x] ? x : f[x] = find(f[x]);
}
void add(int x , int y , int z)
{
    to[++cnt] = y , len[cnt] = z , nxt[cnt] = head[x] , head[x] = cnt;
    to[++cnt] = x , len[cnt] = z , nxt[cnt] = head[y] , head[y] = cnt;
}
void ins(int t , int x , int y)
{
    px[++tot] = x , py[tot] = y , last[tot] = first[t] , first[t] = tot;
}
void drive(int x1 , int y1 , int x2 , int y2)
{
    if(!mp[x2][y2]) return;
    if(!vis[x2][y2]) vis[x2][y2] = vis[x1][y1] , dis[x2][y2] = dis[x1][y1] + 1 , qx[++r] = x2 , qy[r] = y2;
    else if(vis[x1][y1] != vis[x2][y2]) ins(dis[x1][y1] + dis[x2][y2] , vis[x1][y1] , vis[x2][y2]);
}
void dfs(int x)
{
    int i;
    for(i = 1 ; i <= log[deep[x]] ; i ++ )
        fa[i][x] = fa[i - 1][fa[i - 1][x]] , val[i][x] = max(val[i - 1][x] , val[i - 1][fa[i - 1][x]]);
    for(i = head[x] ; i ; i = nxt[i])
        if(to[i] != fa[0][x])
            fa[0][to[i]] = x , val[0][to[i]] = len[i] , deep[to[i]] = deep[x] + 1 , dfs(to[i]);
}
int query(int x , int y)
{
    if(find(x) != find(y)) return -1;
    int i , ans = 0;
    if(deep[x] < deep[y]) swap(x , y);
    for(i = log[deep[x] - deep[y]] ; ~i ; i -- )
        if(deep[x] - deep[y] >= (1 << i))
            ans = max(ans , val[i][x]) , x = fa[i][x];
    for(i = log[deep[x]] ; ~i ; i -- )
        if(deep[x] >= (1 << i) && fa[i][x] != fa[i][y])
            ans = max(ans , max(val[i][x] , val[i][y])) , x = fa[i][x] , y = fa[i][y];
    if(x != y) ans = max(ans , max(val[0][x] , val[0][y]));
    return ans;
}
int main()
{
    int h , w , n , m , i , j , x , y;
    scanf("%d%d%d%d" , &h , &w , &n , &m);
    for(i = 1 ; i <= h ; i ++ )
    {
        scanf("%s" , str + 1);
        for(j = 1 ; j <= w ; j ++ ) mp[i][j] = (str[j] == '.');
    }
    for(i = 1 ; i <= n ; i ++ )
        scanf("%d%d" , &qx[i] , &qy[i]) , vis[qx[i]][qy[i]] = f[i] = i , dis[qx[i]][qy[i]] = 0;
    for(r = n ; l <= r ; l ++ )
        x = qx[l] , y = qy[l] , drive(x , y , x + 1 , y) , drive(x , y , x - 1 , y) , drive(x , y , x , y + 1) , drive(x , y , x , y - 1);
    for(i = 0 ; i <= h * w ; i ++ )
    {
        for(j = first[i] ; j ; j = last[j])
        {
            x = px[j] , y = py[j];
            if(find(x) != find(y)) f[f[x]] = f[y] , add(x , y , i);
        }
    }
    for(i = 2 ; i <= n ; i ++ ) log[i] = log[i >> 1] + 1;
    for(i = 1 ; i <= n ; i ++ ) if(!fa[0][i]) dfs(i);
    while(m -- ) scanf("%d%d" , &x , &y) , printf("%d\n" , query(x , y));
    return 0;
}