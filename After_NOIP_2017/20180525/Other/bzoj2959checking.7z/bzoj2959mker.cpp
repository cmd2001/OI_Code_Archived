#include<bits/stdc++.h>
using namespace std;
const int maxn=1.5e5+1e2;

inline int _(int r=1e4) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1.5e5 , m = n * 5;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1,o;i<=m;i++) {
        o = _(3);
        if( o == 2 ) printf("%d %d %d\n",o,_(n),_());
        else printf("%d %d %d\n",o,_(n),_(n));
    }
    return 0;
}
