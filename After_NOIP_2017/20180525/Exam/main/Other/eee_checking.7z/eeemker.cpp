#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 4e3 , m = 4e3;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) {
        int o = _(11); if( o > 6 ) o = 1;
        if( o == 1 ) printf("1 %d\n",_(n));
        else {
            int l = _(n) , r = _(n);
            if( l > r ) swap(l,r);
            if( o < 4 ) printf("%d %d %d %d\n",o,l,r,_());
            else printf("%d %d %d\n",o,l,r);
        }
    }
    return 0;
}