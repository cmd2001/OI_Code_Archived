#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<tr1/unordered_set>
#define debug cerr
typedef long long int lli;
using namespace std;

int n,m;

namespace SubTask1 {
    const int maxn=5e3+1e2;
    const lli inf=0x3f3f3f3f3f3f3f3fll;
    lli in[maxn];
    tr1::unordered_set<lli> ban;
    
    inline void initban() {
        lli cur = 23;
        for(int i=1;i<=17;i++) cur = cur * 10 + 3 , ban.insert(cur);
    }
    inline void apply_add(int l,int r,const lli &x) {
        for(int i=l;i<=r;i++) in[i] += x;
    }
    inline void apply_fil(int l,int r,const lli &x) {
        for(int i=l;i<=r;i++) in[i] = x;
    }
    inline lli query_sum(int l,int r) {
        lli ret = 0;
        for(int i=l;i<=r;i++) ret += in[i];
        return ret;
    }
    inline lli query_mi(int l,int r) {
        lli ret = inf;
        for(int i=l;i<=r;i++) ret = min( ret , in[i] );
        return ret;
    }
    inline lli query_mx(int l,int r) {
        lli ret = -inf;
        for(int i=l;i<=r;i++) ret = max( ret , in[i] );
        return ret;
    }
    inline bool judge_ban(int l,int r) {
        for(int i=l;i<=r;i++) if( ban.find(in[i]) != ban.end() ) return 1;
        return 0;
    }
    void main() {
        for(int i=1;i<=n;i++) scanf("%lld",in+i);
        for(int i=1,o,l,r,x;i<=m;i++) {
            scanf("%d",&o);
            if( o == 1 ) scanf("%d",&x) , printf("%lld\n",query_sum(x,x));
            else {
                scanf("%d%d",&l,&r);
                if( o == 2 || o == 3 ) {
                    scanf("%d",&x);
                    if( o == 2 ) apply_fil(l,r,x);
                    else if( o == 3 ) apply_add(l,r,x);
                } else {
                    lli val;
                    if( o == 4 ) val = query_mi(l,r);
                    else if( o == 5 ) val = query_mx(l,r);
                    else if( o == 6 ) val = query_sum(l,r) / ( r - l + 1 );
                    apply_fil(l,r,val);
                }
                if( o == 2 || o == 3 || o == 6 ) while( judge_ban(l,r) ) apply_add(l,r,1);
            }
        }
    }
}


int main() {
    scanf("%d%d",&n,&m);
    SubTask1::main();
    return 0;
}
