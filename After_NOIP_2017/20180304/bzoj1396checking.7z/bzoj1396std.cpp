#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;
#define MAXN 100010
#define INF 0x7fffffff
char S[MAXN];
int N;
namespace SegmentTree{
#define lson now<<1
#define rson now<<1|1
    struct SgtNode{
        int l,r,minn,tag;
    };
    struct SegmentTree{
        SgtNode tree[MAXN<<2];
        inline void Update(int now) {tree[now].minn=min(tree[lson].minn,tree[rson].minn);}
        inline void Build(int now,int l,int r)
        {
            tree[now].tag=tree[now].minn=INF;
            tree[now].l=l,tree[now].r=r;
            if (l==r) return;
            int mid=(l+r)>>1;
            Build(lson,l,mid); Build(rson,mid+1,r);
        }
        inline void Pushdown(int now)
        {
            if (tree[now].l==tree[now].r || tree[now].tag==INF) return;
            int val=tree[now].tag;
            tree[now].tag=INF;
            tree[lson].minn=min(tree[lson].minn,val);
            tree[rson].minn=min(tree[rson].minn,val);
            tree[lson].tag=min(tree[lson].tag,val);
            tree[rson].tag=min(tree[rson].tag,val);
        }
        inline void Modify(int now,int L,int R,int val)
        {
            if (L>R) return;
            int l=tree[now].l,r=tree[now].r;
            Pushdown(now);
            if (L<=l && R>=r) {
                tree[now].tag=min(tree[now].tag,val);
                tree[now].minn=min(tree[now].minn,val);
                return;
            }
            int mid=(l+r)>>1;
            if (L<=mid) Modify(lson,L,R,val);
            if (R>mid) Modify(rson,L,R,val);
            Update(now);
        }
        inline int Query(int now,int pos)
        {
            int l=tree[now].l,r=tree[now].r;
            Pushdown(now);
            if (l==r) return tree[now].minn;
            int mid=(l+r)>>1;
            if (pos<=mid) return Query(lson,pos);
                else return Query(rson,pos);
        }
    }t1,t2;
}using namespace SegmentTree;
  
namespace SAM{
    int son[MAXN<<1][27],len[MAXN<<1],par[MAXN<<1],endpos[MAXN<<1],size[MAXN<<1];
    int last,root,sz;
    inline void init() {last=root=++sz;}
    inline void Extend(int c,int pos)
    {
        int cur=++sz,p=last;
        len[cur]=len[p]+1; endpos[cur]=pos; size[cur]=1;
        while (p && !son[p][c]) son[p][c]=cur,p=par[p];
        if (!p) par[cur]=root;
        else {
            int q=son[p][c];
            if (len[p]+1==len[q]) par[cur]=q;
            else {
                int nq=++sz;
                memcpy(son[nq],son[q],sizeof(son[nq]));
                len[nq]=len[p]+1; par[nq]=par[q];
                while (p && son[p][c]==q) son[p][c]=nq,p=par[p];
                par[q]=par[cur]=nq;    
            }
        }
        last=cur;
    }
    inline void Build() {init(); for (int i=1; i<=N; i++) Extend(S[i]-'a'+1,i);}
    int st[MAXN],id[MAXN<<1];
    inline void Prework()
    {
        for (int i=1; i<=sz; i++) st[len[i]]++;
        for (int i=1; i<=N; i++) st[i]+=st[i-1];
        for (int i=1; i<=sz; i++) id[st[len[i]]--]=i;
        for (int i=sz; i>=1; i--) {
            int x=id[i];
            size[par[x]]+=size[x];
            endpos[par[x]]=max(endpos[par[x]],endpos[x]);
        }
    }
    inline void Work()
    {
        for (int i=1; i<=sz; i++)
            if (size[i]==1) {
                int maxlen=len[i],minlen=len[par[i]]+1,end=endpos[i];
//              printf("%d  %d  %d\n",end,maxlen,minlen);
                t1.Modify(1,end-maxlen+1,end-minlen+1,end+1);
                t2.Modify(1,end-minlen+1,end,minlen);
            }
              
        for (int i=1; i<=N; i++) {
            int x=t1.Query(1,i)-i,y=t2.Query(1,i);
            printf("%d\n",min(x,y));
        }
    }
}using namespace SAM;
int main()
{
    scanf("%s",S+1); N=strlen(S+1);
      
    t1.Build(1,1,N),t2.Build(1,1,N);
      
    SAM::Build();
    SAM::Prework();
    SAM::Work();
      
    return 0;
}
