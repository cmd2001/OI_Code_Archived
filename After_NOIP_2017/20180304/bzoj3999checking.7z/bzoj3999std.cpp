#include<iostream>
#include<cstdlib>
#include<cstdio>
#include<cstring>
#include<ctime>
#include<cmath>
#include<algorithm>
#include<iomanip>
#include<queue>
#include<map>
#include<bitset>
#include<stack>
#include<vector>
#include<set>
using namespace std;
#define MAXN 50010
#define MAXM 1010
#define INF 1000000000
#define MOD 1000000007
#define ll long long
#define eps 1e-8
struct vec{
	int to;
	int fro;
};
struct data{
	int mx;
	int mn;
	int ans;
	data(){
		
	}
	data(int x){
		mn=mx=x;
		ans=0;
	}
	friend data operator +(data x,data y){
		data z;
		z.mx=max(x.mx,y.mx);
		z.mn=min(x.mn,y.mn);
		z.ans=max(max(x.ans,y.ans),y.mx-x.mn);
		return z;
	}
	friend data operator +(data x,int y){
		x.mx+=y;
		x.mn+=y;
		return x;
	}
};
vec mp[MAXN*2];
int tai[MAXN],cnt;
int n,m;
int a[MAXN];
int fa[MAXN],son[MAXN],siz[MAXN],dep[MAXN],tp[MAXN],dfn[MAXN],ndf[MAXN],tim;
data vl[MAXN<<2],vr[MAXN<<2];
int ch[MAXN<<2];
inline void be(int x,int y){
	mp[++cnt].to=y;
	mp[cnt].fro=tai[x];
	tai[x]=cnt;
}
inline void bde(int x,int y){
	be(x,y);
	be(y,x);
}
void dfs(int x){
	int i,y;
	siz[x]=1;
	dep[x]=dep[fa[x]]+1;
	for(i=tai[x];i;i=mp[i].fro){
		y=mp[i].to;
		if(!siz[y]){
			fa[y]=x;
			dfs(y);
			siz[x]+=siz[y];
			if(siz[y]>siz[son[x]]){
				son[x]=y;
			}
		}
	}
}
void dfs2(int x,int z){
	int i,y;
	ndf[dfn[x]=++tim]=x;
	tp[x]=z;
	if(son[x]){
		dfs2(son[x],z);
		for(i=tai[x];i;i=mp[i].fro){
			y=mp[i].to;
			if(!dfn[y]){
				dfs2(y,y);
			}
		}
	}
}
inline void ud(int x){
	vl[x]=vl[x<<1]+vl[x<<1|1];
	vr[x]=vr[x<<1|1]+vr[x<<1];
}
inline void toch(int x,int y){
	vl[x]=vl[x]+y;
	vr[x]=vr[x]+y;
	ch[x]+=y;
}
inline void pd(int x){
	if(ch[x]){
		toch(x<<1,ch[x]);
		toch(x<<1|1,ch[x]);
		ch[x]=0;
	}
}
void build(int x,int y,int z){
	if(y==z){
		vl[x]=vr[x]=data(a[ndf[y]]);
		return ;
	}
	int mid=y+z>>1;
	build(x<<1,y,mid);
	build(x<<1|1,mid+1,z);
	ud(x);
}
data ask(int x,int y,int z,int l,int r,int f){
	if(y==l&&z==r){
		return f?vr[x]:vl[x];
	}
	pd(x);
	int mid=y+z>>1;
	if(r<=mid){
		return ask(x<<1,y,mid,l,r,f);
	}else if(l>mid){
		return ask(x<<1|1,mid+1,z,l,r,f);
	}else{
		return f?ask(x<<1|1,mid+1,z,mid+1,r,f)+ask(x<<1,y,mid,l,mid,f):ask(x<<1,y,mid,l,mid,f)+ask(x<<1|1,mid+1,z,mid+1,r,f);
	}
}
void change(int x,int y,int z,int l,int r,int cv){
	if(y==l&&z==r){
		toch(x,cv);
		return ;
	}
	pd(x);
	int mid=y+z>>1;
	if(r<=mid){
		change(x<<1,y,mid,l,r,cv);
	}else if(l>mid){
		change(x<<1|1,mid+1,z,l,r,cv);
	}else{
		change(x<<1,y,mid,l,mid,cv);
		change(x<<1|1,mid+1,z,mid+1,r,cv);
	}
	ud(x);
}
data toask(int x,int y,int z){
	data rex(INF),rey(-INF),re;
	while(tp[x]!=tp[y]){
		if(dep[tp[x]]>=dep[tp[y]]){
			rex=rex+ask(1,1,n,dfn[tp[x]],dfn[x],1);
			change(1,1,n,dfn[tp[x]],dfn[x],z);
			x=fa[tp[x]];
		}else{
			rey=ask(1,1,n,dfn[tp[y]],dfn[y],0)+rey;
			change(1,1,n,dfn[tp[y]],dfn[y],z);
			y=fa[tp[y]];
		}
	}
	if(dep[x]>dep[y]){
		re=rex+ask(1,1,n,dfn[y],dfn[x],1)+rey;
		change(1,1,n,dfn[y],dfn[x],z);
	}else{
		re=rex+ask(1,1,n,dfn[x],dfn[y],0)+rey;
		change(1,1,n,dfn[x],dfn[y],z);
	}
	return re;
}
int main(){
	int i,x,y,z;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(i=1;i<n;i++){
		scanf("%d%d",&x,&y);
		bde(x,y);
	}
	dfs(1);
	dfs2(1,1);
	build(1,1,n);
	scanf("%d",&m);
	while(m--){
		scanf("%d%d%d",&x,&y,&z);
		printf("%d\n",toask(x,y,z).ans);
	}
	return 0;
}

/*
3
1 2 3
1 2
2 3
2
1 2 100
1 3 100
*/

