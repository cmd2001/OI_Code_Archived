#include<bits/stdc++.h>
using namespace std;

inline int _(int r=100000) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 5e4 , m = 5e4;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",_(100),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",_(i-1),i);
    printf("%d\n",m);
    while( m-- )
        printf("%d %d %d\n",_(n),_(n),_());
    return 0;
}
