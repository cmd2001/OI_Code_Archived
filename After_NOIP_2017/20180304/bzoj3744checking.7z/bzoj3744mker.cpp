#include<bits/stdc++.h>
using namespace std;

inline int _(int r = 10000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 50000 , m = 10;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    printf("%d\n",m);
    while(m--) {
        int x = _(n) , y = _(n);
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
