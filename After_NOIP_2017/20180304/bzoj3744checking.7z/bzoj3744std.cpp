#include <cmath>  
#include <cstdio>  
#include <cstring>  
#include <iostream>  
#include <algorithm>  
#define M 50500  
using namespace std;  
struct abcd{  
    abcd *ls,*rs;  
    int num;  
    void* operator new (size_t size,abcd *_,abcd *__,int ___);  
}*tree[M],mempool[1001001],*C=mempool;  
int n,m,tot,block,ans;  
int a[M],l[M],r[M],belong[M];  
int cnt[250][M];  
pair<int,int>b[M];  
int c[M],tim[M],T;  
void Update(int x)  
{  
    for(;x;x-=x&-x)  
    {  
        if(tim[x]!=T)  
            tim[x]=T,c[x]=0;  
        c[x]++;  
    }  
}  
int Get_Ans(int x)  
{  
    int re=0;  
    for(;x<=tot;x+=x&-x)  
        if(tim[x]==T)  
            re+=c[x];  
    return re;  
}  
void* abcd :: operator new (size_t size,abcd *_,abcd *__,int ___)  
{  
    C->ls=_;  
    C->rs=__;  
    C->num=___;  
    return C++;  
}  
abcd* Build_Tree(abcd *p,int x,int y,int val)  
{  
    int mid=x+y>>1;  
    if(x==y) return new (0x0,0x0,p->num+1)abcd;  
    if(val<=mid) return new (Build_Tree(p->ls,x,mid,val),p->rs,p->num+1)abcd;  
    else return new (p->ls,Build_Tree(p->rs,mid+1,y,val),p->num+1)abcd;  
}  
int Get_Ans(abcd *p1,abcd *p2,int x,int y,int l,int r)  
{  
    int mid=x+y>>1;  
    if(p1->num==p2->num)  
        return 0;  
    if(x==l&&y==r)  
        return p2->num-p1->num;  
    if(r<=mid) return Get_Ans(p1->ls,p2->ls,x,mid,l,r);  
    if(l>mid) return Get_Ans(p1->rs,p2->rs,mid+1,y,l,r);  
    return Get_Ans(p1->ls,p2->ls,x,mid,l,mid) + Get_Ans(p1->rs,p2->rs,mid+1,y,mid+1,r);  
}  
inline int Query(int x,int y)  
{  
    int i,re=0;  
    if(belong[x]==belong[y])  
    {  
        ++T;  
        for(i=x;i<=y;i++)  
            re+=Get_Ans(a[i]+1),Update(a[i]);  
        return re;  
    }  
    re+=cnt[belong[x]+1][y];      
    for(i=x;i<l[belong[x]+1];i++)  
        re+=Get_Ans(tree[i],tree[y],0,tot+1,0,a[i]-1);  
    return re;  
}  
int main()  
{  
      
    //freopen("3744.in","r",stdin);  
    //freopen("3744.out","w",stdout);  
    int i,j,k,x,y;  
    cin>>n;  
    for(i=1;i<=n;i++)  
        scanf("%d",&b[i].first),b[i].second=i;  
    sort(b+1,b+n+1);  
    for(i=1;i<=n;i++)  
    {  
        if(i==1||b[i].first!=b[i-1].first)  
            ++tot;  
        a[b[i].second]=tot;  
    }  
    tree[0]=new (0x0,0x0,0)abcd;  
    tree[0]->ls=tree[0]->rs=tree[0];  
    for(i=1;i<=n;i++)  
        tree[i]=Build_Tree(tree[i-1],0,tot+1,a[i]);  
    block=static_cast<int>(sqrt(n)+1e-7);  
    for(i=1;i<=n;i++)  
        belong[i]=(i-1)/block+1;  
    for(i=1;(i-1)*block+1<=n;i++)  
        l[i]=(i-1)*block+1,r[i]=min(i*block,n);  
    for(i=1;(i-1)*block+1<=n;i++)  
    {  
        ++T;  
        for(j=(i-1)*block+1;j<=n;j++)  
        {  
            cnt[i][j]=cnt[i][j-1]+Get_Ans(a[j]+1);  
            Update(a[j]);  
        }  
    }  
    cin>>m;  
    for(i=1;i<=m;i++)  
    {  
        scanf("%d%d",&x,&y);//x^=ans;y^=ans;  
        printf("%d\n", ans=Query(x,y) );  
    }  
}  
