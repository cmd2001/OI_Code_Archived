#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 50005
#define d 223
using namespace std;
int n,m;
int c[N];
int ans[N];
struct node
{
    int l,r,id,yuan;
    friend bool operator < (node aa,node bb)
    {
        if(aa.id!=bb.id)return aa.id<bb.id;
        return aa.r<bb.r;
    }
}a[N];
int now1[N],now2[N];
int st1[N*2],st2[N*2],top;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)scanf("%d",&c[i]);
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&a[i].l,&a[i].r);
        a[i].yuan=i;a[i].id=(a[i].l-1)/d+1;
    }
    sort(a+1,a+m+1);
    int as=0;int r=0,t=0;
    for(int i=1;i<=m;i++)
    {
        if(a[i].id!=a[i-1].id)
        {
            as=0;
            memset(now1,0,sizeof(now1));
            memset(now2,0,sizeof(now2));
            r=t=a[i].id*d;
        }
        while(a[i].r>r)
        {
            r++;
            now1[c[r]]=now1[c[r]+1]+1;
            now2[c[r]]=now2[c[r]-1]+1;
            int tt=now1[c[r]]+now2[c[r]]-1;
            now2[c[r]+now1[c[r]]-1]=tt;
            now1[c[r]-now2[c[r]]+1]=tt;
            as=max(as,tt);
        }
        int tmp=as;top=0;
        for(int j=a[i].l;j<=min(a[i].r,t);j++)
        {
            now1[c[j]]=now1[c[j]+1]+1;
            now2[c[j]]=now2[c[j]-1]+1;
            int tt=now1[c[j]]+now2[c[j]]-1;
            int rr=c[j]+now1[c[j]]-1;int ll=c[j]-now2[c[j]]+1;
            st1[++top]=rr;st2[top]=now2[rr];
            st1[++top]=ll;st2[top]=now1[ll];
            now2[rr]=tt;
            now1[ll]=tt;
            tmp=max(tmp,tt);
        }
        for(int j=top;j>=1;j--)
        {
            if(j%2==0)now1[st1[j]]=st2[j];
            else now2[st1[j]]=st2[j];
        }
        for(int j=a[i].l;j<=min(a[i].r,t);j++)
        {
            now1[c[j]]=now2[c[j]]=0;
        }
        ans[a[i].yuan]=tmp;
    }
    for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
    return 0;
}
