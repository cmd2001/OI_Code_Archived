#include<bits/stdc++.h>
using namespace std;
const int maxn=5e4+1e2;

int in[maxn];

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5e4 , m = 5e4;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) in[i] = i;
    random_shuffle(in+1,in+1+n);
    for(int i=1;i<=n;i++) printf("%d%c",in[i],i!=n?' ':'\n');
    while(m--) {
        int x = _(n) , y = _(n);
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
