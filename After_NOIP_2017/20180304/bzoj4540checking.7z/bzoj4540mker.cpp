#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli __() {
    return ((lli)rand()<<31) + ((lli)rand()<<15) + rand();
}
inline int _(int r=1000000000) {
    return __() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 3;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",((rand()&1)?-1:1)*_(),i!=n?' ':'\n');
    for(int i=1,x,y;i<=m;i++) {
        x = _(n) , y = _(n);
        if( x > y ) x ^= y ^= x ^= y;
        printf("%d %d\n",x,y);
    }
    return 0;
}
