#include<bits/stdc++.h>
using namespace std;

inline int _() {
    return !( rand() & 63 );
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 100;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) putchar(_()?'#':'.');
        puts("");
    }
}
