#include <bits/stdc++.h>
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define per(i,a,b) for(int i=a;i>=b;i--)
#define stop(x) return puts(x) , 0

inline int rd() {
    char c = getchar();
    while (!isdigit(c)) c = getchar() ; int x = c - '0';
    while (isdigit(c = getchar())) x = x * 10 + c - '0';
    return x;
}

int gcd(int a , int b) { return b ? gcd(b , a % b) : a ; }

bool check(int p , int q , int n) {
    n %= p;
    return n < q && n % (p - q) == 0;
}

int p , q , n;

int solve() {
    p = rd() , q = rd() , n = rd();
    int g = gcd(p , q);
    if (n % g)
        stop("R");
    p /= g , q /= g , n /= g;
    if (p == q)
        stop("E"); // status 0
    if (p > n) {
        if (p > q)
            stop("P"); // status 1
        else if (q > p) { // status 4
            if (n + p < q)
                stop("E"); //4 - section 2
            else
                stop(check(q , p , n + p) ? "P" : "E"); //4 - section 1
        }
    } else {
        if (p > q)
            stop(check(p , q , n) ? "E" : "P"); // status 2
        else
            stop("E"); // status 3
    }
}

int main() {
    int T = rd();
    while (T --)
        solve();
    return 0;
}
