#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli __() {
    return ( (lli) rand() << 15)+ rand();
}
inline int _() {
    return __() % 1000000000;
}

int main() {
    srand((unsigned long long)new char);
    static int T = 100000;
    printf("%d\n",T);
    while(T--) printf("%d %d %d\n",_(),_(),_());
    return 0;
}
