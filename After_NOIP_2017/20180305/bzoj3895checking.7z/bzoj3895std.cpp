#include <bits/stdc++.h>
#define rep(i,a,b) for(int i=a;i<=b;i++)
#define per(i,a,b) for(int i=a;i>=b;i--)

inline int rd() {
    char c = getchar();
    while (!isdigit(c)) c = getchar() ; int x = c - '0';
    while (isdigit(c = getchar())) x = x * 10 + c - '0';
    return x;
}

int n , a[53] , v[53][50061];

void input() {
    n = rd();
    rep (i , 1 , n) a[i] = rd();
}

#define ret return v[t1][t2] = 1

bool dfs(int t1 , int t2) {
    if (!t1) return t2 & 1;
    if (t2 == 1) return dfs(t1 + 1 , 0);
    if (v[t1][t2] != -1) return v[t1][t2];
    if (t1 >= 2 && !dfs(t1 - 2 , t2 + 2 + (t2 != 0))) ret;
    if (t1 && !dfs(t1 - 1 , t2)) ret;
    if (t1 && t2 && !dfs(t1 - 1 , t2 + 1)) ret;
    if (t2 && !dfs(t1 , t2 - 1)) ret;
    return v[t1][t2] = 0;
}

#undef ret

void solve() {
    int t1 = 0 , t2 = 0;
    rep (i , 1 , n) if (a[i] == 1) t1 ++ ; else t2 += a[i] + 1;
    if (t2) t2 --;
    puts(dfs(t1 , t2) ? "YES" : "NO");
}

int main() {
    memset(v , -1 , sizeof v);
    per (T , rd() , 1) {
        input();
        solve();
    }
    return 0;
}
