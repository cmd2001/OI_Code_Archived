#include<bits/stdc++.h>
using namespace std;

inline int _() {
    return ( rand() & 1 ) ? rand() % 2 + 1 : rand() % 1000;
}

int main() {
    srand((unsigned long long)new char);
    static int T = 100;
    printf("%d\n",T);
    while(T--) {
        int n = rand() % 50 + 1;
        printf("%d\n",n);
        while(n--) printf("%d%c",_(),n?' ':'\n');
    }
    return 0;
}
