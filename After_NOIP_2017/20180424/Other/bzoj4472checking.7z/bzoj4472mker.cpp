#include<bits/stdc++.h>
using namespace std;

inline int _(int r=3) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char ^ time(0));
    static int n = 500;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d%c",_()-_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d%c",_(n)+1,i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    return 0;
}