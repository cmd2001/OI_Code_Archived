#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;

const int N=100005;

int cnt,n,val[N],lim[N],last[N],a[N],a1,f[N],g[N];
struct edge{int to,next;}e[N*2];

void addedge(int u,int v)
{
    e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;
    e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;
}

bool cmp(int a,int b)
{
    return f[a]>f[b];
}

void dfs(int x,int fa)
{
    f[x]=val[x];
    for (int i=last[x];i;i=e[i].next)
        if (e[i].to!=fa) dfs(e[i].to,x);
    a1=0;
    for (int i=last[x];i;i=e[i].next) 
        if (e[i].to!=fa) a[++a1]=e[i].to;
    sort(a+1,a+a1+1,cmp);
    int p=0;
    while (p<min(lim[x]-1,a1)&&f[a[p+1]]>=0) p++,f[x]+=f[a[p]],g[x]|=g[a[p]];
    if (p<a1&&p>0&&f[a[p]]==f[a[p+1]]||f[a[p]]==0&&p>0) g[x]=1;
}


int main()
{
    scanf("%d",&n);
    for (int i=2;i<=n;i++) scanf("%d",&val[i]);
    for (int i=2;i<=n;i++) scanf("%d",&lim[i]);
    for (int i=1;i<n;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        addedge(x,y);
    }
    lim[1]=n+1;
    dfs(1,0);
    printf("%d\n",f[1]);
    if (g[1]) printf("solution is not unique\n");
    else printf("solution is unique\n");
    return 0;
}