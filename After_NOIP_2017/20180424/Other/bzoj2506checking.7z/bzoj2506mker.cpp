#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100000 , m = 10000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1,l,r,p,k;i<=m;i++) {
        l = _(n) , r = _(n) , p = _() , k = _(p) - 1;
        printf("%d %d %d %d\n",min(l,r),max(l,r),p,k);
    }
    return 0;
}
