#include<bits/stdc++.h>
using namespace std;

inline int _(int r=100) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5 , m = 1e5;
    printf("%d %d\n",n,m);
    for(int i=2;i<=n;i++)
        printf("%d %d\n",i,_(i-1));
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    printf("%d\n",_(n));
    for(int i=1,o;i<=m;i++) {
        o = _(3);
        if( o == 1 ) printf("1 %d\n",_(n));
        else if( o == 2 ) printf("2 %d %d %d\n",_(n),_(n),_());
        else printf("3 %d\n",_(n));
    }
    return 0;
}
