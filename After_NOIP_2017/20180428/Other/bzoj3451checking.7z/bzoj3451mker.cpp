#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 30000;
    printf("%d\n",n);
    for(int i=1;i<n;i++) printf("%d %d\n",i,_(i));
    return 0;
}
