#include<iostream>  
#include<cstdio>  
#include<cstdlib>  
#include<cmath>  
#include<cstring>  
#include<algorithm>  
#define F(i,j,n) for(int i=j;i<=n;i++)  
#define D(i,j,n) for(int i=j;i>=n;i--)  
#define ll long long  
#define maxn 20000  
#define maxm 800000  
using namespace std;  
int n,m,tot,block,num;  
int a[maxn],rt[maxn],pos[maxn],id[maxm],t[maxm][2],f[400][maxn];  
inline int read()  
{  
    int x=0,f=1;char ch=getchar();  
    while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}  
    while (ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}  
    return x*f;  
}  
inline void insert(int pre,int k,int x)  
{  
    int now=rt[k]=++tot;id[tot]=k;  
    pre=rt[pre];  
    D(i,30,0)  
    {  
        int j=(x>>i)&1;  
        t[now][j^1]=t[pre][j^1];  
        t[now][j]=++tot;id[tot]=k;  
        now=t[now][j];pre=t[pre][j];  
    }  
}  
inline int query(int l,int r,int x)  
{  
    int ans=0,tmp=rt[r];  
    D(i,30,0)  
    {  
        if (id[tmp]<l) break;  
        int j=((x>>i)&1)^1;  
        if (id[t[tmp][j]]>=l) ans|=(1<<i);  
        else j^=1;  
        tmp=t[tmp][j];  
    }  
    return ans;  
}  
int main()  
{  
    n=read();m=read();  
    block=int(sqrt(n));num=n/block+(n%block!=0);  
    F(i,1,n) pos[i]=(i-1)/block+1;  
    id[0]=-1;insert(0,0,0);  
    F(i,1,n) a[i]=a[i-1]^read();  
    F(i,1,n) insert(i-1,i,a[i]);  
    F(i,1,num) F(j,(i-1)*block+1,n)  
        f[i][j]=max(f[i][j-1],query((i-1)*block+1,j,a[j]));  
    int ans=0;  
    while (m--)  
    {  
        ll l,r,x=read(),y=read();  
        l=((ll)ans+x)%n+1;r=((ll)ans+y)%n+1;  
        if (l>r) swap(l,r);  
        ans=0;l--;  
        if (pos[l]==pos[r])  
        {  
            F(i,l,r) ans=max(ans,query(l,r,a[i]));  
        }  
        else  
        {  
            ans=f[pos[l]+1][r];  
            F(i,l,pos[l]*block) ans=max(ans,query(l,r,a[i]));  
        }  
        printf("%d\n",ans);  
    }  
    return 0;  
}  
