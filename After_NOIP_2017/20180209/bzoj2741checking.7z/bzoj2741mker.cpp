#include<bits/stdc++.h>
using namespace std;

inline _(int r=12768) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = 10000 , m = 1000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    while( m-- )
        printf("%d %d\n",_(n),_(n));
    return 0;
}
