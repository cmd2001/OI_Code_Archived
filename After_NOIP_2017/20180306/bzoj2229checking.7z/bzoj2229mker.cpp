#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int T = 5;
    printf("%d\n",T);
    while(T--) {
        int n = 3 , m = 5 , t = 3;
        printf("%d %d\n",n,m);
        while(m--) {
            int x = _(n) , y = _(n);
            while( x == y ) x = _(n) , y = _(n);
            printf("%d %d %d\n",x,y,_());
        }
        printf("%d\n",t);
        while(t--) printf("%d\n",_());
    }
    return 0;
}
