    #include<cmath>  
    #include<queue>  
    #include<vector>  
    #include<cstdio>  
    #include<cstdlib>  
    #include<iostream>  
    #include<algorithm>  
    #define pb push_back  
    using namespace std;  
    const int maxn=21;  
    const int maxm=410;  
    int n,m,id[maxn][maxn],cnt=0,x,y,du[maxn];  
    double a[maxm][maxm],equ[maxm],p[maxn];  
    vector<int>nxt[maxn];  
      
    void guass(){  
        for (int i=1;i<=cnt;++i){  
            int tmp=i;  
            for (int j=i+1;j<=cnt;++j)  
                if (abs(a[j][i])>abs(a[tmp][i])) tmp=j;  
            if (tmp!=i)  
            for (int j=1;j<=cnt+1;++j) swap(a[i][j],a[tmp][j]);  
            for (int j=i+1;j<=cnt;++j){  
                double N=a[j][i]/a[i][i];  
                for (int k=i;k<=cnt+1;++k) a[j][k]-=a[i][k]*N;  
            }  
        }  
        equ[cnt]=a[cnt][cnt+1]/a[cnt][cnt];  
        for (int i=cnt-1;i>=1;--i){  
            double N=a[i][cnt+1];  
            for (int j=i+1;j<=cnt;++j) N-=a[i][j]*equ[j];  
            equ[i]=N/a[i][i];  
        }  
        for (int i=1;i<=n;++i) printf("%.6lf ",equ[id[i][i]]);  
    }  
      
    int main(){
        freopen("20180409/dat.txt","r",stdin);
        scanf("%d%d%d%d",&n,&m,&x,&y);  
        for (int i=1;i<=m;++i){  
            int u,v; scanf("%d%d",&u,&v);  
            nxt[u].pb(v); nxt[v].pb(u);  
            du[u]++; du[v]++;  
        }  
        for (int i=1;i<=n;++i) scanf("%lf",&p[i]);  
        for (int i=1;i<=n;++i)  
            for (int j=1;j<=n;++j) {id[i][j]=++cnt;if(i!=j)a[cnt][cnt]=p[i]*p[j];}  
        for (int i=1;i<=n;++i)  
            for (int j=1;j<=n;++j)  
                if (i!=j){  
                    for (int k=0;k<nxt[i].size();++k){  
                        int tx=nxt[i][k];  
                        a[id[tx][j]][id[i][j]]+=(1-p[i])/du[i]*p[j];  
                    }  
                    for (int k=0;k<nxt[j].size();++k){  
                        int ty=nxt[j][k];  
                        a[id[i][ty]][id[i][j]]+=p[i]*(1-p[j])/du[j];  
                    }  
                    for (int k=0;k<nxt[i].size();++k)  
                        for (int q=0;q<nxt[j].size();++q){  
                            int tx=nxt[i][k],ty=nxt[j][q];  
                            a[id[tx][ty]][id[i][j]]+=(1-p[i])*(1-p[j])/du[i]/du[j];  
                        }  
                }  
        for (int i=1;i<=n;++i)  
            for (int j=1;j<=n;++j) a[id[i][j]][id[i][j]]-=1.0;  
        a[id[x][y]][cnt+1]=-1;  
        guass();  
    }  
