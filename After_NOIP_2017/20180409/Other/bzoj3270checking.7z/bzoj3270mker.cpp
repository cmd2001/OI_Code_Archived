#include<bits/stdc++.h>
using namespace std;
const int maxn=25;

bool vis[maxn][maxn];
int n = 20;
inline int _(int r=n) {
    return rand() % n + 1;
}
inline double __() {
    int a = rand() , b = rand();
    while( !b || a / b ) a = rand() , b = rand();
    return (double) a / b;
}
inline void randedge(int &x,int &y) {
    x = _() , y = _();
    while( x == y || vis[x][y] ) x = _() , y = _();
    vis[x][y] = vis[y][x] = 1;
}

int main() {
    freopen("dat.txt","w",stdout);
    static int m = 50;
    printf("%d %d %d %d\n",n,m,_(),_());
    while(m--) {
        int x,y; randedge(x,y);
        printf("%d %d\n",x,y);
    }
    for(int i=1;i<=n;i++) printf("%lf%c",__(),i!=n?' ':'\n');
    return 0;
}
