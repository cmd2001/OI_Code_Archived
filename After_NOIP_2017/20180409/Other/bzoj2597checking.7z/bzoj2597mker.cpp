#include<bits/stdc++.h>
using namespace std;
const int maxn=110;

int in[maxn][maxn];

inline int _(int r=3) {
    return rand() % r ;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 5;
    printf("%d\n",n);
    for(int i=1;i<=n;i++)
        for(int j=1;j<i;j++) {
            const int t = _();
            if( t == 2 ) in[i][j] = in[j][i] = 2;
            else in[i][j] = t , in[j][i] = t ^ 1;
        }
    for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) printf("%d%c",in[i][j],j!=n?' ':'\n');
    return 0;
}