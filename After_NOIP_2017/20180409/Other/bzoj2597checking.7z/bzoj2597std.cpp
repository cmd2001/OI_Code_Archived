#include <cstdio>  
#include <cstring>  
#include <iostream>  
#include <algorithm>  
#define M 11000  
#define S 0  
#define T 10999  
#define INF 0x3f3f3f3f  
using namespace std;  
struct abcd{  
    int to,f,cost,next;  
}table[1001001];  
int head[M],tot=1;  
int n,cnt,ans,map[110][110],edge[110][110];  
void Add(int x,int y,int f,int cost)  
{  
    table[++tot].to=y;  
    table[tot].f=f;  
    table[tot].cost=cost;  
    table[tot].next=head[x];  
    head[x]=tot;  
}  
void Link(int x,int y,int f,int cost)  
{  
    Add(x,y,f,cost);  
    Add(y,x,0,-cost);  
}  
bool Edmons_Karp()  
{  
    static int q[65540],f[M],from[M],cost[M];  
    static unsigned short r,h;  
    static bool v[M];  
    int i;  
    memset(cost,0x3f,sizeof cost);  
    q[++r]=S;f[S]=INF;cost[S]=0;f[T]=0;  
    while(r!=h)  
    {  
        int x=q[++h];v[x]=0;  
        for(i=head[x];i;i=table[i].next)  
            if( table[i].f && cost[x]+table[i].cost<cost[table[i].to] )  
            {  
                cost[table[i].to]=cost[x]+table[i].cost;  
                f[table[i].to]=min(f[x],table[i].f);  
                from[table[i].to]=i;  
                if(!v[table[i].to])  
                    v[table[i].to]=1,q[++r]=table[i].to;  
            }  
    }  
    if(!f[T]) return false;  
    ans-=cost[T]*f[T];  
    for(i=from[T];i;i=from[table[i^1].to])  
        table[i].f-=f[T],table[i^1].f+=f[T];  
    return true;  
}  
int main()  
{  
      
    //freopen("hand.in","r",stdin);  
    //freopen("hand.out","w",stdout);  
      
    int i,j;  
    cin>>n;cnt=n;  
    for(i=1;i<=n;i++)  
        for(j=1;j<=n;j++)  
            scanf("%d",&map[i][j]);  
    for(i=1;i<=n;i++)  
        for(j=0;j<=n-2;j++)  
            Link(S,i,1,j);  
    for(i=1;i<=n;i++)  
        for(j=1;j<i;j++)  
        {  
            Link(++cnt,T,1,0);  
            if(map[i][j]==0||map[i][j]==2)  
                Link(i,cnt,1,0),edge[j][i]=tot-1;  
            if(map[i][j]==1||map[i][j]==2)  
                Link(j,cnt,1,0),edge[i][j]=tot-1;  
        }  
    ans=n*(n-1)*(n-2)/6;  
    while( Edmons_Karp() );  
    cout<<ans<<endl;  
    for(i=1;i<=n;i++)  
        for(j=1;j<=n;j++)  
        {  
            if(i==j) printf("0%c",j==n?'\n':' ');  
            else printf("%d%c",!edge[i][j]||table[edge[i][j]].f?0:1,j==n?'\n':' ');  
        }  
    return 0;  
}  