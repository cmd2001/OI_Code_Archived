#include<cmath>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define inf 1e9
using namespace std;
struct edge{int to,next,f;}e[11000];
int head[205],dis[205],q[205],a[205],b[205];
int n,m,S,T,x,y,ans,tot=1;
void add(int x,int y,int f){
    e[++tot]=(edge){y,head[x],f};
    head[x]=tot;
    e[++tot]=(edge){x,head[y],0};
    head[y]=tot;
}
bool bfs(){
    for (int i=1;i<=T;i++) dis[i]=-1;
    int h=dis[S]=0,t=1,x; q[1]=S;
    while (h!=t){
        x=q[++h];
        for (int i=head[x];i;i=e[i].next)
            if (e[i].f&&dis[e[i].to]==-1)
                dis[e[i].to]=dis[x]+1,q[++t]=e[i].to;
    }
    return dis[T]!=-1;
}
int dfs(int x,int flow){
    if (x==T) return flow;
    int k,rest=flow;
    for (int i=head[x];i;i=e[i].next)
        if (dis[e[i].to]==dis[x]+1&&e[i].f){
            k=dfs(e[i].to,min(e[i].f,rest));
            rest-=k; e[i].f-=k; e[i^1].f+=k;
        }
    if (rest) dis[x]=-1;
    return flow-rest;
}
int main(){
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++) scanf("%d",&a[i]);
    for (int i=1;i<=n;i++) scanf("%d",&b[i]);
    S=2*n+1; T=S+1;
    for (int i=1;i<=n;i++) add(S,i,b[i]);
    for (int i=1;i<=n;i++) add(i+n,T,a[i]);
    for (int i=1;i<=m;i++){
        scanf("%d%d",&x,&y);
        add(x,y+n,inf);
    }
    while (bfs()) ans+=dfs(S,inf);
    printf("%d\n",ans);
}