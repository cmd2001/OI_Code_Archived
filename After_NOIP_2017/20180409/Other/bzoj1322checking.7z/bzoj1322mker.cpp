#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 5000;
    printf("%d %d\n",n,m);
    for(int t=0;t<2;t++) for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) printf("%d %d\n",_(n),_(n));
    return 0;
}