#include<bits/stdc++.h>
#define ll long long
#define inf 1000000000
#define pa pair<ll,ll>
using namespace std;
const int mod=1000000007;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
struct node{ll p,s;}a[205],b[205];
ll n,f,m;
pa ans;
bool cmp(node a,node b)
{
    return (a.s==b.s)?a.p<b.p:a.s<b.s;
}
pa judge(ll mid)
{
    ll rest=m-f*mid,day=0,now=0;
    for (int i=1;i<=n;i++)
    {
        if (b[i].s>=day)
        {
            ll j=min(rest/b[i].p/mid,b[i].s-day+1);
            day+=j;now+=mid*j;rest-=b[i].p*j*mid;
        }
        if (b[i].s>=day)
        {
            ll j=min(rest/b[i].p,mid);
            now+=j;day++;rest-=b[i].p*j;
        }
    }
    return make_pair(now,rest);
}
int main()
{
    while (scanf("%lld%lld%lld",&m,&f,&n)!=EOF)
    {
        for (int i=1;i<=n;i++) scanf("%lld%lld",&a[i].p,&a[i].s);
        sort(a+1,a+n+1,cmp);int _n=0;
        for (int i=1;i<=n;i++)
        {
            while (_n!=0&&a[i].p<=b[_n].p) _n--;
            b[++_n]=a[i];
        }
        n=_n;
        ll l=1,r=m/(f+b[1].p);ans=make_pair(0,0);
        while (l<=r)
        {
            ll m1=l+(r-l)/3,m2=r-(r-l)/3;pa s1,s2;
            if ((s1=judge(m1))>(s2=judge(m2)))
            {
                ans=max(ans,s1);
                r=m2-1;
            }
            else
            {
                ans=max(ans,s2);
                l=m1+1;
            }
        }
        printf("%lld\n",ans.first);
    }
    return 0;
}