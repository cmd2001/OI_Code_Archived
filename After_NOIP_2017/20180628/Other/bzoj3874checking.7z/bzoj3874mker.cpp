#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5;
    printf("%d %d %d\n",_(),_(),n);
    for(int i=1;i<=n;i++) printf("%d %d\n",_(10),_(10));
    return 0;
}
