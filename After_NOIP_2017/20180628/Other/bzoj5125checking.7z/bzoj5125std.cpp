#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
const int N=40005;
int n,k;
int a[N];
int tr[N];//树状数组
int lb (int x){return x&(-x);}
void change (int x,int y){while (x<=n) {tr[x]+=y;x+=lb(x);}}
int find (int x)
{
    int lalal=0;
    while (x>=1){lalal=lalal+tr[x];x-=lb(x);}
    return lalal;
}
int g[N],f[N];
int L,R,now;
void go (int l,int r)
{
    while (R<r) now=now+(R-L+1-find(a[R+1])),change(a[++R],1);
    while (L<l) now=now-find(a[L]-1),change(a[L++],-1);
    while (L>l) now=now+find(a[L-1]-1),change(a[--L],1);
    while (R>r) now=now-(R-L+1-find(a[R])),change(a[R--],-1);
}
void solve (int l,int r,int dl,int dr)//要处理啊的区间    可以转移的区间
{
    int mid=(l+r)>>1,dm=dl;
    for (int u=dl;u<=min(mid-1,dr);u++)
    {
        go(u+1,mid);
        int t=g[u]+now;
        if (t<f[mid]) f[mid]=t,dm=u;
    }
    if (l<mid) solve(l,mid-1,dl,dm);
    if (mid<r) solve(mid+1,r,dm,dr);
}
int main()
{
    scanf("%d%d",&n,&k);
    for (int u=1;u<=n;u++) scanf("%d",&a[u]);
    for (int u=1;u<=n;u++)
    {
        change(a[u],1);
        f[u]=f[u-1]+u-find(a[u]);
    }
    for (int u=2;u<=k;u++)
    {
        memcpy(g,f,sizeof(g));
        memset(f,63,sizeof(f));
        memset(tr,0,sizeof(tr));
        L=1;R=0;now=0;
        solve(u,n,u-1,n);
    }
    printf("%d\n",f[n]);
    return 0;
}
