#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e4+1e2) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 10 , k = 2;
    printf("%d %d %d\n",n,m,k);
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,_(i-1),_());
    for(int i=n;i<=m;i++) printf("%d %d %d\n",_(n),_(n),_());
    return 0;
}