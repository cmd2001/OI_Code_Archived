#include <cstdio>
#include <cstring>
#include <algorithm>
#include <queue>
#include <utility>
#include <vector>
#define N 30010
#define inf 0x3fffffff
using namespace std;
priority_queue<pair<int , int> > q;
vector<int> v[N];
int hh[N] , tt[N << 2]  , ll[N << 2] , nn[N << 2] , cc = 1 , vv[N] , dd[N] , uu[N];
int n , k , head[N] , to[N << 1] , len[N << 1] , nxt[N << 1] , cnt;
int vis[N] , root , sum , si[N] , bs[N] , f[N] , g[N] , sf[N] , sg[N] , md , deep[N] , dis[N] , ans , num;
void aa(int x , int y , int z)
{
    tt[++cc] = y , ll[cc] = z , nn[cc] = hh[x] , hh[x] = cc;
}
void add(int x , int y , int z)
{
    printf("x = %d , y = %d , z = %d\n",x,y,z);
    to[++cnt] = y , len[cnt] = z , nxt[cnt] = head[x] , head[x] = cnt;
}
bool cmp(int a , int b)
{
    return tt[a] < tt[b];
}
void dijkstra()
{
    int x , i;
    memset(dd , 0x3f , sizeof(dd));
    dd[1] = 0 , q.push(make_pair(0 , 1));
    while(!q.empty())
    {
        x = q.top().second , q.pop();
        if(vv[x]) continue;
        vv[x] = 1;
        for(i = hh[x] ; i ; i = nn[i])
            if(dd[x] == dd[tt[i]] + ll[i])
                v[tt[i]].push_back(i ^ 1);
        for(i = hh[x] ; i ; i = nn[i])
            if(dd[tt[i]] > dd[x] + ll[i])
                dd[tt[i]] = dd[x] + ll[i] , q.push(make_pair(-dd[tt[i]] , tt[i]));
    }
}
void dfs(int x)
{
    int i;
    sort(v[x].begin() , v[x].end() , cmp);
    for(i = 0 ; i < (int)v[x].size() ; i ++ )
        if(!uu[tt[v[x][i]]])
            uu[tt[v[x][i]]] = 1 , add(x , tt[v[x][i]] , ll[v[x][i]]) , add(tt[v[x][i]] , x , ll[v[x][i]]) , dfs(tt[v[x][i]]);
}
void getroot(int x , int fa)
{
    int i;
    bs[x] = 0 , si[x] = 1;
    for(i = head[x] ; i ; i = nxt[i])
        if(!vis[to[i]] && to[i] != fa)
            getroot(to[i] , x) , si[x] += si[to[i]] , bs[x] = max(bs[x] , si[to[i]]);
    bs[x] = max(bs[x] , sum - si[x]);
    if(bs[x] < bs[root]) root = x;
}
void getdeep(int x , int fa)
{
    int i;
    for(i = head[x] ; i ; i = nxt[i])
    {
        if(!vis[to[i]] && to[i] != fa)
        {
            deep[to[i]] = deep[x] + 1 , dis[to[i]] = dis[x] + len[i] , md = max(md , deep[to[i]]);
            if(dis[to[i]] > f[deep[to[i]]]) f[deep[to[i]]] = dis[to[i]] , sf[deep[to[i]]] = 1;
            else if(dis[to[i]] == f[deep[to[i]]]) sf[deep[to[i]]] ++ ;
            getdeep(to[i] , x);
        }
    }
}
void query(int x)
{
    int i , j , sm = 0;
    vis[x] = 1;
    for(i = head[x] ; i ; i = nxt[i])
    {
        if(!vis[to[i]])
        {
            md = deep[to[i]] = 1 , dis[to[i]] = len[i] , f[1] = len[i] , sf[1] = 1 , getdeep(to[i] , x);
            for(j = 1 ; j <= md && j <= k ; j ++ )
            {
                if(ans < f[j] + g[k - j]) ans = f[j] + g[k - j] , num = sf[j] * sg[k - j];
                else if(ans == f[j] + g[k - j])num += sf[j] * sg[k - j];
            }
            for(j = 1 ; j <= md && j <= k ; j ++ )
            {
                if(g[j] < f[j]) g[j] = f[j] , sg[j] = sf[j];
                else if(g[j] == f[j]) sg[j] += sf[j];
            }
            for(j = 1 ; j <= md ; j ++ ) f[j] = -inf , sf[j] = 0;
            sm = max(sm , md);
        }
    }
    for(i = 1 ; i <= sm && i <= k ; i ++ ) g[i] = -inf , sg[i] = 0;
    for(i = head[x] ; i ; i = nxt[i])
        if(!vis[to[i]])
            root = 0 , sum = si[to[i]] , getroot(to[i] , x) , query(root);
}
int main()
{
    int m , i , x , y , z;
    scanf("%d%d%d" , &n , &m , &k) , k -- ;
    for(i = 1 ; i <= m ; i ++ ) scanf("%d%d%d" , &x , &y , &z) , aa(x , y , z) , aa(y , x , z);
    dijkstra() , uu[1] = 1 , dfs(1);
    memset(f , 0xc0 , sizeof(f)) , memset(g , 0xc0 , sizeof(g)) , g[0] = 0 , sg[0] = 1;
    bs[0] = inf , sum = n , getroot(1 , 0) , query(root);
    printf("%d %d\n" , ans , num);
    return 0;
}

