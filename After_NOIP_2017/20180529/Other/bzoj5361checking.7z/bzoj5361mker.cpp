#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2e5) {
    return rand() % r + 1;
}

inline void makecase() {
    int n = 5 , m = 0;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    while(m--) printf("%d %d\n",_(n),_(n));
}
int main() {
    static int T = 10;
    srand((unsigned long long)new char);
    printf("%d\n",T);
    while(T--) makecase();
    return 0;
}