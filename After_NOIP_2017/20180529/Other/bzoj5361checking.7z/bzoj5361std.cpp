#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define inf 0x3f3f3f3f
#define N 200010
#define ull unsigned long long
#define nn 200001
inline char gc(){
    static char buf[1<<16],*S,*T;
    if(S==T){T=(S=buf)+fread(buf,1,1<<16,stdin);if(T==S) return EOF;}
    return *S++;
}
inline int read(){
    int x=0,f=1;char ch=gc();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=gc();}
    while(ch>='0'&&ch<='9') x=x*10+ch-'0',ch=gc();
    return x*f;
}
int n,m,h[N],num=0,a[N],fa[N][20],Log[N],dep[N],rt[N],owo=0;
ull w[N],s[N];
struct edge{
    int to,next;
}data[N<<1];
struct node{
    int lc,rc;ull x;
}tr[N*20];
inline void ins(int &p,int l,int r,int x){
    tr[++owo]=tr[p];p=owo;tr[p].x^=w[x];
    if(l==r) return;int mid=l+r>>1;
    if(x<=mid) ins(tr[p].lc,l,mid,x);
    else ins(tr[p].rc,mid+1,r,x);
}
void dfs(int x){
    rt[x]=rt[fa[x][0]];ins(rt[x],1,nn,a[x]);
    for(int i=1;i<=Log[n];++i){
        if(!fa[x][i-1]) break;
        fa[x][i]=fa[fa[x][i-1]][i-1];
    }for(int i=h[x];i;i=data[i].next){
        int y=data[i].to;if(y==fa[x][0]) continue;
        fa[y][0]=x;dep[y]=dep[x]+1;dfs(y);
    }
}
inline int lca(int x,int y){
    if(dep[x]<dep[y]) swap(x,y);
    int d=dep[x]-dep[y];
    for(int i=0;i<=Log[d];++i)
        if(d>>i&1) x=fa[x][i];
    if(x==y) return x;
    for(int i=Log[n];i>=0;--i)
        if(fa[x][i]!=fa[y][i]) x=fa[x][i],y=fa[y][i];
    return fa[x][0];
}
inline int ask(int p1,int p2,int p3,int p4,int l,int r){
    if(l==r) return l;int mid=l+r>>1;
    ull res=tr[tr[p1].lc].x^tr[tr[p2].lc].x^tr[tr[p3].lc].x^tr[tr[p4].lc].x;
    if(res==(s[mid]^s[l-1])) return ask(tr[p1].rc,tr[p2].rc,tr[p3].rc,tr[p4].rc,mid+1,r);
    return ask(tr[p1].lc,tr[p2].lc,tr[p3].lc,tr[p4].lc,l,mid);
}
int main(){
//  freopen("a.in","r",stdin);
    int tst=read();srand(200000711);
    for(int i=1;i<=nn;++i) w[i]=rand()*rand()*rand()*rand(),s[i]=w[i]^s[i-1];
    while(tst--){
        n=read();m=read();Log[0]=-1;memset(fa,0,sizeof(fa));
        memset(rt,0,sizeof(rt));owo=0;memset(h,0,sizeof(h));num=0;
        for(int i=1;i<=n;++i) Log[i]=Log[i>>1]+1,a[i]=read();
        for(int i=1;i<n;++i){
            int x=read(),y=read();
            data[++num].to=y;data[num].next=h[x];h[x]=num;
            data[++num].to=x;data[num].next=h[y];h[y]=num;
        }dfs(1);while(m--){
            int x=read(),y=read(),t=lca(x,y);
            printf("%d\n",ask(rt[x],rt[y],rt[t],rt[fa[t][0]],1,nn));
        }
    }return 0;
}