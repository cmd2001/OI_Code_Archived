#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 7;
    printf("%d\n",n);
    while(n--) printf("%d %d\n",_(),_());
    return 0;
}