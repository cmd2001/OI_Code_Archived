#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}
inline int __() {
    return _() - _();
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 100;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",__(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) {
        int o = min(_(12),6);
        if( !n ) o = 1;
        if( o == 1 ) {
            int pos = _(n+1) - 1 , len = _(3);
            printf("INSERT %d %d ",pos,len) , n += len;
            for(int i=1;i<=len;i++) printf("%d%c",__(),i!=len?' ':'\n');
        } else if( o == 2 ) {
            int st = _(n), len = _(n-st+1);
            printf("DELETE %d %d\n",st,len) , n -= len;
        } else if( o == 3 ) {
            int st = _(n) , len = _(n-st+1);
            printf("MAKE-SAME %d %d %d\n",st,len,__());
        } else if( o == 4 ) {
            int st = _(n), len = _(n-st+1);
            printf("REVERSE %d %d\n",st,len);
        } else if( o == 5 ) {
            int st = _(n) , len = _(n-st+1);
            printf("GET-SUM %d %d\n",st,len);
        } else puts("MAX-SUM");
    }
    return 0;
}