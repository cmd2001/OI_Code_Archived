#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+1e2;

int fa[maxn];

inline int fd(int x) {
    return fa[x] == x ? x : fa[x] = fd(fa[x]);
}
inline int _(int r=1000) {
    return rand() % r + 1;
}
inline void makegroup(int &x,int &y,int n) {
    x = _(n) , y = _(n);
    while( fd(x) != fd(y) ) x = _(n) , y = _(n);
}

int main() {
    srand((unsigned long long)new char);
    static int n = 10000 , m = 50000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) fa[i] = i;
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1,x,y;i<=m;i++) {
        if( _() & 1 ) {
            makegroup(x,y,n);
            printf("0 %d %d\n",x,y);
        }
        else {
            int t = _(3);
            if( t == 2 ) { --i; continue; }
            if( t == 3 ) printf("%d %d %d\n",t,_(n),_());
            else {
                printf("%d %d %d\n",t,y=_(n),x=_(n));
                if( fd(x) != fd(y) ) fa[fd(x)] = y;
            }
        }
    }
    return 0;
}
