#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
const int maxn = 100002;
struct node{
    int u,v,w,id;
    bool q;
}e[maxn*10];
int n,m,T,N,ls[maxn*50],rs[maxn*50],sum[maxn*50],tot,h[maxn],ori[maxn],a[maxn],root[maxn],fa[maxn],ans[maxn*5];

void read(int &x){
    x=0; int f=1; char c=getchar();
    while (c<'0' || c>'9'){if (c=='-') f=-1; c=getchar();}
    while (c>='0' && c<='9') x=x*10+c-48,c=getchar();
    x*=f;
}

bool operator<(node a, node b){
    return a.w==b.w?a.q<b.q:a.w<b.w;
}

int find(int x){
    return fa[x]==x?x:fa[x]=find(fa[x]);
}

void insert(int &x, int l, int r, int pos){
    if (!x) x=++tot;
    if (l==r){
        sum[x]=1;
        return;
    }
    int mid=l+r>>1;
    if (pos<=mid) insert(ls[x],l,mid,pos);
    else insert(rs[x],mid+1,r,pos);
    sum[x]=sum[ls[x]]+sum[rs[x]];
}

int merge(int x, int y){
    if (!x || !y) return x+y;
    if (!ls[x] && !rs[x]){
        sum[x]+=sum[y];
        return x;
    }
    ls[x]=merge(ls[x],ls[y]);
    rs[x]=merge(rs[x],rs[y]);
    sum[x]=sum[ls[x]]+sum[rs[x]];
    return x;
}

int query(int x, int l, int r, int pos){
    if (l==r) return l; int mid=l+r>>1;
    if (sum[ls[x]]>=pos) return query(ls[x],l,mid,pos);
    else return query(rs[x],mid+1,r,pos-sum[ls[x]]);
}

int main(){
    read(n); read(m); read(T);
    for (int i=1; i<=n; i++) read(h[i]), a[i]=h[i];
    sort(a+1,a+1+n); N=unique(a+1,a+1+n)-a-1;
    for (int i=1,height; i<=n; i++) height=h[i],h[i]=lower_bound(a+1,a+1+N,h[i])-a,ori[h[i]]=height;
    for (int i=1; i<=n; i++) insert(root[i],1,n,h[i]),fa[i]=i;
    for (int i=1; i<=m; i++) read(e[i].u), read(e[i].v), read(e[i].w), e[i].q=0;
    for (int i=1+m; i<=T+m; i++) read(e[i].u), read(e[i].w), read(e[i].v), e[i].q=1, e[i].id=i-m;
    sort(e+1,e+1+m+T);
    for (int i=1,cnt=0,u,v; i<=m+T; i++){
        if (!e[i].q){
            if (cnt==n-1) continue;
            u=find(e[i].u), v=find(e[i].v);
            if (u!=v){
                fa[u]=v; cnt++;
                root[v]=merge(root[u],root[v]);
            }
        }
        else{
            int x=find(e[i].u);
            if (sum[root[x]]<e[i].v) ans[e[i].id]=-1;
            else ans[e[i].id]=ori[query(root[x],1,n,sum[root[x]]-e[i].v+1)];
        }
    }
    for (int i=1; i<=T; i++) printf("%d\n", ans[i]);
    return 0;
}
