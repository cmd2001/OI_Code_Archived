#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5 , m = 5e5 , q = 5e5;
    printf("%d %d %d\n",n,m,q);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) printf("%d %d %d\n",_(n),_(n),_());
    for(int i=1;i<=q;i++) printf("%d %d %d\n",_(n),_(),_(n));
    return 0;
}
