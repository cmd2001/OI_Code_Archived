#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long long Mod=10086;
int n,v[100010],b[40],a[100010],q,tot,now,zero;
long long ans,mul[100010];
int comp(int x,int y){return x>y;}
void Gauss_Eli(){
    for (int i=1;i<=n;i++){
        for (int j=31;j>=0;j--)
          if ((v[i]>>j)&1)
            if (b[j]==0){b[j]=i;break;}
            else v[i]^=v[b[j]];
        if (v[i]==0) ++zero;
    }
    for (int i=31;i>=0;i--)
      for (int j=1;j<=n;j++)
        if (b[i]!=j&&((v[j]>>i)&1))
          v[j]^=v[b[i]];
    sort(v+1,v+n+1,comp);
    tot=n;
    while (v[tot]==0) --tot;
}
int main()
{
    freopen("dat.txt","r",stdin);
    scanf("%d",&n);mul[0]=1;
    for (int i=1;i<=n;i++)
      mul[i]=(mul[i-1]*2)%Mod;
    for (int i=1;i<=n;i++){
        scanf("%d",&v[i]);
        a[i]=v[i];
    }
    Gauss_Eli();ans=1;
    scanf("%d",&q);
    for (int i=1;i<=tot;i++)
      if ((now^v[i])<q){
          now^=v[i];
          ans=(ans+mul[tot-i])%Mod;;
      }
    ans=(ans*mul[zero])%Mod;//���㡰0������
    if (q==0) ans=1;
    else ans=(ans+1)%Mod;
    printf("%I64d\n",ans);
    return 0;
}
