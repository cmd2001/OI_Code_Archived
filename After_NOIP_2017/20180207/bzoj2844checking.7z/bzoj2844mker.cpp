#include<bits/stdc++.h>
using namespace std;

inline long long __() {
    return rand() | (rand()<<15);
}
inline int _() {
    return __() % 1000000000;
}
int main() {
    freopen("dat.txt","w",stdout);
    const int n = 1e5;
    printf("%d\n",n);
    for(int i=0;i<=n;i++) printf("%d\n",_());
    return 0;
}
