#include<bits/stdc++.h>
using namespace std;

inline int _(int x=1000000000) {
    return rand() % x + 1;
}
inline bool same(int a,int b,int c,int d) {
    static int p[5];
    p[1] = a , p[2] = b , p[3] = c , p[4] = d;
    sort(p+1,p+5);
    for(int i=2;i<=4;i++) if( p[i] == p[i-1] ) return 1;
    return 0;
}
int main() {
    srand((unsigned long long)new char);
    //freopen("dat.txt","w",stdout);
    int n = 20000 , m = 25000;
    printf("%d\n",n);
    for(int i=1;i<=n;i++)
        printf("%d%c",_(),i!=n?' ':'\n');
    printf("%d\n",m);
    for(int i=1;i<=m;i++) {
        int a = _(n) , b = _(n) , c = _(n) , d = _(n);
        while( same(a,b,c,d) ) a = _(n) , b = _(n) , c = _(n) , d = _(n);
        printf("%d %d %d %d\n",a,b,c,d);
    }
    return 0;
}
