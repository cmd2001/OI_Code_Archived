#include<iostream>  
#include<cstdio>  
#include<cstring>  
using namespace std;  
  
int n,len,bin[25],f[2500005],g[1005][26]; char ch[1005];  
int main(){  
    int cas,i,k; scanf("%d",&cas);  
    bin[0]=1; for (i=1; i<=21; i++) bin[i]=bin[i-1]<<1;  
    while (cas--){  
        scanf("%d%s",&n,ch+1); len=strlen(ch+1);  
        if (n>21){ puts("NO"); continue; }  
        for (i=0; i<n; i++) g[len][i]=g[len+1][i]=len+1;  
        for (i=len; i; i--){  
            for (k=0; k<n; k++) g[i-1][k]=g[i][k];  
            g[i-1][ch[i]-'a']=i;  
        }  
        for (i=1; i<bin[n]; i++)  
            for (f[i]=k=0; bin[k]<=i; k++)  
                if (i&bin[k]) f[i]=max(f[i],g[f[i^bin[k]]][k]);  
        puts((f[bin[n]-1]<=len)?"YES":"NO");  
    }  
    return 0;  
}  
