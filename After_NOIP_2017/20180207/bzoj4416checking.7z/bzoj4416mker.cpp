#include<bits/stdc++.h>
using namespace std;

int main() {
    static int T = 1;
    srand((unsigned long long)new char);
    printf("%d\n",T);
    while(T--) {
        int n = rand() % 11 + 10 , t = rand() % 150 + 1;
        printf("%d\n",n);
        while(t--) putchar('a'+rand()%26);
        puts("");
    }
    return 0;
}
