#include<bits/stdc++.h>
using namespace std;

set<pair<int,int> > es;

inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 7;
    printf("%d %d\n",n,m);
    for(int i=2,t;i<=n;i++) es.insert(make_pair(t=_(i-1),i)) , printf("%d %d\n",t,i);
    for(int i=n,a,b;i<=m;i++) {
        while(1) {
            a = _(n) , b = _(n);
            if( a == b ) continue;
            if( es.find(make_pair(min(a,b),max(a,b))) != es.end() ) continue;
            break;
        }
        es.insert(make_pair(min(a,b),max(a,b))) , printf("%d %d\n",a,b);
    }
    return 0;
}

