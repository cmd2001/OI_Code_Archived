#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<map>
#include<set>
#include<vector>
#include<queue>
#define pa pair<int,int>
#define inf 1000000000
#define ll long long 
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int n,m,cnt,ind;
int last[100005],size[100005],dfn[100005],low[100005];
ll ans[100005];
struct edge{int to,next;}e[1000005];
void insert(int u,int v)
{
	e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;
	e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;
}
void tarjan(int x)
{
	int t=0;
	size[x]=1;
	dfn[x]=low[x]=++ind;
	for(int i=last[x];i;i=e[i].next)
		if(dfn[e[i].to])low[x]=min(low[x],dfn[e[i].to]);
		else 
		{
			tarjan(e[i].to);
			size[x]+=size[e[i].to];
			low[x]=min(low[x],low[e[i].to]);
			if(dfn[x]<=low[e[i].to])
			{
				ans[x]+=(ll)t*size[e[i].to];
				t+=size[e[i].to];
			}
		}
	ans[x]+=(ll)t*(n-t-1);
}
int main()
{
	n=read();m=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read();
		insert(u,v);
	}
	tarjan(1);
	for(int i=1;i<=n;i++)
		printf("%lld\n",(ans[i]+n-1)*2);
	return 0;
}
