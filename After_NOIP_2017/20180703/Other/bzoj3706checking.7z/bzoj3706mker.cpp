#include<bits/stdc++.h>
using namespace std;

set<pair<int,int> > es;
inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    static int n = 1e6 , m = 1e6 , q = 1e6;
    srand((unsigned long long)new char);
    printf("%d %d\n",n,m);
    for(int i=1,a,b;i<=m;i++) {
        while(1) {
            a = _(n) , b = _(n);
            if( a == b ) continue; 
            if( es.find(make_pair(min(a,b),max(a,b))) != es.end() ) continue;
            break;
        }
        es.insert(make_pair(min(a,b),max(a,b))) , printf("%d %d %d\n",a,b,_(2)-1);
    }
    printf("%d\n",q);
    for(int i=1,o;i<=q;i++) {
        o = _(2);
        if( o == 2 ) printf("%d\n",o);
        else printf("%d %d\n",o,_(m)-1);
    }
    return 0;
}



