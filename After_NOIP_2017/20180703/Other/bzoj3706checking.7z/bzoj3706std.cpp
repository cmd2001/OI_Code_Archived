#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define N 1000003
using namespace std;
int fa[N],sum[N],ans,cnt,n,m;
int x[N],y[N],c[N],du[N];
int find(int x)
{
	if (fa[x]==x) return x;
	fa[x]=find(fa[x]);
	return fa[x];
}
int main()
{
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) fa[i]=i;
	for (int i=1;i<=m;i++) {
		scanf("%d%d%d",&x[i],&y[i],&c[i]);
		int r1=find(x[i]); int r2=find(y[i]);
		if (r1!=r2) {
			if (sum[r1]&&sum[r2]) ans--;
			sum[r1]+=sum[r2]; fa[r2]=r1;
		}
		if (c[i]) {
			sum[r1]++; if (sum[r1]==1) ans++;
			du[x[i]]++; du[y[i]]++;
			if (du[x[i]]&1) cnt++;
			else cnt--;
			if (du[y[i]]&1) cnt++;
			else cnt--; 
		}
	}
	int q; scanf("%d",&q);
	for (int i=1;i<=q;i++) {
		int opt,now;
		scanf("%d",&opt);
		if (opt==1) {
			scanf("%d",&now); now++;
			int r1=find(x[now]);
			c[now]^=1;
			if (c[now]) {//变成黑边 
				sum[r1]++; if (sum[r1]==1) ans++;
				du[x[now]]++; du[y[now]]++;
			    if (du[x[now]]&1) cnt++;
			    else cnt--;
			    if (du[y[now]]&1) cnt++;
			    else cnt--; 
			}
			else {
				sum[r1]--; if (sum[r1]==0) ans--;
				du[x[now]]--; du[y[now]]--;
			    if (du[x[now]]&1) cnt++;
			    else cnt--;
			    if (du[y[now]]&1) cnt++;
			    else cnt--; 
			}
		}
		else {
			if (cnt) printf("-1\n");
			else printf("%d\n",ans);
		}
	}
}
