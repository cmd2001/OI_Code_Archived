#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<cstdlib>
#include<algorithm>
#include<queue>
#define pa pair<int,int>
#define ll long long
#define inf 1000000000
using namespace std;
int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int n,cnt;
int d[1000005],last[1000005];
int pre[1000005],nxt[1000005];
bool vis[1000005];
struct edge{int to,next,v;}e[3000005];
void insert(int u,int v,int w)
{
	e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;e[cnt].v=w;
}
void dijkstra()
{
	priority_queue<pa,vector<pa>,greater<pa> >q;
	for(int i=0;i<=n+1;i++)d[i]=inf;
	d[1]=0;q.push(make_pair(0,1));
	while(!q.empty())
	{
		int now=q.top().second;q.pop();
		if(vis[now])continue;vis[now]=1;
		for(int i=last[now];i;i=e[i].next)
			if(d[now]+e[i].v<d[e[i].to])
			{
				d[e[i].to]=d[now]+e[i].v;
				q.push(make_pair(d[e[i].to],e[i].to));
			}
	}
}
int main()
{
	n=read();
	for(int i=1;i<=n;i++)
	{
		int x=read();
		for(int j=i+1;j<=min(i+x+1,n)&&!pre[j];j++)
			pre[j]=1,insert(j,j-1,1);
		for(int j=i+x+1;j<=n&&!nxt[j];j++)
			nxt[j]=1,insert(j,j+1,1);
		if(i+x<=n)
			insert(i,i+x+1,0);
		else insert(i,n+1,i+x-n);
	}
	dijkstra();
	printf("%d\n",d[n+1]);
	return 0;
}
