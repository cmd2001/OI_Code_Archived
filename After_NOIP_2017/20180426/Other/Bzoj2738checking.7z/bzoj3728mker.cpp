#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5e5 , k = _(n);
    printf("%d %d\n",n,k);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    return 0;
}