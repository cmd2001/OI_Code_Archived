#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
#include<algorithm>
#include<vector>
#include<set>
#include<map>
#include<queue>
#define ll long long 
#define inf 1000000000
using namespace std;
ll read()
{
    ll x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
ll ans;
int n,k;
int p[500005],w[500005];
multiset<int> st;
priority_queue<int,vector<int> >q;
int main()
{
	n=read();k=read();
	for(int i=1;i<=n;i++)p[i]=read();
	sort(p+1,p+n+1);
	for(int i=1;i<=n;i++)w[i]=read();
	for(int i=1;i<=n;i++)
		st.insert(w[i]);
	for(int i=1;i<=n;i++)
	{
		multiset<int>::iterator it=st.upper_bound(p[i]);
		if(it!=st.begin())
		{
			--it;
			q.push(p[i]-*it);
			st.erase(it);
			ans+=p[i];
		}
	}
	if(st.size()>k){puts("NIE");return 0;}
	for(multiset<int>::iterator it=st.begin();it!=st.end();it++)
	{
		k--;
		ans+=*it;
	}
	while(k--){ans-=q.top();q.pop();}
	printf("%lld\n",ans);
	return 0;
}