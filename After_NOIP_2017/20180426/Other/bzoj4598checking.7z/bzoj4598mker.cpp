#include<bits/stdc++.h>
#define debug cout
using namespace std;

inline int _(int r=26) {
    return rand() % r + 1;
}

int main() {
    freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char);
    static int T = 10 , n = 1e6 , m = 3;
    printf("%d\n",T);
    while(T--) {
        printf("%d %d\n",n,m);
        for(int i=1;i<=n;i++) printf("%c",_(26)-1+'A');
        puts("");
        for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
        for(int i=1;i<=m;i++) printf("%c",_(26)-1+'A');
        puts("");
    }
    return 0;
}