#include<bits/stdc++.h>
using namespace std;

inline int _(int r=100) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5000 , m = 5000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_()-_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",_(i-1),i);
    for(int i=1;i<=m;i++) ( _(2) & 1 ) ? printf("Q %d\n",_(n)) : printf("M %d %d\n",_(n),_()-_());
    return 0;
}
