#include <queue>
#include <cstdio>
#include <algorithm>
#define N 200010
#define lson l , mid , x << 1
#define rson mid + 1 , r , x << 1 | 1
using namespace std;
typedef long long ll;
struct data
{
    ll sum , ls , rs , ts;
    inline friend data operator+(const data &a , const data &b)
    {
        data ans;
        ans.sum = a.sum + b.sum;
        ans.ls = max(a.ls , a.sum + b.ls);
        ans.rs = max(b.rs , b.sum + a.rs);
        ans.ts = max(a.rs + b.ls , max(a.ts , b.ts));
        return ans;
    }
}a[N << 2];
struct heap
{
    priority_queue<ll> A , B;
    inline void push(ll x) {A.push(x);}
    inline void del(ll x) {B.push(x);}
    inline ll top()
    {
        while(!B.empty() && A.top() == B.top()) A.pop() , B.pop();
        return A.top();
    }
}q[N];
int n , v[N] , head[N] , to[N << 1] , nxt[N << 1] , cnt , fa[N] , si[N] , bl[N] , ed[N] , pos[N] , tot;
ll f[N] , ms[N] , w[N];
char str[5];
inline void add(int x , int y)
{
    to[++cnt] = y , nxt[cnt] = head[x] , head[x] = cnt;
}
void dfs1(int x)
{
    int i;
    si[x] = 1;
    for(i = head[x] ; i ; i = nxt[i])
        if(to[i] != fa[x])
            fa[to[i]] = x , dfs1(to[i]) , si[x] += si[to[i]];
}
void dfs2(int x , int c)
{
    int i , k = 0;
    bl[x] = c , pos[x] = ++tot , w[pos[x]] = v[x];
    for(i = head[x] ; i ; i = nxt[i])
        if(to[i] != fa[x] && si[to[i]] > si[k])
            k = to[i];
    if(k)
    {
        dfs2(k , c) , f[x] = f[k] , ms[x] = ms[k] , ed[x] = ed[k];
        for(i = head[x] ; i ; i = nxt[i])
            if(to[i] != fa[x] && to[i] != k) {
                dfs2(to[i] , to[i]) , w[pos[x]] += f[to[i]] , q[pos[x]].push(ms[to[i]]);
                //if( x == 3 ) printf("ms = %d\n",ms[to[i]]);
            }
    }
    else ed[x] = x;
    f[x] = max(f[x] + w[pos[x]] , 0ll) , ms[x] = max(ms[x] , max(f[x] , q[pos[x]].top()));
}
void build(int l , int r , int x)
{
    if(l == r)
    {
        a[x].sum = w[l] , a[x].ls = a[x].rs = max(w[l] , 0ll) , a[x].ts = max(w[l] , q[l].top());
        return;
    }
    int mid = (l + r) >> 1;
    build(lson) , build(rson);
    a[x] = a[x << 1] + a[x << 1 | 1];
}
void fix(int p , int l , int r , int x)
{
    if(l == r)
    {
        a[x].sum = w[l] , a[x].ls = a[x].rs = max(w[l] , 0ll) , a[x].ts = max(w[l] , q[l].top());
        return;
    }
    int mid = (l + r) >> 1;
    if(p <= mid) fix(p , lson);
    else fix(p , rson);
    a[x] = a[x << 1] + a[x << 1 | 1];
}
data query(int b , int e , int l , int r , int x)
{
    if(b <= l && r <= e) return a[x];
    int mid = (l + r) >> 1;
    if(e <= mid) return query(b , e , lson);
    else if(b > mid) return query(b , e , rson);
    else return query(b , e , lson) + query(b , e , rson);
}
void modify(int x , int z)
{
    data a , b;
    bool flag = 0;
    a.ls = w[pos[x]] , b.ls = w[pos[x]] - v[x] + z , v[x] = z;
    while(x)
    {
        w[pos[x]] += b.ls - a.ls;
        if(flag) {
            //printf("ts = %lld\n",a.ts);
            q[pos[x]].del(a.ts) , q[pos[x]].push(b.ts);
        }
        a = query(pos[bl[x]] , pos[ed[x]] , 1 , n , 1);
        fix(pos[x] , 1 , n , 1);
        b = query(pos[bl[x]] , pos[ed[x]] , 1 , n , 1);
        x = fa[bl[x]] , flag = 1;
    }
}
int main()
{
    int m , i , x , y;
    scanf("%d%d" , &n , &m);
    for(i = 1 ; i <= n ; i ++ ) scanf("%d" , &v[i]) , q[i].push(0);
    for(i = 1 ; i < n ; i ++ ) scanf("%d%d" , &x , &y) , add(x , y) , add(y , x);
    dfs1(1) , dfs2(1 , 1);
    //for(int i=1;i<=n;i++) printf("%lld ",ms[i]); puts("");
    //for(int i=1;i<=n;i++) printf("%lld ",w[pos[i]]); puts("");
    build(1 , n , 1);
    while(m -- )
    {
        scanf("%s%d" , str , &x);
        if(str[0] == 'M') scanf("%d" , &y) , modify(x , y);
        else printf("%lld\n" , query(pos[x] , pos[ed[x]] , 1 , n , 1).ts);
    }
    return 0;
}
