#include <cassert>
#include <iostream>

using namespace std;

const int kMaxN = 2e5, kWordSize = 21;

struct Node {
    int and_sum, or_sum;
    int mx;
    int and_tag, or_tag;

    Node(const int value = 0) : and_sum(value), or_sum(value), mx(value), 
            and_tag((1 << kWordSize) - 1), or_tag(0) { }
} tree[1 << 19];

int a[kMaxN];

void JoinSons(int node) {
    tree[node].and_sum = tree[2 * node + 1].and_sum & tree[2 * node + 2].and_sum;
    tree[node].or_sum = tree[2 * node + 1].or_sum | tree[2 * node + 2].or_sum;
    tree[node].mx = max(tree[2 * node + 1].mx, tree[2 * node + 2].mx);
}

void BuildTree(int node, int left, int right) {
    if (left == right) {
        tree[node] = Node(a[left]);
    } else {
       int middle = (left + right) / 2;
       BuildTree(2 * node + 1, left, middle);
       BuildTree(2 * node + 2, middle + 1, right);    
       JoinSons(node);
    }
}

void PushLazy(int node, int left, int right) {
    tree[node].mx &= tree[node].and_tag;
    tree[node].and_sum &= tree[node].and_tag;
    tree[node].or_sum &= tree[node].and_tag;
    
    tree[node].mx |= tree[node].or_tag;
    tree[node].and_sum |= tree[node].or_tag;
    tree[node].or_sum |= tree[node].or_tag;
    if (left != right) {
        tree[2 * node + 1].and_tag &= tree[node].and_tag;
        tree[2 * node + 1].or_tag &= tree[node].and_tag;
        tree[2 * node + 2].and_tag &= tree[node].and_tag;
        tree[2 * node + 2].or_tag &= tree[node].and_tag;

        tree[2 * node + 1].or_tag |= tree[node].or_tag;
        tree[2 * node + 2].or_tag |= tree[node].or_tag;
    }
    tree[node].and_tag = (1 << kWordSize) - 1;
    tree[node].or_tag = 0;
}

void Update(int node, int left, int right, 
            const int q_left, const int q_right, 
            const int value, const bool is_or) {
    PushLazy(node, left, right);
    if (q_left > right or left > q_right) {
        return;
    }
    if (q_left <= left and right <= q_right) {
        if (!((tree[node].or_sum ^ tree[node].and_sum) & (is_or ? value : ~value))) { 
            if (is_or) {
                tree[node].or_tag |= value;
            } else {
                tree[node].and_tag &= value;
                tree[node].or_tag &= value;
            }
            PushLazy(node, left, right);
            return;
        }
    }

    int middle = (left + right) / 2;
    Update(2 * node + 1, left, middle, q_left, q_right, value, is_or);
    Update(2 * node + 2, middle + 1, right, q_left, q_right, value, is_or); 
    JoinSons(node);
}

int QueryMax(int node, int left, int right, int q_left, int q_right) {
    PushLazy(node, left, right);
    if (q_left <= left and right <= q_right) {
        return tree[node].mx;
    } else if (left > q_right or q_left > right) {
        return 0;
    } else {
        int middle = (left + right) / 2;
        int ans = max(QueryMax(2 * node + 1, left, middle, q_left, q_right),
                      QueryMax(2 * node + 2, middle + 1, right, q_left, q_right));
        JoinSons(node);
        return ans;
    }
}

int main() {
    cin.tie(0);
    ios_base::sync_with_stdio(false);

    int n, q; cin >> n >> q;
    for (int i = 0; i < n; i += 1) { cin >> a[i]; }
    BuildTree(0, 0, n - 1);

    while (q--> 0) {
        int op_type, left, right; cin >> op_type >> left >> right; left -= 1; right -= 1;
        if (op_type == 3) {
            cout << QueryMax(0, 0, n - 1, left, right) << '\n';
        } else {
            int x; cin >> x;
            Update(0, 0, n - 1, left, right, x, op_type - 1);
        }
    }

    return 0;
}

