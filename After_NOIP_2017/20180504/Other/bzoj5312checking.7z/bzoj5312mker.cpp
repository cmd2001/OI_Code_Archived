#include<bits/stdc++.h>
using namespace std;

inline int Rand() {
    return rand() + ( rand() << 16 );
}
inline int _(int r=1<<20) {
    return Rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2e5 , m = 2e5;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    while(m--) {
        int o = _(3) , l = _(n) , r = _(n);
        if( l > r ) swap(l,r);
        if( o == 3 ) printf("%d %d %d\n",o,l,r);
        else printf("%d %d %d %d\n",o,l,r,_());
    }
    return 0;
}
