#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}

inline void make_point(int k) {
    for(int i=1;i<=k;i++) printf("%d%c",_(),i!=k?' ':'\n');
}

inline void make_case() {
    srand((unsigned long long)new char ^ time(0));
    int n = 10000 , k = _(5) , t = 3;
    printf("%d %d\n",n,k); for(int i=1;i<=n;i++) make_point(k);
    printf("%d\n",t);
    while(t--) make_point(k) , printf("%d\n",_(n));
}

int main() {
    for(int i=0;i<2;i++) make_case();
    return 0;
}