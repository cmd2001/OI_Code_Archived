#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#define mp make_pair
#define pa pair<int,int>
#define M 500005
#include <queue>
#define inf 0x3f3f3f3f
#define fi first
#define se second
using namespace std;
priority_queue<pa> pq;
int q[10],ans[M];
struct node
{
    int ma[10],mi[10],d[10],l,r;
}t[M];
int root,n,m,k,now;
void read(int &tmp)
{
    tmp=0;
    char ch=getchar();
    int fu=1;
    for (;ch<'0'||ch>'9';ch=getchar())
        if (ch=='-') fu=-1;
    for (;ch>='0'&&ch<='9';ch=getchar())
        tmp=tmp*10+ch-'0';
    tmp*=fu;
}
bool cmp(node a,node b)
{
    return a.d[now]<b.d[now];
}
void Update(int x)
{
    int l=t[x].l,r=t[x].r;
    for (int i=0;i<k;i++)
    {
        t[x].mi[i]=min(t[x].mi[i],min(t[l].mi[i],t[r].mi[i]));
        t[x].ma[i]=max(t[x].ma[i],max(t[l].ma[i],t[r].ma[i]));
    }
}
int Build(int l,int r,int d)
{
    now=d;
    int mid=(l+r)>>1;
    nth_element(t+1+l,t+1+mid,t+1+r,cmp);
    if (mid!=l) t[mid].l=Build(l,mid-1,(d+1)%k);
    else t[mid].l=0;
    if (mid!=r) t[mid].r=Build(mid+1,r,(d+1)%k);
    else t[mid].r=0;
    Update(mid);
    return mid;
}
int Sqr(int x)
{
    return x*x;
}
int Dis(int x)
{
    int ans=0;
    for (int i=0;i<k;i++)
        ans+=Sqr(t[x].d[i]-q[i]);
    return ans;
}
int Get(int x)
{
    int ans=0;
    for (int i=0;i<k;i++)
    {
        if (q[i]<t[x].mi[i])
            ans+=Sqr(t[x].mi[i]-q[i]);
        if (q[i]>t[x].ma[i])
            ans+=Sqr(q[i]-t[x].ma[i]);
    }
    return ans;
}
void Query(int x)
{
    if (!x) return;
    int d0=Dis(x),dl=Get(t[x].l),dr=Get(t[x].r);
    if (d0<pq.top().fi)
    {
        pq.pop();
        pq.push(mp(d0,x));
    }
    if (dl<dr)
    {
        if (dl<pq.top().fi)
            Query(t[x].l);
        if (dr<pq.top().fi)
            Query(t[x].r);
    }
    else
    {
        if (dr<pq.top().fi)
            Query(t[x].r);
        if (dl<pq.top().fi)
            Query(t[x].l);
    }
}
int main()
{
    while (scanf("%d%d",&n,&k)!=EOF)
    {
        for (int j=0;j<k;j++)
            t[0].ma[j]=-inf,t[0].mi[j]=inf;
        for (int i=1;i<=n;i++)
            for (int j=0;j<k;j++)
            {
                read(t[i].d[j]);
                t[i].ma[j]=t[i].mi[j]=t[i].d[j];
            }
        root=Build(1,n,0);
        int Q;
        read(Q);
        while (Q--)
        {
            for (int i=0;i<k;i++)
                read(q[i]);
            read(m);
            printf("the closest %d points are:\n",m);
            for (int i=1;i<=m;i++)
                pq.push(mp(inf,0));
            Query(root);
            for (int i=1;i<=m;i++)
                ans[i]=pq.top().se,pq.pop();
            for (int i=m;i;i--)
            {
                for (int j=0;j<k;j++)
                {
                    if (j) printf(" ");
                    printf("%d",t[ans[i]].d[j]);
                }
                printf("\n");
            }
        }
    }
    return 0; 
}
