#include<bits/stdc++.h>
using namespace std;

inline int _(int r=100) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) {
        int l = _(10) , r = _(10);
        printf("%d %d %d %d %d %d\n",_(10),_(),_(),min(l,r),max(l,r),_());
    }
    return 0;
}