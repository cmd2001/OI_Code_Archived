#include<bits/stdc++.h>
using namespace std;
set<int> app;

inline int Rand() {
    return rand() + ( rand() << 16 );
}
inline int _(int r=1e6) {
    return Rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2e5,siz,ful;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) {
        int o = _(3);
        while( !siz && o == 2 ) o = _(3);
        if( o == 1 ) app.insert(++ful) , ++siz , printf("%d %d %d\n",o,_(),_());
        else if( o == 2 ) {
            int ite = _(siz) - 1;
            set<int>::iterator it = app.begin();
            while(ite--) ++it;
            printf("%d %d\n",o,*it) , --siz , app.erase(it);
        } else if( o == 3 ) printf("%d %d %d\n",o,_(),_());
    }
    return 0;
}