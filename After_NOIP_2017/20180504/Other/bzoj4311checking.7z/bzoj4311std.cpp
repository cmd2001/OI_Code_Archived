#include<cstdio>
#include<algorithm>
#include<queue>
#define MAXN 200000
using namespace std;
void Read(int &x){
    static char c;
    while(c=getchar(),c!=EOF)
        if(c>='0'&&c<='9'){
            x=c-'0';
            while(c=getchar(),c>='0'&&c<='9')
                x=x*10+c-'0';
            ungetc(c,stdin);
            return;
        }
}
int n,ocnt,qcnt,bk,tmp[MAXN+10],tmp2[MAXN+10];
long long ans[MAXN+10];
struct point{
    int x,y;
    inline point(){
    }
    inline point(int x,int y):x(x),y(y){
    }
    inline point operator-(const point &b)const{
        return point(x-b.x,y-b.y);
    }
    bool operator<(const point &b)const{
        if(x==b.x)
            return y<b.y;
        return x<b.x;
    }
}Q[MAXN+10],*q[MAXN+10];
inline long long dot(const point &a,const point &b){
    return 1ll*a.x*b.x+1ll*a.y*b.y;
}
inline long long cross(const point &a,const point &b){
    return 1ll*a.x*b.y-1ll*a.y*b.x;
}
struct Ope{
    point x;
    int l,r;
    inline bool operator<(const Ope &b)const{
        return x<b.x;
    }
}cg[MAXN+10];
struct node{
    vector<point*>op;
}tree[MAXN*4+10];
void insert(int i,int l,int r,int ll,int rr,point *a){
    if(ll<=l&&r<=rr){
        tree[i].op.push_back(a);
        return;
    }
    if(ll>r||rr<l)
        return;
    int mid((l+r)>>1);
    insert(i<<1,l,mid,ll,rr,a);
    insert((i<<1)|1,mid+1,r,ll,rr,a);
}
void read(){
    Read(n);
    int i,p,x,y;
    for(i=1;i<=n;i++){
        Read(p),Read(x);
        if(p==1){
            Read(y);
            cg[++ocnt].x=point(x,y);
            cg[ocnt].l=qcnt+1;
            cg[ocnt].r=-1;
        }
        else if(p==2)
            cg[x].r=qcnt;
        else{
            Read(y);
            Q[++qcnt]=point(x,y);
        }
    }
    sort(cg+1,cg+ocnt+1);
    for(i=1;i<=ocnt;i++){
        if(cg[i].r==-1)
            cg[i].r=qcnt;
        if(cg[i].l>cg[i].r)
            continue;
        insert(1,1,qcnt,cg[i].l,cg[i].r,&cg[i].x);
    }
}
void Divide_Conqure(int i,int l,int r){
    if(l==r){
        tmp[l]=l;
        for(vector<point*>::iterator j=tree[i].op.begin();j<tree[i].op.end();j++)
            ans[l]=max(ans[l],dot(Q[l],**j));
        return;
    }
    int mid((l+r)>>1),x,j,k;
    Divide_Conqure(i<<1,l,mid);
    Divide_Conqure((i<<1)|1,mid+1,r);
    x=l,j=mid+1,k=l;
    while(x<=mid||j<=r){
        if(j>r||(x<=mid&&cross(Q[tmp[x]],Q[tmp[j]])<=0))
            tmp2[k++]=tmp[x++];
        else
            tmp2[k++]=tmp[j++];
    }
    bk=0;
    for(x=l;x<=r;x++)
        tmp[x]=tmp2[x];
    for(vector<point*>::iterator v=tree[i].op.begin();v<tree[i].op.end();v++){
        while(bk>1&&cross(*q[bk]-*q[bk-1],**v-*q[bk-1])>=0)
            bk--;
        q[++bk]=*v;
    }
    if(bk){
        for(x=l,j=1;x<=r;x++){
            while(j<bk&&dot(Q[tmp[x]],*q[j+1])>dot(Q[tmp[x]],*q[j]))
                j++;
            ans[tmp[x]]=max(ans[tmp[x]],dot(Q[tmp[x]],*q[j]));
        }
    }
}
void print(){
    int i;
    for(i=1;i<=qcnt;i++)
        printf("%lld\n",ans[i]);
}
int main()
{
    read();
    Divide_Conqure(1,1,qcnt);
    print();
}