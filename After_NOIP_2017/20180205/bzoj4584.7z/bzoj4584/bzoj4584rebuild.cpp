#pragma GCC optimize(3)
#include<bits/stdc++.h>
#define lli long long int
#define debug cout
using namespace std;
const int maxn=1e3+1e2;
const int mod=1e9+7;

int l[maxn],r[maxn],srt[maxn],len;
lli f[2][maxn][maxn],sum[maxn],inv[maxn],ans;
int n;

inline void gen() {
    for(int i=1;i<=n;i++)
        srt[++len] = l[i] , srt[++len] = r[i] + 1;
    sort(srt+1,srt+1+len) , len = unique(srt+1,srt+1+len) - srt - 1;
    for(int i=1;i<=n;i++)
        l[i] = lower_bound(srt+1,srt+1+len,l[i]) - srt ,
        r[i] = lower_bound(srt+1,srt+1+len,r[i]+1) - srt ;
    inv[0] = inv[1] = 1;
    for(int i=2;i<=n;i++) inv[i] = ( mod - mod / i ) * inv[mod%i] % mod;
}
inline void dp() {
    int cur = 0;
    for(int i=0;i<len;i++) sum[i] = 1;
    f[1][0][1] = 1;
    for(int i=1;i<=n;i++) {
        memcpy(f[cur],f[cur^1],sizeof(f[1]));
        for(int j=l[i];j<r[i];j++) {
            for(int k=2;k<=i;k++)
                f[cur][j][k] += f[cur^1][j][k-1] * ( srt[j+1] - srt[j] - k + 1 ) % mod * inv[k] % mod;
            f[cur][j][1] += sum[j-1] * ( srt[j+1] - srt[j] ) % mod;
        }
        for(int j=1;j<len;j++) {
            sum[j] = sum[j-1];
            for(int k=1;k<=i;k++)
                sum[j] = ( sum[j] + f[cur][j][k] ) % mod;
        }
        cur ^= 1;
    }
}
int main() {
    freopen("dat.txt","r",stdin);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",l+i,r+i);
    gen();
    dp();
    ans = ( sum[len-1] - 1 + mod ) % mod;
    printf("%lld\n",ans);
    return 0;
}


