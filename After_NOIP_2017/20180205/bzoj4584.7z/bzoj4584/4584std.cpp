#include <cstdio>
#include <cstring>
#include <algorithm>
#define debug cout
#include<iostream>

using namespace std;

const int N=501,mo=1e9+7;

typedef long long LL;

int n,tot,a[N*2],len[N*2],f[N*2][N],s[N*2],L[N],R[N],Inv[N],cnt[N][N*2];

char c;

int read()
{
    for (c=getchar();c<'0' || c>'9';c=getchar());
    int x=c-48;
    for (c=getchar();c>='0' && c<='9';c=getchar()) x=x*10+c-48;
    return x;
}

int main()
{
    //freopen("dat.txt","r",stdin);
    n=read();
    for (int i=1;i<=n;i++)
    {
        L[i]=read()-1; R[i]=read();
        a[++tot]=L[i]; a[++tot]=R[i];
    }
    sort(a+1,a+tot+1);
    for (int i=1;i<=tot;i++) len[i]=a[i]-a[i-1];
    Inv[1]=1;
    for (int i=2;i<=n;i++) Inv[i]=(LL)Inv[mo%i]*(mo-mo/i)%mo;
    f[0][1]=1;
    for (int i=0;i<=tot;i++) s[i]=1;
    for (int i=1;i<=n;i++)
    {
        int x,y;
        for (x=tot;a[x]!=L[i];x--);
        for (y=1;a[y]!=R[i];y++);
        memcpy(cnt[i],cnt[i-1],sizeof(cnt[i]));
        for (int j=x+1;j<=y;j++)
        {
            cnt[i][j]++;
            for (int k=cnt[i][j];k>1;k--)
            {
                //debug<<"in this"<<endl;
                f[j][k]=(f[j][k]+(LL)f[j][k-1]*(len[j]-k+1)%mo*Inv[k])%mo;
            }
            //debug<<"j = "<<j<<endl<<"f = "<<f[j][1]<<endl;
            f[j][1]=(f[j][1]+(LL)s[j-1]*len[j])%mo;
            //debug<<"new f = "<<f[j][1]<<endl;
        }
        for (int j=x+1;j<=tot;j++)
        {
            s[j]=s[j-1];
            for (int k=cnt[i][j];k;k--) s[j]=(s[j]+f[j][k])%mo;
            //debug<<"j = "<<j<<"s = "<<s[j]<<endl;
        }
        //debug<<"s = "<<s[tot]<<endl;
    }
    s[tot]=(s[tot]-1+mo)%mo;
    printf("%d\n",s[tot]);
    return 0;
}
