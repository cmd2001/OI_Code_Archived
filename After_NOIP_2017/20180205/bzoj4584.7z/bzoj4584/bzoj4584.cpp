#include<bits/stdc++.h>
#define lli long long int
#define debug cout
using namespace std;
const int maxn=1e3+1e2;
const int mod=1e9+7;

int l[maxn],r[maxn],srt[maxn],len;
lli f[maxn][maxn],sum[maxn][maxn],c[maxn][maxn],cp[maxn][maxn],inv[maxn],ans;
int n;

inline lli bru(int n,int m) {
    lli ret = 1;
    for(int i=n;i>n-m;i--) ret = ret * i % mod;
    return ret * inv[m] % mod;
}
inline void gen() {
    for(int i=1;i<=n;i++)
        srt[++len] = l[i] , srt[++len] = r[i] + 1;
    sort(srt+1,srt+1+len) , len = unique(srt+1,srt+1+len) - srt - 1;
    //debug<<"len = "<<len<<endl;
    for(int i=1;i<=n;i++)
        l[i] = lower_bound(srt+1,srt+1+len,l[i]) - srt ,
        r[i] = lower_bound(srt+1,srt+1+len,r[i]+1) - srt ;
    c[0][0] = 1;
    for(int i=1;i<=n;i++) {
        c[i][0] = 1;
        for(int j=1;j<=i;j++)
            c[i][j] = ( c[i-1][j] + c[i-1][j-1] ) % mod;
    }
    /*for(int i=0;i<=n;i++) {
        for(int j=0;j<=i;j++) debug<<c[i][j]<<" ";debug<<endl;
    }*/
    inv[0] = inv[1] = 1;
    for(int i=2;i<=n;i++) inv[i] = ( mod - mod / i ) * inv[mod%i] % mod;
    //for(int i=1;i<=n;i++) debug<<inv[i]<<" ";debug<<endl;
    for(int i=1;i<=n;i++) ( inv[i] *= inv[i-1] ) %= mod;
    for(int i=1;i<len;i++)
        for(int j=1;j<=n;j++)
            cp[i][j] = bru(srt[i+1]-srt[i],j);
    for(int i=1;i<len;i++)
        for(int j=1;j<=n;j++)
            for(int k=0;k<j;k++)
                sum[i][j] = ( sum[i][j] + cp[i][k+1] * c[j-1][k] % mod ) % mod;
    /*for(int i=1;i<len;i++) {
        for(int j=1;j<=n;j++) debug<<cp[i][j]<<" ";debug<<endl;
    }*/
}
inline void dp() {
    for(int i=0;i<len;i++) f[0][i] = 1;
    for(int i=1;i<=n;i++) {
        for(int j=l[i];j<r[i];j++) {
            for(int k=i;k/*&&l[k]<=j&&j<r[k]*/;k--) {
                debug<<"i = "<<i<<"k = "<<k<<endl;
                debug<<"sum = "<<sum[j][i-k+1]<<endl;
                debug<<"add = "<<f[k-1][j-1] * sum[j][i-k+1]<<endl;
                f[i][j] += f[k-1][j-1] * sum[j][i-k+1] % mod;
            }
        }
        for(int j=1;j<len;j++) debug<<f[i][j]<<" ";debug<<endl;
        for(int j=1;j<len;j++)
            f[i][j] = ( f[i][j] + f[i][j-1] ) % mod;
    }
    for(int i=1;i<=n;i++)
        ans = ( ans + f[i][len-1] ) % mod;
    printf("%lld\n",ans);
}
int main() {
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",l+i,r+i);
    gen();
    dp();
    
    return 0;
}


