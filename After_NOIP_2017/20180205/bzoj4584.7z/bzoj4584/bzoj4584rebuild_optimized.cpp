#pragma GCC optimize(3)
#include<cstdio>
#include<algorithm>
#define lli long long int
#define debug cout
const int maxn=1e3+1e2;
const int mod=1e9+7;
 
int l[maxn],r[maxn],srt[maxn],cnt[maxn],len;
lli f[maxn][maxn],sum[maxn],inv[maxn],ans;
int n;
 
inline void gen() {
    for(int i=1;i<=n;i++)
        srt[++len] = l[i] , srt[++len] = r[i] + 1;
    std::sort(srt+1,srt+1+len) , len = std::unique(srt+1,srt+1+len) - srt - 1;
    for(int i=1;i<=n;i++)
        l[i] = std::lower_bound(srt+1,srt+1+len,l[i]) - srt ,
        r[i] = std::lower_bound(srt+1,srt+1+len,r[i]+1) - srt ;
    inv[0] = inv[1] = 1;
    for(int i=2;i<=n;i++) inv[i] = ( mod - mod / i ) * inv[mod%i] % mod;
}
inline void dp() {
    for(int i=0;i<len;i++) sum[i] = 1;
    for(int i=1;i<=n;i++) {
        for(int j=l[i];j<r[i];j++) {
            ++cnt[j];
            for(int k=cnt[j];k-1;k--)
                f[j][k] += f[j][k-1] * ( srt[j+1] - srt[j] - k + 1 ) % mod * inv[k] % mod;
            f[j][1] += sum[j-1] * ( srt[j+1] - srt[j] ) % mod;
        }
        for(int j=l[i];j<len;j++) {
            sum[j] = sum[j-1];
            for(int k=1;k<=cnt[j];k++)
                sum[j] = ( sum[j] + f[j][k] ) % mod;
        }
    }
}
int main() {
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d%d",l+i,r+i);
    gen();
    dp();
    ans = ( sum[len-1] - 1 + mod ) % mod;
    printf("%lld\n",ans);
    return 0;
}
