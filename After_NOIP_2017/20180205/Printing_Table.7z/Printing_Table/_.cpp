#include<bits/stdc++.h>
using namespace std;

inline int _() {
    return rand() % 99+1;
}

int main() {
    static int n = 6;
    while(n--)  printf("%d\n",_());
    return 0;
}
