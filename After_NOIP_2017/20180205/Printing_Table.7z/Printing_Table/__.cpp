#include<bits/stdc++.h>
#define debug cout
using namespace std;
const int maxn=1e3+7;
int me[1010][1010],v[1010][1010];

inline int _(int m,int n) {
    if(v[m][n]) return me[m][n];
    v[m][n] = 1;
    if( !m ) return me[m][n] = ( n + 1 ) % maxn;
    if( !n ) return me[m][n] = _( m - 1 , 1 );
    return me[m][n] = _(m-1,_(m,n-1));
}

int main() {
    for(int i=0;i<=10;i++) {
        for(int j=0;j<=10;j++) debug<<_(i,j)<<" ";
        debug<<endl;
    }
}
