#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    //freopen("dat.txt","w",stdout);
    const int n = 2e5 , k = 1000;
    printf("%d %d\n",n,k);
    for(int i=2;i<=n;i++)
        printf("%d %d %d\n",i-1,_(i-1),(rand()&1)?_(10):0);
    return 0;
}
