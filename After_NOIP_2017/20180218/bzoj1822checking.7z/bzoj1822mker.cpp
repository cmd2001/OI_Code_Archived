#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char);
    static int n = 3 , m = 3 , t = 1;
    printf("%d %d %d\n",n,m,t);
    for(int i=1;i<=n;i++)
        printf("%d %d %d %d\n",_(1e2),_(1e2),_(1e2),_(2e4));
    for(int i=1;i<=m;i++)
        printf("%d %d\n",_(1e2),_(1e2));
    for(int i=1;i<=t;i++)
        printf("%d %d %d\n",_(1e2),_(1e2),_(1e1));
    return 0;
}
