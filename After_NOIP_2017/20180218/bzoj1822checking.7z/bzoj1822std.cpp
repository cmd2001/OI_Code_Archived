#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<cstring>
#define debug cout
#define ll long long 
#define inf 1000000000
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int ans;
int n,m,K,cnt,T;
int d[205],r[205],tim[205],last[405];
int tr[205];
int h[405],q[405],cur[405];
int mp[205][205];
struct edge{
	int to,next,v;
}e[500005];
struct P{
	int x,y;
}w[205],t[205],s[205];
struct L{
	P a,b;
};
void insert(int u,int v,int w)
{
	e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;e[cnt].v=w;
	e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;e[cnt].v=0;
}
inline P operator-(P a,P b)
{
	P t;t.x=a.x-b.x;t.y=a.y-b.y;return t;
}
inline double operator*(P a,P b)
{
	return a.x*b.y-a.y*b.x;
}
inline double dot(P a,P b)
{
	return a.x*b.x+a.y*b.y;
}
inline double dis(P a,P b)
{
	return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
inline double dis(L l,P p)
{
	if(dot(l.a-p,l.b-p)>0)
		return min(dis(l.a,p),dis(l.b,p));
	return abs((p-l.a)*(l.b-l.a)/dis(l.a,l.b));
}
bool jud(int x,int y)//����x�뾫��y
{
	if(dis(w[x],s[y])>r[x])return 0;
	for(int i=1;i<=K;i++)
		if(dis((L){w[x],s[y]},t[i])<tr[i])return 0;
	return 1;
}
void build(int x)
{
	cnt=1;
	for(int i=1;i<=cnt;i++)e[i].v=0;
	T=n+m+1;
	memset(last,0,sizeof(last));
	for(int i=1;i<=n;i++)
		insert(0,i,x/tim[i]+1);
	for(int i=1;i<=m;i++)
		insert(i+n,T,1);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(mp[i][j])insert(i,j+n,1);
}
bool bfs()
{
	int head=0,tail=1;
	for(int i=0;i<=T;i++)h[i]=-1;
	q[0]=0;h[0]=0;
	while(head!=tail)
	{
		int now=q[head];head++;
		for(int i=last[now];i;i=e[i].next)
			if(e[i].v&&h[e[i].to]==-1)
			{
				h[e[i].to]=h[now]+1;
				q[tail++]=e[i].to;
			}
	}
	return h[T]!=-1;
}
int dfs(int x,int f)
{
	if(x==T)return f;
	int w,used=0;
	for(int i=cur[x];i;i=e[i].next)
		if(h[e[i].to]==h[x]+1)
		{
			w=f-used;
			w=dfs(e[i].to,min(w,e[i].v));
			e[i].v-=w;e[i^1].v+=w;
			if(e[i].v)cur[x]=i;
			used+=w;if(used==f)return f;
		}
	if(!used)h[x]=-1;
	return used;
}
void dinic()
{
	while(bfs())
	{
		for(int i=0;i<=T;i++)
			cur[i]=last[i];
		ans+=dfs(0,inf);
	}
}
int main()
{
	int mx=0;
	n=read();m=read();K=read();
	for(int i=1;i<=n;i++)
		w[i].x=read(),w[i].y=read(),r[i]=read(),tim[i]=read(),mx=max(mx,tim[i]);
	for(int i=1;i<=m;i++)
		s[i].x=read(),s[i].y=read();
	for(int i=1;i<=K;i++)
		t[i].x=read(),t[i].y=read(),tr[i]=read();
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++)
		{
			mp[i][j]=jud(i,j);
			debug<<mp[i][j]<<" ";
			if(mp[i][j])d[j]=1;
		}
		debug<<endl;
	}
	for(int i=1;i<=m;i++)
		if(!d[i])
		{
			puts("-1");
			return 0;
		}
	int l=0,r=m*mx,mid;
	while(l<=r)
	{
		mid=(l+r)>>1;
		build(mid);
		ans=0;
		dinic();
		if(ans==m)r=mid-1;
		else l=mid+1;
	}
	printf("%d\n",l);
	return 0;
}
