#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,_(i-1),_(2)-1);
    return 0;
}