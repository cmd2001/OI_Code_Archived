#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define MOD 20110520
#define MAXN 12
#define MAXV 531442
#define gv(x,ps) ((x)/p[(ps)]%3)
#define cd(x,ps) ((x)-((x)/p[ps]%3*p[ps]))
#define sd(x,ps,v) ((x)+v*p[ps])
int n,m;
void pm(int x)
{
        int i;
        for (i=0;i<=m;i++)
        {
                printf("%d",x%3);
                x/=3;
        }
        printf("\n");
}
void deal(int &x,int y)
{
        x=(x+y)%MOD;
}
char mp[104][104];
int dp[2][12][MAXV];
int p[12];
int main()
{
    freopen("dat.txt","r",stdin);
        //freopen("input.txt","r",stdin);
        int i,j,k,x,y,z;
        p[0]=1;
        scanf("%d%d\n",&n,&m);
        for (i=1;i<12;i++)
                p[i]=p[i-1]*3;
        for (i=0;i<n;i++)
        {
                for (j=0;j<m;j++)
                {
                        scanf("%c",&mp[i][j]);
                }
                scanf("\n");
        }
        int l;
        if (n<m)
        {
                for (i=0;i<max(n,m);i++)
                {
                        for (j=i+1;j<max(n,m);j++)
                        {
                                swap(mp[i][j],mp[j][i]);
                        }
                }
                swap(n,m);
        }
        l=p[m+1];
        dp[0][0][0]=1;
        int v;
        for (i=0;i<n;i++)
        {
                for (j=0;j<m;j++)
                {
                        if (j==m-1)//{{{
                        {
                                if (mp[i][j]=='*')
                                {
                                        for (k=0;k<l;k++)
                                        {
                                                if (!dp[i&1][j][k])continue;
                                                x=gv(k,j);
                                                y=gv(k,j+1);
                                                if (x||y)continue;
                                                deal(dp[(i+1)&1][0][k*3],dp[i&1][j][k]);
                                        }
                                        memset(dp[i&1],0,sizeof(dp[i&1]));
                                }else
                                {
                                        for (k=0;k<l;k++)
                                        {
                                                if (!dp[i&1][j][k])continue;
                                                x=gv(k,j);
                                                y=gv(k,j+1);
                                                v=cd(k,j);
                                                v=cd(v,j+1);
                                                if (x==0 && y==0)
                                                {
                                                        z=sd(v,j,1);
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==0 && y==1)
                                                {
                                                        z=sd(v,j,1);
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==0 && y==2)
                                                {
                                                        z=sd(v,j,2);
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                        z=v;
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==1 && y==0)
                                                {
                                                        z=sd(v,j,2);
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==1 && y==1)
                                                {
                                                        z=v;
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==1 && y==2)
                                                {
                                                        //DO nothing
                                                }else if (x==2 && y==0)
                                                {
                                                        z=v;
                                                        deal(dp[(i+1)&1][0][z*3],dp[i&1][j][k]);
                                                }else if (x==2 && y==1)
                                                {
                                                        //Do nothing
                                                }else if (x==2 && y==2)
                                                {
                                                        //Do nothing
                                                }
                                        }
                                        memset(dp[i&1],0,sizeof(dp[i&1]));
                                }
                        }else//}}}
                        {
                                if (mp[i][j]=='*')
                                {
                                        for (k=0;k<l;k++)
                                        {
                                                if (!dp[i&1][j][k])continue;
                                                x=gv(k,j);
                                                y=gv(k,j+1);
                                                if (x||y)continue;
                                                deal(dp[i&1][j+1][k],dp[i&1][j][k]);
                                        }
                                }else
                                {
                                        for (k=0;k<l;k++)
                                        {
                                                if (!dp[i&1][j][k])continue;
                                                x=gv(k,j);
                                                y=gv(k,j+1);
                                                v=cd(k,j);
                                                v=cd(v,j+1);
                                                if (x==0 && y==0)
                                                {
                                                        z=sd(v,j+1,1);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=sd(v,j,1);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=sd(v,j+1,2);
                                                        z=sd(z,j,2);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==0 && y==1)
                                                {
                                                        z=sd(v,j+1,2);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=sd(v,j,1);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==0 && y==2)
                                                {
                                                        z=v;
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=sd(v,j,2);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==1 && y==0)
                                                {
                                                        z=sd(v,j+1,1);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=sd(v,j,2);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==1 && y==1)
                                                {
                                                        z=v;
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==1 && y==2)
                                                {
                                                        //Do nothing
                                                }else if (x==2 && y==0)
                                                {
                                                        z=sd(v,j+1,2);
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                        z=v;
                                                        deal(dp[i&1][j+1][z],dp[i&1][j][k]);
                                                }else if (x==2 && y==1)
                                                {
                                                        //Do nothing
                                                }else if (x==2 && y==2)
                                                {
                                                        //Do nothing
                                                }
                                        }
                                }
                        }
                }
        }
        cout<<dp[n&1][0][0]<<endl;
        return 0;
}