#include<bits/stdc++.h>
using namespace std;

int main() {
    freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char);
    static int n = 10 , m = 10;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) putchar(rand()%16==1?'*':'_');
        puts("");
    }
    return 0;
}