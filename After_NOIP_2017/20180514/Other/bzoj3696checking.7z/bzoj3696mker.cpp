#include<bits/stdc++.h>
using namespace std;

int main() {
    srand((unsigned long long)new char);
    static int n = 500;
    printf("%d\n",n);
    for(int i=1;i<n;i++) printf("%d\n",rand()%i+1);
    return 0;
}