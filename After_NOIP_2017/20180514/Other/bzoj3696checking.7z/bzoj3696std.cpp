#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<set>
#include<iomanip>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<map>
#include<cmath>
using namespace std;
int read()
{
    int x=0;char ch=getchar();
    while(ch<'0'||ch>'9')ch=getchar();
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x;
}
int n,cnt;
int a[100005][505];
int ans[512],last[100005],deep[100005];
struct edge{
	int to,next;
}e[100005];
void insert(int u,int v)
{
	e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;
}
void dfs(int x)
{
	a[x][0]=1;
	for(int i=last[x];i;i=e[i].next)
	{
		dfs(e[i].to);
		for(int j=0;j<=deep[x];j++)
			for(int k=0;k<=deep[e[i].to];k++)
				ans[j^(k+1)]+=a[x][j]*a[e[i].to][k];
		deep[x]=max(deep[x],deep[e[i].to]+1);
		for(int j=0;j<=deep[e[i].to];j++)
			a[x][j+1]+=a[e[i].to][j];
	}
}
int main()
{
	n=read();
	for(int i=2;i<=n;i++)
	{
		int x=read();insert(x,i);
	}
	dfs(1);
	int mx=512;
	for(;mx;mx--)
		if(ans[mx])break;
	for(int i=0;i<=mx;i++)
		printf("%d\n",ans[i]);
	return 0;
}