#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
using namespace std;

typedef long long LL;

const int N=100005;
const int M=205;
const int MOD=10007;

int n,m,cnt,last[N],up[N][M],down[N][M],L,now,A,B,Q,s[M][M],jc[M];
struct edge{int to,next;}e[N*2];

void addedge(int u,int v)
{
    e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;
    e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;
}

void dfs1(int x,int fa)
{
    down[x][0]=1;
    for (int i=last[x];i;i=e[i].next)
    {
        int v=e[i].to;
        if (v==fa) continue;
        dfs1(e[i].to,x);
        down[x][0]+=down[v][0];
        for (int k=1;k<=m;k++) down[x][k]=(down[x][k]+down[v][k]+down[v][k-1])%MOD;
    }
}

void dfs2(int x,int fa)
{
    if (fa)
    {
        up[x][0]=n-down[x][0];
        for (int k=1;k<=m;k++)
        {
            up[x][k]=(up[x][k]+up[fa][k]+up[fa][k-1])%MOD;
            up[x][k]=(up[x][k]+down[fa][k]+down[fa][k-1])%MOD;
            up[x][k]=(up[x][k]-down[x][k]-down[x][k-1])%MOD;
            up[x][k]=(up[x][k]-down[x][k-1])%MOD;
            if (k>1) up[x][k]=(up[x][k]-down[x][k-2])%MOD;
            up[x][k]=(up[x][k]+MOD)%MOD;
        }
    }
    for (int i=last[x];i;i=e[i].next)
        if (e[i].to!=fa) dfs2(e[i].to,x);
}

int main()
{
    /*scanf("%d%d%d%d%d%d%d",&n,&m,&L,&now,&A,&B,&Q);
    for (int i=1;i<n;i++){
        now=(now*A+B)%Q;
        int tmp=i<L?i:L;
        int x=i-now%tmp,y=i+1;
        addedge(x,y);
    }*/
    scanf("%d%d",&n,&m);
    for (int i=1;i<n;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        addedge(x,y);
    }
    s[0][0]=jc[0]=1;
    for (int i=1;i<=m;i++)
    {
        jc[i]=jc[i-1]*i%MOD;
        for (int j=1;j<=i;j++) s[i][j]=(s[i-1][j]*j%MOD+s[i-1][j-1])%MOD;
    }
    dfs1(1,0);
    dfs2(1,0);
    for (int i=1;i<=n;i++)
    {
        int ans=0;
        for (int k=1;k<=m;k++) ans=(ans+(LL)s[m][k]*jc[k]*(up[i][k]+down[i][k])%MOD)%MOD;
        printf("%d\n",ans);
    }
    return 0;
}