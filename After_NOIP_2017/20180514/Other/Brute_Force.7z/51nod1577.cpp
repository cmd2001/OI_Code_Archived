#pragma GCC optimize("Ofast,no-stack-protector")
#pragma GCC optimize("-funsafe-loop-optimizations")
#pragma GCC optimize("-funroll-loops")
#pragma GCC optimize("-fwhole-program")
#include<cstdio>
#include<cstring>
#include<cctype>
#include<algorithm>
#include<cmath>
#define bool unsigned char
typedef unsigned int ui;
const int maxn=5e5+1e2,maxl=31;

ui in[maxn],bel[maxn],bit[maxl],tps[maxl],ed[maxn],top;
bool ans[maxn];
ui n,q;

struct StkNode {
    ui *dst;
    __inline void work() { *dst = 0; }
}stk[maxn];

struct LinearBase {
    ui dat[maxl];
    __inline const ui& operator [] (const ui &x) const { return dat[x]; }
    __inline void insert(ui x) {
        for(ui i=30;~i;i--) if( x & bit[i] ) {
            if( !dat[i] ) return void( dat[i] = x );
            else x ^= dat[i];
        }
    }
    __inline void mem_insert(ui x) {
        for(ui i=30;~i;i--) if( x & bit[i] ) {
            if( !dat[i] ) {
                stk[++top] = (StkNode){dat+i} , dat[i] = x;
                return;
            } else x ^= dat[i];
        }
    }
    __inline bool check(ui x) {
        for(ui i=30;~i;i--) if( x & bit[i] ) {
            if( !dat[i] ) return 0;
            else x ^= dat[i];
        }
        return 1;
    }
    __inline void merge(const LinearBase &r) {
        for(ui i=30;~i;i--) if( r[i] ) insert(r[i]);
    }
    __inline void reset() {
        memset(dat,0,sizeof(dat));
    }
}lb;

struct QueryNode {
    ui l,r,w,id;
    friend bool operator < (const QueryNode &a,const QueryNode &b) {
        return bel[a.l] != bel[b.l] ? bel[a.l] < bel[b.l] : a.r < b.r;
    }
}qs[maxn];

__inline bool force(const ui &l,const ui &r,const ui &w) {
    lb.reset();
    for(ui i=l;i<=r;i++) lb.insert(in[i]);
    return lb.check(w);
}

__inline void init() {
    ui bs = std::max( 1u , (ui) sqrt((unsigned long long)n*n/q) ) , cnt = 0;
    for(ui l=1,r;l<=n;l=r+1) {
        r = std::min( n , l + bs - 1 ) , ed[++cnt] = r;
        for(ui i=l;i<=r;i++) bel[i] = cnt;
    }
}

__inline unsigned char nextchar() {
    static const ui BS = 1 << 18;
    static unsigned char buf[BS],*st,*ed;
    if( st == ed ) ed = buf + fread(st=buf,1,BS,stdin);
    return st == ed ? 0 : *st++;
}
__inline ui getint() {
    ui ret = 0;
    unsigned char ch;
    while( !isdigit(ch=nextchar()) ) ;
    do ret=ret*10+ch-'0'; while( isdigit(ch=nextchar()) );
    return ret;
}

int main() {
    freopen("51nod_Problem_1577_Test_5_In.txt","r",stdin);
    freopen("2333.txt","w",stdout);
    static ui cnt;
    n = getint();
    for(ui *st=in+1,*ed=st+n;st!=ed;*st++=getint());
    for(ui i=0;i<30;i++) bit[i] = 1 << i;
    q = getint() , init();
    for(ui i=1,w,l,r;i<=q;i++) { // ans = 1 means can .
        l = getint() , r = getint() , w = getint();
        if( bel[l] == bel[r] ) ans[i] = force(l,r,w);
        else qs[++cnt] = (QueryNode){l,r,w,i};
    }
    std::sort(qs+1,qs+1+cnt);
    for(ui l=1,r;l<=cnt;l=r+1) {
        for(r=l;r<=cnt&&bel[qs[l].l]==bel[qs[r].l];r++) ;
        lb.reset() , top = 0;
        ui b = ed[bel[qs[l].l]] , rr = b, ll = b + 1;
        for(ui t=l;t<=r;t++) {
            while( rr < qs[t].r ) lb.insert(in[++rr]);
            while( qs[t].l < ll ) lb.mem_insert(in[--ll]);
            ans[qs[t].id] = lb.check(qs[t].w);
            while(top) stk[top--].work();
            ll = b + 1;
        }
    }
    for(ui i=1;i<=q;i++) puts(ans[i]?"YES":"NO");
    return 0;
}
