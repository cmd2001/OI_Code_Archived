#include<bits/stdc++.h>
using namespace std;
const int maxn=3e3+1e1;

int vis[maxn][maxn];

inline int _(int r) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3000 , m = 3000 , t = 400;
    printf("%d %d %d\n",n,m,t);
    while(t--) {
        int x = _(n) , y = _(m);
        while( vis[x][y] ) x = _(n) , y = _(m);
        vis[x][y] = printf("%d %d\n",x,y) , 1;
    }
    return 0;
}
