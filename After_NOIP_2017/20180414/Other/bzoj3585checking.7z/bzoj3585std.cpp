#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define lc(x) t[x].l
#define rc(x) t[x].r
const int N=2e5+5,MX=1e8+5;
inline int read(){
    char c=getchar();int x=0,f=1;
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
int n,Q,a[N],l,r;
struct node{
    int l,r,mn;
}t[N*30];
int sz,root[N];
void ins(int &x,int l,int r,int p,int v){//right of p is v
    t[++sz]=t[x];x=sz;
    if(l==r) t[x].mn=v;
    else{
        int mid=(l+r)>>1;
        if(p<=mid) ins(t[x].l,l,mid,p,v);
        else ins(t[x].r,mid+1,r,p,v);
        t[x].mn=min(t[lc(x)].mn,t[rc(x)].mn);
    }
}
int query(int x,int l,int r,int v){
    if(l==r) return l;
    else{
        int mid=(l+r)>>1;
        if(t[lc(x)].mn<v) return query(t[x].l,l,mid,v);
        else return query(t[x].r,mid+1,r,v);
    }
}
int main(int argc, const char * argv[]) {
    n=read();Q=read();
    for(int i=1;i<=n;i++) a[i]=read(),root[i]=root[i-1],ins(root[i],0,MX,a[i],i);
    while(Q--){
        l=read();r=read();
        printf("%d\n",query(root[r],0,MX,l));
    }
    return 0;
}
