#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
inline void makeseq(int n) {
    for(int i=1;i<=n;i++) printf("%d%c",_(n>>1)-1," \n"[i==n]);
}
inline void makelr(int &l,int &r,int n) {
    l = _(n) , r = _(n);
    if( l > r ) swap(l,r);
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2e5 , m = 2e5;
    printf("%d %d\n",n,m);
    makeseq(n);
    for(int i=1,l,r;i<=m;i++) makelr(l,r,n) , printf("%d %d\n",l,r);
    return 0;
}
