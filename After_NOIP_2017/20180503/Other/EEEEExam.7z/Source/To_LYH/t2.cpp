#include<bits/stdc++.h>
typedef long long int lli;
const int maxn=1e6+1e2,maxe=1e7+1e2;

int n;
lli ans;

struct BinaryIndexTree {
    int dat[maxn];
    #define lowbit(x) (x&-x)
    inline void update(int x,int y) {
        while( x <= n ) dat[x] += y , x += lowbit(x);
    }
    inline int query(int x) {
        int ret = 0; --x;
        while(x) ret += dat[x] , x -= lowbit(x);
        return ret;
    }
}bit;

int cmp = 0;
struct Point {
    int z,x,y;
    friend bool operator < (const Point &a,const Point &b) {
        return !cmp ? a.z < b.z : ( a.x != b.x ? a.x < b.x : a.y < b.y );
    }
}ps[maxn];

inline void solve(int l,int r) {
    if( l == r ) return;
    const int mid = ( l + r ) >> 1;
    solve(l,mid) , solve(mid+1,r);
    cmp = 1 , std::sort(ps+l,ps+mid+1) , std::sort(ps+mid+1,ps+r+1);
    int cl = l , cr = mid + 1;
    while( cl <= mid || cr <= r ) {
        if( cl > mid ) ans += bit.query(ps[cr++].y);
        else if( cr > r ) bit.update(ps[cl++].y,1);
        else if( ps[cl].x <= ps[cr].x ) bit.update(ps[cl++].y,1);
        else ans += bit.query(ps[cr++].y);
    }
    for(int i=l;i<=mid;i++) bit.update(ps[i].y,-1);
}

int main() {
    scanf("%d",&n);
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].z = i; 
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].x = i; 
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].y = i; 
    cmp = 0 , std::sort(ps+1,ps+1+n) , solve(1,n);
    return printf("%lld\n",ans) , 0;
}

