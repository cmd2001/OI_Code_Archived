#include<bits/stdc++.h>
typedef long long int lli;

lli n,cur,ans;

int main() {
    freopen("mst.in","r",stdin);
    freopen("mst.out","w",stdout);
    scanf("%lld",&n) , --n , cur = n;
    for(int i=0;n;n>>=1,i++) {
        if( ( cur = ( cur + ( n & 1 ) ) >> 1 ) & 1 ) ans ^= 1ll << i;
    }
    return printf("%lld\n",ans) , fclose(stdout);
}

