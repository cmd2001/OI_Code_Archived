#include<vector>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
//by:MirrorGray
using namespace std;
const int N=211111;
vector <int> v;
int a[N],cnt[N],mn[N];

int main(){
	int n,m,k;scanf("%d%d%d",&n,&k,&m);
	memset(mn,0x3f,sizeof(mn));
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		cnt[a[i]%m]++;
		mn[a[i]%m]=min(mn[a[i]%m],a[i]);
	}
	int ans=-1;
	for(int i=0;i<=100000;i++)if(cnt[i]>=k){
		if(ans==-1)ans=i;
		else if(mn[i]<mn[ans])ans=i;
	}
	if(~ans){
		puts("Yes");
		for(int i=1;i<=n && k;i++)if(a[i]%m==ans)v.push_back(a[i]);
		sort(v.begin(),v.end());
		for(uint i=0;i<k;i++)printf("%d ",v[i]);
		puts("");
	}
	else puts("No");
	return 0;
}