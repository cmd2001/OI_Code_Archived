#include<bits/stdc++.h>
using namespace std;

int in[(int)(2e6+1e2)];

int main() {
    srand((unsigned long long)new char);
    static int n = 1e6;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) in[i] = i;
    for(int t=3;t;t--) {
        random_shuffle(in+1,in+1+n);
        for(int i=1;i<=n;i++) printf("%d%c",in[i],i!=n?' ':'\n');
    }
    return 0;
}
