#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;
#define pii pair<ll, ll>
#define MP make_pair
#define fir first
#define sec second
#define debug cout
const int N=65;
inline ll read(){
    char c=getchar();ll x=0,f=1;
    while(c<'0'||c>'9'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
    return x*f;
}
 
ll n, m, k, p, mi[N]; int tot;
pii f[N][2][2][2], im;
struct meow{
    int n, a[N];
    int& operator[](int x) {return a[x];}
    void read(ll x) {memset(a,0,sizeof(a));n=0; while(x>0) a[++n]=x&1, x>>=1;}
}a, b, c;
 
inline void mod(ll &x) {if(x>=p) x-=p;}
pii dfs(int d, int s1, int s2, int s3) {
    if(d==0) return MP(1, 0);
    if(f[d][s1][s2][s3] != im) return f[d][s1][s2][s3];
    pii now(0, 0);
    //debug<<"bd = "<<b[d]<<endl;
    int lim1 = s1 ? a[d] : 1, lim2 = s2 ? b[d] : 1, lim3 = s3 ? c[d] : 0;
    //printf("lim1 = %d , lim2 = %d , lim3 = %d\n",lim1,lim2,lim3);
    for(int i=0; i<=lim1; i++)
        for(int j=0; j<=lim2; j++) if((i^j)>=lim3) {
            pii t = dfs(d-1, s1 && i==lim1, s2 && j==lim2, s3 && (i^j)==lim3);
            mod(now.fir += t.fir);
            mod(now.sec += (t.sec + (i^j) * mi[d-1]%p * t.fir%p)%p); 
        }
    //printf("bit = %d , la = %d , lb = %d , lc = %d , f = %lld g = %lld\n",d,s1,s2,s3,now.second,now.fir);
    return f[d][s1][s2][s3]=now;
}
int main() {
    int T=read();
    im=MP(-1, -1);
    while(T--) {
        n=read(); m=read(); k=read(); p=read();
        n--; m--;
        mi[0]=1; for(int i=1; i<=60; i++) mi[i] = (mi[i-1]<<1)%p;
        a.read(n); b.read(m); c.read(k);
        tot=max(a.n, max(b.n, c.n));
        for(int i=0; i<=tot; i++) for(int j=0;j<2;j++) for(int k=0;k<2;k++) f[i][j][k][0]=f[i][j][k][1]=im;
        pii ans = dfs(tot, 1, 1, 1);
        printf("%lld\n", (ans.sec - ans.fir*(k%p)%p + p)%p);
    }
}
