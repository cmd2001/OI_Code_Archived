#include<bits/stdc++.h>
typedef long long int lli;
using namespace std;

inline lli Rand() {
    return rand() | ( rand() << 16 ) | ((lli)rand()<<32) | (lli(rand()<<64));
}

int main() {
    srand((unsigned long long)new char);
    static int T = 10;
    printf("%d\n",T);
    while(T--) printf("%lld %lld %lld %lld\n",Rand(),Rand(),Rand()%1000000000+1);
}
