#include <cstdio>
#include <cstring>
#include <iostream>
char s1[500010],str[1000010];
using namespace std;
int n,len,mx,pos,last,maxx,ans;
int rl[1000010],rs[1000010];
void work()
{
    len=strlen(s1),n=0;
    int i,j,a;
    for(i=0;i<len;i++)   str[n++]='*',str[n++]=s1[i];
    str[n++]='*';
    memset(rs,0,sizeof(rs));
    for(mx=-1,i=0;i<n;i++)
    {
        if(mx>i) rl[i]=min(mx-i+1,rl[2*pos-i]);
        else    rl[i]=1;
        for(;i+rl[i]<n&&rl[i]<=i&&str[i+rl[i]]==str[i-rl[i]];rl[i]++);
        if(mx<i+rl[i]-1) mx=i+rl[i]-1,pos=i;
        rs[i-rl[i]+1]=i+rl[i]-1;
    }
    ans=0,last=maxx=rs[0]+2;
    //for(int i=0;i<n;i++) printf("%d ",rs[i]); puts("");
    for(i=0;i<n;i+=2)
    {
        if(i==last) last=maxx,ans++;
        maxx=max(maxx,rs[i]+2);
    }
    printf("%d\n",ans);
    return ;
}
int main()
{
    while(scanf("%s",s1)!=EOF)  work();
    return 0;
}
