#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2) {
    return rand() % r ;
}

int main() {
    srand((unsigned long long)new char ^ time(0));
    static int T = 5 , n = 5e4;
    while(T--) {
        for(int i=1;i<=n;i++) putchar('a'+_());
        puts("");
    }
}
