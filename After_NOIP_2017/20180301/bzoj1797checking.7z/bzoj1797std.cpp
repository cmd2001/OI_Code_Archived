#include<set>
#include<map>
#include<ctime>
#include<queue>
#include<cmath>
#include<cstdio>
#include<vector>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
#define inf 1000000000
#define pa pair<int,int>
#define ll long long 
using namespace std;
ll read()
{
	ll x=0,f=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int n,m,S,T,cnt=1;
int last[4005],q[4005],h[4005],cur[4005];
int ind,top,scc;
int id[4005],dfn[4005],low[4005];
bool inq[4005];
struct edge{
	int from,to,next,v;
}e[120005];
void insert(int u,int v,int w)
{
	e[++cnt].from=u;e[cnt].to=v;e[cnt].next=last[u];last[u]=cnt;e[cnt].v=w;
	e[++cnt].from=v;e[cnt].to=u;e[cnt].next=last[v];last[v]=cnt;e[cnt].v=0;
}
bool bfs()
{
	int head=0,tail=1;
	for(int i=1;i<=n;i++)h[i]=-1;
	q[0]=S;h[S]=0;
	while(head!=tail)
	{
		int x=q[head];head++;
		for(int i=last[x];i;i=e[i].next)
			if(h[e[i].to]==-1&&e[i].v)
			{
				h[e[i].to]=h[x]+1;
				q[tail++]=e[i].to;
			}
	}
	return h[T]!=-1;
}
int dfs(int x,int f)
{
	if(x==T)return f;
	int w,used=0;
	for(int i=cur[x];i;i=e[i].next)
		if(h[e[i].to]==h[x]+1)
		{
			w=dfs(e[i].to,min(e[i].v,f-used));
			e[i].v-=w;e[i^1].v+=w;
			if(e[i].v)cur[x]=i;
			used+=w;if(used==f)return f;
		}
	if(!used)h[x]=-1;
	return used;
}
int dinic()
{
	int ans=0;
	while(bfs())
	{
		for(int i=1;i<=n;i++)cur[i]=last[i];
		ans+=dfs(S,inf);
	}
	return ans;
}
void tarjan(int x)
{
	dfn[x]=low[x]=++ind;
	q[++top]=x;inq[x]=1;
	for(int i=last[x];i;i=e[i].next)
		if(e[i].v)
		{
			if(!dfn[e[i].to])
			{
				tarjan(e[i].to);
				low[x]=min(low[e[i].to],low[x]);
			}
			else if(inq[e[i].to])
				low[x]=min(dfn[e[i].to],low[x]);
		}
	int now=0;
	if(dfn[x]==low[x])
	{
		scc++;
		while(now!=x)
		{
			now=q[top--];
			id[now]=scc;inq[now]=0;
		}
	}
}
int main()
{
	n=read();m=read();S=read();T=read();
	for(int i=1;i<=m;i++)
	{
		int u=read(),v=read(),w=read();
		insert(u,v,w);
	}
	dinic();
	for(int i=1;i<=n;i++)
		if(!dfn[i])tarjan(i);
	for(int i=2;i<=cnt;i+=2)
		if(e[i].v)puts("0 0");
		else 
		{
			if(id[e[i].from]!=id[e[i].to])
				printf("1 ");
			else printf("0 ");
			if(id[e[i].from]==id[S]&&id[e[i].to]==id[T])
				puts("1");
			else puts("0");
		}
	return 0;
}
