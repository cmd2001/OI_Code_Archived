#include<bits/stdc++.h>
using namespace std;

int n;
inline int _(int r=100) {
    return rand() % r + 1;
}

inline void g(int &x,int &y) {
    x = _(n) , y = _(n);
    while( x == y ) x = _(n) , y = _(n);
}
int main() {
    srand((unsigned long long)new char);
    n = 3;int m = 5 , st , ed ;
    g(st,ed);
    printf("%d %d %d %d\n",n,m,st,ed);
    while(m--) {
        int x,y;
        g(x,y);
        printf("%d %d %d\n",x,y,_());
    }
    return 0;
}
