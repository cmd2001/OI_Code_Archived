#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 1000 , m = 1000 , t = _(n) , p = _(m);
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) {
            if( i == t && j == p ) putchar('1');
            else putchar('0'+(_(32768)==1?1:0));
         }
         puts("");
    }
    return 0;
}
