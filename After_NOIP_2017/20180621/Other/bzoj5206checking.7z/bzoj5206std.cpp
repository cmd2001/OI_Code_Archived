#include <cstdio>
#include <iostream>
#include <algorithm>

using namespace std;

const int N=100010,P=1e9+7;

inline char nc(){
  static char buf[100000],*p1=buf,*p2=buf;
  return p1==p2&&(p2=(p1=buf)+fread(buf,1,100000,stdin),p1==p2)?EOF:*p1++;
}

inline void read(int &x){
  char c=nc(); x=0;
  for(;c>'9'||c<'0';c=nc());for(;c>='0'&&c<='9';x=x*10+c-'0',c=nc());
}

int n,m,cnt,G[N],a[N],b[N],c[N],cl[N],id[N],d[N],vis[N][3],cst[N][3];
struct edge{
  int t,nx,w,c;
}E[N];

inline bool cmp(const int &x,const int &y){
  if(a[x]!=a[y]) return a[x]<a[y];
  if(b[x]!=b[y]) return b[x]<b[y];
  return cl[x]<cl[y];
}

inline void addedge(int x,int y,int w,int c){
  E[++cnt].t=y; E[cnt].nx=G[x]; E[cnt].w=w; E[cnt].c=c; G[x]=cnt;
}

int main(){
  read(n); read(m);
  for(int i=1;i<=m;i++){
    read(a[i]); read(b[i]); read(c[i]); id[i]=i;
    char clr; while((clr=nc())!='R' && clr!='G' && clr!='B');
    cl[i]=(clr=='R'?0:(clr=='G'?1:2));
    if(a[i]>b[i]) swap(a[i],b[i]);
  }
  sort(id+1,id+1+m,cmp); int t=1;
  d[a[id[1]]]++; d[b[id[1]]]++;
  for(int i=2;i<=m;i++){
    if(a[id[i]]==a[id[t]] && b[id[i]]==b[id[t]] && cl[id[i]]==cl[id[t]])
      c[id[t]]=(c[id[t]]+c[id[i]])%P;
    else{
      t++; id[t]=id[i];
      d[a[id[i]]]++; d[b[id[i]]]++;
    }
  }
  m=t;
  for(int i=1;i<=m;i++)
    if(d[a[id[i]]]>d[b[id[i]]]) addedge(b[id[i]],a[id[i]],c[id[i]],cl[id[i]]);
    else addedge(a[id[i]],b[id[i]],c[id[i]],cl[id[i]]);
  int ans=0;
  for(int k=1;k<=m;k++){
    int u=a[id[k]],v=b[id[k]],cc=cl[id[k]],tot=0;
    for(int i=G[u];i;i=E[i].nx)
      if(E[i].c!=cc) vis[E[i].t][E[i].c]=k,cst[E[i].t][E[i].c]=E[i].w;
    for(int i=G[v];i;i=E[i].nx)
      if(E[i].c!=cc && vis[E[i].t][3-cc-E[i].c]==k)
    tot=(tot+1LL*E[i].w*cst[E[i].t][3-cc-E[i].c])%P;
    ans=(ans+1LL*tot*c[id[k]])%P;
  }
  printf("%d\n",ans);
  return 0;
}