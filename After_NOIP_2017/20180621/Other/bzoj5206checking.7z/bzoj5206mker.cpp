#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e6) {
    return rand() % r + 1;
}
char col[]=" RGB";

int main() {
    srand((unsigned long long)new char);
    static int n = 50000 , m = 1e5;
    printf("%d %d\n",n,m);
    while(m--) {
        int a = _(n) , b = _(n);
        while( a == b ) a = _(n) , b = _(n);
        printf("%d %d %d %c\n",a,b,_(),col[_(3)]);
    }
    return 0;
}