#include<iostream>  
#include<cstdio>  
#include<cstring>  
#include<bitset>  
#include<algorithm>  
#define N 30010  
#define M 100010   
using namespace std;  
int point[N],n,m,x,y,t,nxt[M],d[N],q[N],cnt,len[N],end,ans;  
bitset<N>bit[N];  
struct edge{int st,en;}e[M];  
struct use{int en,v;}a[N];  
inline int read(){  
  int x(0);char ch=getchar();  
  while (ch<'0'||ch>'9') ch=getchar();  
  while (ch>='0'&&ch<='9') x=x*10+ch-'0',ch=getchar();  
  return x;   
}    
inline void add(int x,int y){  
   nxt[++cnt]=point[x];point[x]=cnt;  
   e[cnt].st=x;e[cnt].en=y;   
}  
inline bool cmp(use a,use b){  
   return a.v>b.v;  
}  
inline void solve(){  
  int h(0),t(0),num(0);  
  for (int i=1;i<=n;i++) if (!d[i]) q[++t]=i;  
  while (h<t){  
    int u=q[++h];  
    for (int i=point[u];i;i=nxt[i]){  
      d[e[i].en]--;if (!d[e[i].en]) q[++t]=e[i].en;  
    }   
  }   
  for (int i=t;i>=1;i--){  
    int u=q[i];bit[u][u]=1;num=0;len[u]=1;   
    for (int j=point[u];j;j=nxt[j]){  
      a[++num]=use{e[j].en,len[e[j].en]};  
      len[u]=max(len[u],len[e[j].en]+1);    
    }  
    sort(a+1,a+num+1,cmp);  
    for (int j=1;j<=num;j++){  
      int y=a[j].en;//cout<<u<<' '<<y<<endl;  
      if (bit[u][y]) ans++;  
      bit[u]|=bit[y];  
    }     
  }   
}  
int main(){  
  n=read();m=read();  
  for (int i=1;i<=m;i++){  
    x=read();y=read();  
    add(x,y);d[y]++;  
  }  
  solve();  
  cout<<ans<<endl;  
}   
