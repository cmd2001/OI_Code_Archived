#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e8) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5 , m = 1e5;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_()-_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    for(int i=1;i<=m;i++) {
        int o = _(2) , a = _(n) , b = _(n);
        if( o == 2 ) printf("%d %d %d\n",o,a,b);
        else printf("%d %d %d %d\n",o,a,b,_(1e6));
    }
    return 0;
}

