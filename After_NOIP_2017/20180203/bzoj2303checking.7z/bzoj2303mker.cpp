#include<bits/stdc++.h>
using namespace std;

int main() {
    srand((unsigned long long)new char);
    int n = 2 , m = 2 , k = 2;
    printf("%d %d %d\n",n,m,k);
    while( k-- )
        printf("%d %d %d\n",rand()%n+1,rand()%m+1,rand()&1);
    return 0;
}
