#include<iostream>
#include<cstdio>
#include<cstring>
#define mod 1000000000
#define N 2000005
using namespace std;

struct node{ int x,y,z; }a[N]; int n,m,cnt,fa[N],g[N];
int read(){
	int x=0; char ch=getchar();
	while (ch<'0' || ch>'9') ch=getchar();
	while (ch>='0' && ch<='9'){ x=x*10+ch-'0'; ch=getchar(); }
	return x;
}
int getfa(int x){
	if (x==fa[x]) return x;
    int t=getfa(fa[x]);
	g[x]^=g[fa[x]]; return fa[x]=t;
}
int calc(){
	int i,u,v,tmp;
	for (i=1; i<=m+n; i++){ fa[i]=i; g[i]=0; }
	fa[m+1]=1;
	for (i=1; i<=cnt; i++){
		u=getfa(a[i].x); v=getfa(a[i].y+m);
		tmp=g[a[i].x]^g[a[i].y+m]^a[i].z;
		if (u!=v){ fa[u]=v; g[u]=tmp; }
		else if (tmp) return 0;
	}
	int ans=-1;
	for (i=1; i<=m+n; i++)
		if (getfa(i)==i)
			if (ans==-1) {ans=1;} else{
				ans<<=1; if (ans>=mod) ans-=mod;
			}
	return ans;
}
int main(){
	m=read(); n=read(); cnt=read(); int i; bool bo[2]; bo[0]=bo[1]=1;
	for (i=1; i<=cnt; i++){
		a[i].x=read(); a[i].y=read(); a[i].z=read();
		if (a[i].x+a[i].y==2){ bo[a[i].z]=0; i--; cnt--; continue; }
		if (!((a[i].x|a[i].y)&1)) a[i].z^=1;
	}
	int ans=0; if (bo[1]) ans=calc();
	if (bo[0]){
		for (i=1; i<=cnt; i++)
			if (a[i].x>1 && a[i].y>1) a[i].z^=1;
		ans+=calc();
	}
	if (ans>=mod) ans-=mod; printf("%d\n",ans);
	return 0;
}

