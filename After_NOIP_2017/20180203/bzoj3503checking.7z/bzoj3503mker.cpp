#include<bits/stdc++.h>
using namespace std;

inline int _() {
//                  32768
    return rand() % 30000 + 1;
}

int main() {
    srand((unsigned long long)new char);
    const int n = 1e5;
    printf("%d\n",n);
    for(int i=1;i<=n;i++)
        printf("%d%c",_(),i!=n?' ':'\n');
    return 0;
}
