#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
using namespace std;
int n,m,cnt,S,T,ans;
int to[100000],next[100000],cost[100000],flow[100000],dis[300],inq[300],pe[300],pv[300],head[300];
queue<int> q;
int rd()
{
    int ret=0,f=1;  char gc=getchar();
    while(gc<'0'||gc>'9') {if(gc=='-')f=-f;   gc=getchar();}
    while(gc>='0'&&gc<='9')   ret=ret*10+gc-'0',gc=getchar();
    return ret*f;
}
void add(int a,int b,int c,int d)
{
    to[cnt]=b,cost[cnt]=c,flow[cnt]=d,next[cnt]=head[a],head[a]=cnt++;
    to[cnt]=a,cost[cnt]=-c,flow[cnt]=0,next[cnt]=head[b],head[b]=cnt++;
}
int bfs()
{
    int i,u;
    memset(dis,0x3f,sizeof(dis));
    q.push(S),dis[S]=0;
    while(!q.empty())
    {
        u=q.front(),q.pop(),inq[u]=0;
        for(i=head[u];i!=-1;i=next[i])
        {
            if(dis[to[i]]>dis[u]+cost[i]&&flow[i])
            {
                dis[to[i]]=dis[u]+cost[i],pe[to[i]]=i,pv[to[i]]=u;
                if(!inq[to[i]]) inq[to[i]]=1,q.push(to[i]);
            }
        }
    }
    return dis[T]<0x3f3f3f3f;
}
int main()
{
    int i,j,k,a,b,c;
    n=rd(),m=rd();
    S=0,T=2*n+3;
    memset(head,-1,sizeof(head));
    for(i=2;i<=n+1;i++)  add(S,i+n+1,0,1),add(i,T,0,1),add(i+n+1,1,0,m);
    add(1,n+2,0,m);
    for(i=1;i<=n;i++)
        for(j=i+1;j<=n+1;j++)
            add(i+n+1,j,rd(),1<<30);
    while(bfs())
    {
        int mf=1<<30;
        for(i=T;i!=S;i=pv[i])   mf=min(mf,flow[pe[i]]);
        ans+=mf*dis[T];
        for(i=T;i!=S;i=pv[i])   flow[pe[i]]-=mf,flow[pe[i]^1]+=mf;
    }
    printf("%d\n",ans);
    return 0;
}
