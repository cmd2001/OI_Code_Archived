#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e6) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100 , t = _(n);
    printf("%d %d\n",n,t);
    for(int i=n;i;i--)
        for(int j=1;j<=i;j++) printf("%d%c",_(),j!=i?' ':'\n');
    return 0;
}
