#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2) {
    return rand() % r + 1;
}
inline char __() {
    return _() == 1 ? '(' : ')';
}


int main() {
    srand((unsigned long long)new char);
    static int n = 100000 , m = 100000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) putchar(__()); puts("");
    while(m--) {
        int x = _(n) , y = _(n) , t = _(4);
        if( x > y ) swap(x,y);
        if( t == 1 ) printf("R %d %d %c\n",x,y,__());
        else if( t == 2 ) printf("S %d %d\n",x,y);
        else if( t == 3 ) printf("I %d %d\n",x,y);
        else {
            while( ( y - x  + 1 ) & 1 ) {
                x = _(n) , y = _(n) , t = _(4);
                if( x > y ) swap(x,y);
            }
            printf("Q %d %d\n",x,y);
        }
    }
    return 0;
}
