#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r;
}
inline int __(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 40000 , k = _(20000);
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,__(i-1),_());
    printf("%d\n",k);
    return 0;
}
