#include <iostream>  
#include <algorithm>  
#include <cmath>  
#include <cstdio>  
#include <cstring>  
#include <vector>  
using namespace std;  
#define pb push_back  
#define maxn 50000  
struct node  
{  
    int v,l;  
};  
vector<node>g[maxn];  
vector<int>dep;  
int n,k,siz[maxn],nsiz,f[maxn],root,d[maxn],K,ans;  
bool vis[maxn];  
void getroot(int now,int fa)  
{  
    int v;  
    siz[now]=1;f[now]=0;  
    for(int i=0;i<g[now].size();i++)  
    {  
        if((v=g[now][i].v)!=fa && !vis[v])  
        {  
            getroot(v, now);  
            siz[now]+=siz[v];  
            f[now]=max(f[now],siz[v]);  
        }  
    }  
    f[now]=max(f[now],nsiz-siz[now]);  
    if (f[now]<f[root])root = now;  
}  
void getdep(int now,int fa)  
{  
    dep.pb(d[now]);  
    int v;siz[now]=1;  
    for(int i=0;i<g[now].size();i++)  
    {  
        v=g[now][i].v;  
        if(v==fa||vis[v]) continue;  
        d[v]=d[now]+g[now][i].l;  
        getdep(v,now);  
        siz[now]+=siz[v];  
    }  
}  
int calc(int now,int have)  
{  
    dep.clear();d[now]=have;  
    getdep(now,0);  
    sort(dep.begin(),dep.end());  
    int ret=0;  
    for(int l=0,r=dep.size()-1;l<r;)  
    {  
        if(dep[l]+dep[r]<=K)  
        {  
            ret+=r-l;  
            l++;  
        }  
        else r--;  
    }  
    return ret;  
}  
void work(int now)  
{  
    int v;  
    ans+=calc(now,0);  
    vis[now]=1;  
    for(int i=0;i<g[now].size();i++)  
    {  
        v=g[now][i].v;  
        if(!vis[v])  
        {  
            ans-=calc(v,g[now][i].l);  
            f[0]=nsiz=siz[v];  
            getroot(v,root=0);  
            work(root);  
        }  
    }  
}  
int main()  
{  
    int a,b,c;  
    scanf("%d",&n);  
    node tmp;  
    for(int i=1;i<n;i++)  
    {  
        scanf("%d%d%d",&a,&b,&c);  
        tmp.v=b;tmp.l=c;  
        g[a].pb(tmp);  
        tmp.v=a;tmp.l=c;  
        g[b].pb(tmp);  
    }  
    scanf("%d",&K);  
    f[0]=n;  
    getroot(1,root=0);  
    ans = 0;  
    work(root);  
    printf("%d\n", ans);  
    return 0;  
}  
