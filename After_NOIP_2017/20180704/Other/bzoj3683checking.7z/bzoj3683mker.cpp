#include<bits/stdc++.h>
using namespace std;
const int maxn=3e5+1e2;

int deg[maxn];

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 5;
    printf("%d %d\n",n,m);
    for(int i=2,t;i<=n;i++) ++deg[t=_(i-1)] , printf("%d%c",t,i!=n?' ':'\n');
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) {
        int o = min( _(5) , 3 );
        if( o == 3 ) {
            int t;
            do t = _(n); while( !deg[t] );
            printf("Q %d\n",t);
        } else printf("%c %d %d\n",o==2?'M':'S',_(n),_());
    }
    return 0;
}
