#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

const int N=55;
const int M=N*N*2;
const int inf=0x3f3f3f3f;

int n,m,map[N][N],cnt,dis[M],last[M],dx[4]={-1,1,0,0},dy[4]={0,0,-1,1},cur[M],s,t,ans;
struct edge{int to,c,next;}e[M*5];
queue <int> q;

int point(int x,int y,int z)
{
    if (z==1) return (x-1)*m+y;
    else return n*m+(x-1)*m+y;
}

void addedge(int u,int v,int c)
{
    e[++cnt].to=v;e[cnt].c=c;e[cnt].next=last[u];last[u]=cnt;
    e[++cnt].to=u;e[cnt].c=0;e[cnt].next=last[v];last[v]=cnt;
}

bool bfs()
{
    for (int i=s;i<=t;i++) dis[i]=0;
    dis[s]=1;
    while (!q.empty()) q.pop();
    q.push(s);
    while (!q.empty())
    {
        int u=q.front();
        q.pop();
        for (int i=last[u];i;i=e[i].next)
            if (e[i].c&&!dis[e[i].to])
            {
                dis[e[i].to]=dis[u]+1;
                if (e[i].to==t) return 1;
                q.push(e[i].to);
            }
    }
    return 0;
}

int dfs(int x,int maxf)
{
    if (x==t||!maxf) return maxf;
    int ret=0;
    for (int &i=cur[x];i;i=e[i].next)
        if (e[i].c&&dis[e[i].to]==dis[x]+1)
        {
            int f=dfs(e[i].to,min(e[i].c,maxf-ret));
            e[i].c-=f;
            e[i^1].c+=f;
            ret+=f;
            if (maxf==ret) break;
        }
    return ret;
}

void dinic()
{
    while (bfs())
    {
        for (int i=s;i<=t;i++) cur[i]=last[i];
        ans-=dfs(s,inf);
    }
}

int main()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++)
            scanf("%d",&map[i][j]);
    s=0;t=n*m*2+1;cnt=1;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++)
            if (map[i][j]<0)
            {
                int mx=0;
                int p=i,q=j,op=-map[i][j]-1;
                while (1)
                {
                    p+=dx[op];q+=dy[op];
                    if (p<1||p>n||q<1||q>m) break;
                    mx=max(mx,map[p][q]);
                }
                ans+=mx;
                if (op<2) addedge(s,point(i,j,1),inf);
                else addedge(point(i,j,2),t,inf);
                p=i;q=j;
                while (1)
                {
                    int lp=p,lq=q;
                    p+=dx[op];q+=dy[op];
                    if (p<1||p>n||q<1||q>m) break;
                    if (op<2) addedge(point(lp,lq,1),point(p,q,1),mx-max(0,map[lp][lq]));
                    else addedge(point(p,q,2),point(lp,lq,2),mx-max(map[lp][lq],0));
                }
            }
            else addedge(point(i,j,1),point(i,j,2),inf);
    dinic();
    printf("%d\n",ans);
    return 0;
}
