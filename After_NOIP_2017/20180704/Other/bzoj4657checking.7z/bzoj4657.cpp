#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#define debug cout
using namespace std;
const int maxn=2.5e3+1e2,maxe=maxn*55,maxt=55;
const int inf=0x3f3f3f3f;
const int dx[]={0,-1,1,0,0},dy[]={0,0,0,-1,1};
// up down left right .

int st,ed;
namespace NetworkFlow {
    int s[maxn<<1],t[maxe<<3],nxt[maxe<<3],f[maxe<<3];
    int dep[maxn<<1];
    inline void coredge(int from,int to,int flow) {
        static int cnt = 1;
        t[++cnt] = to , f[cnt] = flow , nxt[cnt] = s[from] , s[from] = cnt;
    }
    inline void singledge(int from,int to,int flow) {
        coredge(from,to,flow) , coredge(to,from,0);
    }
    inline bool bfs() {
        memset(dep,-1,sizeof(dep)) , dep[st] = 0;
        queue<int> q; q.push(st);
        while( q.size() ) {
            const int pos = q.front(); q.pop();
            for(int at=s[pos];at;at=nxt[at]) if( f[at] && !~dep[t[at]] ) {
                dep[t[at]] = dep[pos] + 1 , q.push(t[at]);
            }
        }
        return ~dep[ed];
    }
    inline int dfs(int pos,int flow) {
        if( pos == ed ) return flow;
        int ret = 0 , now = 0;
        for(int at=s[pos];at;at=nxt[at]) if( f[at] && dep[t[at]] > dep[pos] ) {
            now = dfs(t[at],min(flow,f[at])) , ret += now , flow -= now , f[at] -= now , f[at^1] += now;
            if( !flow ) return ret;
        }
        if( !ret ) dep[pos] = -1;
        return ret;
    }
    inline int dinic() {
        int ret = 0;
        while( bfs() ) ret += dfs(st,inf);
        return ret;
    }
}

int in[maxt][maxt],n,m;

inline int cov(int x,int y,int tpe) {
    return ( m * ( x - 1 ) + y ) * 2 - 1 + tpe;
}

inline int build_chain(int sx,int sy,int d) {
    #define legal(x,y) ( 0 < x && x <= n && 0 < y && y <= m )
    int mx = -1;
    for(int x=sx,y=sy;legal(x,y);x+=dx[d],y+=dy[d]) if( in[x][y] > 0 ) mx = max( mx , in[x][y] );
    if( !~mx ) return 0; // useless gun .
    for(int x=sx+dx[d],y=sy+dy[d];legal(x,y);sx=x,sy=y,x+=dx[d],y+=dy[d]) if( in[x][y] >= 0 ) {
        if( d <= 2 ) NetworkFlow::singledge(cov(sx,sy,0),cov(x,y,0),mx-max(in[sx][sy],0));
        else NetworkFlow::singledge(cov(x,y,1),cov(sx,sy,1),mx-max(in[sx][sy],0));
    }
    return mx;
    #undef legal
}


int main() {
    static int ans;
    scanf("%d%d",&n,&m) , st = 2 * n * m + 1 , ed = 2 * n * m + 2;
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",in[i]+j);
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++)  {
        if( in[i][j] < 0 ) {
            ans += build_chain(i,j,-in[i][j]);
            if( in[i][j] >= -2 ) NetworkFlow::singledge(st,cov(i,j,0),inf);
            else NetworkFlow::singledge(cov(i,j,1),ed,inf);
        } else NetworkFlow::singledge(cov(i,j,0),cov(i,j,1),inf);
    }
    ans -= NetworkFlow::dinic() , printf("%d\n",ans);
    return 0;
}

