#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r;
}

int main() {
    static int n = 3 , m = 4;
    srand((unsigned long long)new char);
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) printf("%d%c",_()-4,j!=m?' ':'\n');
    return 0;
}
