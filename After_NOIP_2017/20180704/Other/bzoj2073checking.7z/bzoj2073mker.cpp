#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 16 , w = _(300) + 100;
    printf("%d %d\n",w,n);
    while(n--) printf("%d %d\n",_(50),_(100));
    return 0;
}

