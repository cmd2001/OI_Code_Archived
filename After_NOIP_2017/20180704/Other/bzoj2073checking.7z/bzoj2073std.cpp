#include<iostream>
#include<set>
#include<map>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<ctime>
#include<vector>
#include<queue>
#include<algorithm>
#include<cmath>
#define inf 2000000000
#define pa pair<int,int>
#define ll long long 
using namespace std;
ll read()
{
    ll x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int bin[20];
int t[20],w[20],f[65536],tim[65535],sum[65536];
int W,n;
int main()
{
	memset(f,127/3,sizeof(f));
	bin[0]=1;for(int i=1;i<20;i++)bin[i]=bin[i-1]<<1;
	W=read();n=read();
	for(int i=1;i<=n;i++)
		t[i]=read(),w[i]=read();
	for(int i=1;i<bin[n];i++)
		for(int j=1;j<=n;j++)
			if(i&bin[j-1])
			{
				tim[i]=max(tim[i],t[j]);
				sum[i]+=w[j];
			}
	f[0]=0;
	for(int i=1;i<bin[n];i++)
		for(int j=i;j;j=i&(j-1))
			if(sum[j]<=W)f[i]=min(f[i],tim[j]+f[i^j]);
	printf("%d\n",f[bin[n]-1]);
	return 0;
}
