#include<bits/stdc++.h>
using namespace std;

int main() {
    srand((unsigned long long)new char);
    static int n = 50 , m = 10000;
    for(int i=1;i<=m;i++) putchar('0'+rand()%2);
    printf(" %d\n",n);
    for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) printf("%d%c",rand()%(int)1e9,j!=n?' ':'\n');
    return 0;
}