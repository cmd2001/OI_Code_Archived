#include<bits/stdc++.h>
using namespace std;

inline long long Rand() {
    return ( (long long)rand() << 32 ) + ((long long)rand()<<16) + rand();
}
inline int _(int r=1e9) {
    return Rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 50000 , m = 50000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n+m;i++) printf("%d %d\n",-_(),-_());
    return 0;
}
