#include<bits/stdc++.h>
using namespace std;

int n,m;
struct pnt
{
    int x,y;
}a[500010],b[500010];

int cmp(pnt x,pnt y)
{
    return x.x==y.x?x.y<y.y:x.x<y.x;
}
int pre(pnt*a,int size,int type)
{
    sort(a,a+size,cmp);
    static bool del[500010];
    memset(del,0,sizeof(del));
    if(type==0)
    {
        int last=0;
        for(int i=1;i<size;i++)
        {
            if(a[i].y>=a[last].y)
            del[i]=1;
            else
            last=i;
        }
    }
    else
    {
        int last=size-1;
        for(int i=size-2;i>=0;i--)
        {
            if(a[i].y<=a[last].y)
            del[i]=1;
            else
            last=i;
        }
    }
    int nn=0;
    for(int i=0;i<size;i++)
    if(!del[i])
    a[nn++]=a[i];
    return nn;
}
long long get(int x,int y)
{
    if(b[y].x<a[x].x&&b[y].y<a[x].y)
    return 0;
    return (long long)(b[y].x-a[x].x)*(b[y].y-a[x].y);
}
long long wk(int l1,int r1,int l2,int r2)
{
    if(l1==r1)
    return 0;
    int md=l1+r1>>1,hh=l2;
    for(int i=l2+1;i<r2;i++)
    if(get(md,hh)<get(md,i))
    hh=i;
    return max(max(wk(l1,md,l2,hh+1),wk(md+1,r1,hh,r2)),get(md,hh));
}
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=0;i<n;i++)
    {
        scanf("%d%d",&a[i].x,&a[i].y);
    }
    for(int i=0;i<m;i++)
    {
        scanf("%d%d",&b[i].x,&b[i].y);
    }
    n=pre(a,n,0);
    m=pre(b,m,1);
    
    /*puts("");
    for(int i=0;i<n;i++)
    printf("%d %d\n",a[i].x,a[i].y);
    puts("");
    for(int i=0;i<m;i++)
    printf("%d %d\n",b[i].x,b[i].y);
    puts("");*/
    
    printf("%lld",wk(0,n,0,m));
}
