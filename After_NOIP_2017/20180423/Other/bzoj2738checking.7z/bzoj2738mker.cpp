#include<bits/stdc++.h>
using namespace std;

inline int _(int r=32768) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 500 , q = 60000;
    printf("%d %d\n",n,q);
    for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) printf("%d%c",_(),j!=n?' ':'\n');
    for(int i=1,sx,sy,tx,ty,siz;i<=q;i++) {
        sx = _(n) , sy = _(n) , tx = _(n) , ty = _(n);
        if( sx > tx ) swap(sx,tx);
        if( sy > ty ) swap(sy,ty);
        siz = ( tx - sx + 1 ) * ( ty - sy + 1 );
        printf("%d %d %d %d %d\n",sx,sy,tx,ty,_(siz));
    }
}
