#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int read()
{
    int x=0,f=1; char ch=getchar();
    while (ch<'0' || ch>'9') {if (ch=='-')f=-1; ch=getchar();}
    while (ch>='0' && ch<='9') {x=x*10+ch-'0'; ch=getchar();}
    return x*f; 
}
#define maxn 500010
long long ans;
struct EdgeNode{int next,to;}edge[maxn<<1];
int head[maxn],cnt=1;
int n,m,k,t,g[maxn],fa[maxn],father[maxn][21],deep[maxn],dfn[maxn];
struct Node
{
    int x,y,dp,id;
    Node () {}
    Node (int a,int b,int c,int d) {x=a;y=b;dp=c;id=d;}
    bool operator < (const Node & A) const
        {return dp==A.dp?id<A.id:dp>A.dp;}
}tmp[maxn];int tot;
void add(int u,int v) {cnt++;edge[cnt].next=head[u];head[u]=cnt;edge[cnt].to=v;}
void insert(int u,int v) {add(u,v);add(v,u);}
void DFS(int now,int tim)
{
    dfn[now]=tim;
    for (int i=1; i<=20; i++)
        if ((1<<i)<=deep[now]) father[now][i]=father[father[now][i-1]][i-1];
            else break;
    for (int i=head[now]; i; i=edge[i].next)
        if (edge[i].to!=father[now][0])
            {
                deep[edge[i].to]=deep[now]+1;
                father[edge[i].to][0]=now;
                DFS(edge[i].to,tim);
            }
}
int LCA(int x,int y)
{
    if (deep[x]<deep[y]) swap(x,y);
    int dd=deep[x]-deep[y];
    for (int i=0; (1<<i)<=dd; i++)
        if (dd&(1<<i)) x=father[x][i];
    for (int i=20; i>=0; i--)
        if (father[x][i]!=father[y][i])
            x=father[x][i],y=father[y][i];
    if (x==y) return x;
    return father[x][0];
}
int main()
{
    n=read(); m=read(); k=read();
    for (int i=1; i<=n; i++) g[i]=read();
    for (int i=1; i<=n; i++) fa[i]=i;
    for (int x,y,i=1; i<=m; i++) 
        x=read(),y=read(),insert(n+i,fa[x]),insert(n+i,fa[y]),fa[y]=n+i;
    for (int i=n+m; i; i--) if (!father[i][0]) DFS(i,++t);
//    printf("%d\n",t);
    for (int x,y,i=1; i<=k; i++)
        {
            x=read(),y=read();
            if (dfn[x]==dfn[y]) tmp[++tot]=Node(x,y,deep[LCA(x,y)],i);
        }
    sort(tmp+1,tmp+tot+1);
    for (int x,y,cd,i=1; i<=tot; i++) x=tmp[i].x,y=tmp[i].y,cd=min(g[x],g[y]),g[x]-=cd,g[y]-=cd,ans+=(long long)cd;
//    printf("%d\n",tot);
    printf("%lld",(long long)ans<<1);
    return 0;
}
