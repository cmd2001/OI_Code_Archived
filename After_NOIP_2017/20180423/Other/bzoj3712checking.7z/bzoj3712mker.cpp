#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+1e2;

int used[maxn];

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 3 , o = 10;
    printf("%d %d %d\n",n,m,o);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1,x,y;i<=m;i++) {
        x = _(n) , y = _(n);
        while( x == y || used[y] || used[x] ) x = _(n) , y = _(n);
        printf("%d %d\n",x,y) , used[x] = 1;
    }
    for(int i=1,x,y;i<=o;i++) {
        x = _(n) , y = _(n);
        while( x == y ) x = _(n) , y = _(n);
        printf("%d %d\n",x,y);
    }
    return 0;
}
