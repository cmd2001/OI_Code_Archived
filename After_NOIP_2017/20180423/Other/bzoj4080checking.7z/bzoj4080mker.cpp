#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}
inline int __() {
    return _() - _();
}

int main() {
    srand((unsigned long long)new char ^ time(0));
    static int n = 10 , d = 5000;
    printf("%d %d\n",n,d);
    for(int i=1;i<=n;i++) printf("%d %d\n",__(),__());
    return 0;
}
