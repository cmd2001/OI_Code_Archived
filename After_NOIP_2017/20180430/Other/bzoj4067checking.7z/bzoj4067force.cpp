#include<bits/stdc++.h>
#define debug cout
using namespace std;
const int maxn=1e2+1e1;

int n,k,m,p,c[maxn],chain[maxn][maxn],fa[maxn],son[maxn],u[maxn],v[maxn],d[maxn],b[maxn],ans;
int fx[maxn];

inline int calclog() {
    int ret = 0;
    for(int i=1;i<=m;i++) if( fa[i] && fx[i] != fx[fa[i]] ) ++ret;
    return 10 * log(ret+1);
}
inline int calc() {
    int ret = 0 , mul = calclog();
    for(int i=1;i<=m;i++) if( fx[i] ) ret -= c[i];
    for(int i=1;i<=p;i++) if( fx[u[i]] == fx[v[i]] ) ret += !fx[u[i]] ? d[i] * mul : b[i] * mul;
    return ret;
}
inline void dfs(int pos) {
    if( pos > m ) return void(ans=max(ans,calc()));
    fx[pos] = 0 , dfs(pos+1) , fx[pos] = 1 , dfs(pos+1);
}

int main() {
    static double dd;
    scanf("%d%d%d%d%*s",&n,&k,&m,&p);
    for(int i=1;i<=m;i++) scanf("%d",c+i);
    for(int i=1;i<=k;i++) for(int j=1;j<=n;j++) scanf("%d",chain[i]+j) , fa[chain[i][j]] = chain[i][j-1];
    for(int i=1;i<=p;i++) scanf("%d%d%d%lf",u+i,v+i,d+i,&dd) , b[i] = floor( d[i] * dd );
    dfs(1) , printf("%d\n",ans);
    return 0;
}
