#include<bits/stdc++.h>
using namespace std;
const int maxn=1010;

vector<int> pts,rms,lev[maxn];
vector<pair<pair<int,int>,pair<int,double> > > es;
bool vis[maxn][maxn];

inline double __() {
    return (double) rand() / ( rand() + 1 );
}
inline int _(int r=10) {
    return rand() % r + 1;
}

inline int make_edge(const vector<int> &v) {
    //printf("making edge siz = %u\n",v.size());
    int ret = 0 , p;
    memset(vis,0,sizeof(vis));
    for(unsigned i=0;i<v.size();i++) {
        if(i) for(int t=0;t<=i/3;t++) {
            p = _(i) - 1;
            int x = v[i] , y = v[p];
            if( vis[x][y] ) { --t; continue; }
            vis[x][y] = vis[y][x] = 1 , es.push_back(make_pair(make_pair(x,y),make_pair(_(),__()))) , ++ret;
        }
    }
    return ret;
}

int main() {
    srand((unsigned long long)new char);
    //static int n = 2 , k = 3 , m = 8 , p = 0;
    static int n = 50 , k = 4 , m = 1000 , p = 0;
    for(int i=1;i<=n*k;i++) pts.push_back(i);
    for(int i=m;i>n*k;i--) rms.push_back(i);
    random_shuffle(pts.begin(),pts.end()) , random_shuffle(rms.begin(),rms.end());
    for(int i=1;i<=n;i++) for(int j=1;j<=k;j++) lev[i].push_back(pts[k*(i-1)+j-1]);
    for(int i=1;i<=n;i++) p += make_edge(lev[i]);
    for(int i=m;i>n*k;i--) lev[_(n)].push_back(i);
    /*p += make_edge(rms) , */printf("%d %d %d %d Str\n",n,k,m,p);
    for(int i=1;i<=m;i++) printf("%d%c",_(),i!=m?' ':'\n');
    for(int j=1;j<=k;j++) for(int i=1;i<=n;i++) printf("%d%c",pts[k*(i-1)+j-1],i!=n?' ':'\n');
    if( es.size() > 10000 ) random_shuffle(es.begin(),es.end()) , es.resize(10000);
    for(auto g : es ) printf("%d %d %d %0.1lf\n",g.first.first,g.first.second,g.second.first,g.second.second);
    return 0;
}
