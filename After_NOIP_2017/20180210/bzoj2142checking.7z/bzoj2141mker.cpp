#include<bits/stdc++.h>
using namespace std;
bitset<10000> vis;

_(int r) {
    return rand()%r+1;
}
int main() {
    srand((unsigned long long)new char);
    int n = 10 , m = 10;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) {
        int x = _(100);
        //while( vis[x] ) x = _(100);
        vis[x] = 1;
        printf("%d%c",x,i!=n?' ':'\n');
    }
    printf("%d\n",m);
    while( m-- ) {
        int x = _(n) , y = _(n);
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
