#include<bits/stdc++.h>
using namespace std;
const int maxn=8e4+1e2;

vector<pair<int,int> > es;

inline _(int r=1000) {
    return rand() % r + 1;
}
int fa[maxn];
inline int findfa(int x) {
    return fa[x] == x ? x : fa[x] = findfa(fa[x]);
}
inline void merge(int x,int y) {
    fa[findfa(x)] = y;
}
inline void buildcase() {
    int n = 1000 , m = 500 , q = 500 , lim = 2;
    int cnt = m;
    es.clear();
    for(int i=1;i<=n;i++) fa[i] = i;
    printf("%d %d %d\n",n,m,q);
    for(int i=2;i<=n;i++)
        es.push_back(make_pair(i,_(i-1)));
    random_shuffle(es.begin(),es.end());
    for(int i=1;i<=n;i++)
        printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=0;i<m;i++) {
        printf("%d %d\n",es[i].first,es[i].second);
        merge(es[i].first,es[i].second);
    }
    for(int i=1;i<=q;i++) {
        if( ( rand() & 1 ) && cnt < n ) {
            printf("L %d %d\n",es[cnt].first,es[cnt].second);
            merge(es[cnt].first,es[cnt].second);
            ++cnt;
        } else {
            int x = _(n) , y = _(n);
            while( x == y || findfa(x) != findfa(y) ) x=_(n) , y = _(n);
            printf("Q %d %d %d\n",x,y,lim);
        }
    }
}
int main() {
    srand((unsigned long long)new char);
    static int T = 2;
    printf("%d\n",T);
    buildcase();
    return 0;
        
}

