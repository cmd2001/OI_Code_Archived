#include<cstdio>
#include<cstring>
#include<algorithm>
#define Pow 17
using namespace std;
int n,m,T,v[80010],p[80010],a[160010],nxt[160010],root[80010],num[80010],father[80010],deep[80010];
int tot,cnt,size,f[80010][19],anti[80010],lastans,w[80010];
struct segtree{
    int l,r,val;
}t[10000010];
void add(int x,int y){
    tot++;a[tot]=y;nxt[tot]=p[x];p[x]=tot;
}
int comp(int x,int y){return w[x]<w[y];}
int find(int x){
    if (x==father[x]) return x;
    father[x]=find(father[x]);
    return father[x];
}
void insert(int &i,int j,int l,int r,int x){
    i=++size;t[i]=t[j];t[i].val++;
    if (l==r) return;
    int mid=(l+r)>>1;
    if (x<=mid) insert(t[i].l,t[j].l,l,mid,x);
    else insert(t[i].r,t[j].r,mid+1,r,x);
}
void dfs(int u,int fa){
    deep[u]=deep[fa]+1;
    for (int i=1;i<=Pow;i++)
      f[u][i]=f[f[u][i-1]][i-1];
    insert(root[u],root[fa],1,cnt,v[u]);
    for (int i=p[u];i!=0;i=nxt[i])
      if (a[i]!=fa){
          f[a[i]][0]=u;
          dfs(a[i],u);
      }
}
int find_lca(int x,int y){
    if (deep[x]!=deep[y]){
        if (deep[x]<deep[y]) swap(x,y);
        for (int i=Pow;i>=0;i--)
          if (deep[f[x][i]]>=deep[y])
            x=f[x][i];
    }
    for (int i=Pow;i>=0;i--)
      if (f[x][i]!=f[y][i]){
          x=f[x][i];y=f[y][i];
      }
    while (x!=y){
        x=f[x][0];y=f[y][0];
    }
    return x;
}
int query(int i,int j,int lca,int flca,int l,int r,int k){
    if (l==r) return l;
    int mid=(l+r)>>1,val;
    val=t[t[i].l].val+t[t[j].l].val-t[t[lca].l].val-t[t[flca].l].val;
    if (k<=val) return query(t[i].l,t[j].l,t[lca].l,t[flca].l,l,mid,k);
    else return query(t[i].r,t[j].r,t[lca].r,t[flca].r,mid+1,r,k-val);
}
int main()
{
    scanf("%d",&T);
    scanf("%d%d%d",&n,&m,&T);
    for (int i=1;i<=n;i++){
        scanf("%d",&w[i]);p[i]=i;
    }
    sort(p+1,p+n+1,comp);
    for (int i=1;i<=n;i++){
        if (w[p[i]]==w[p[i-1]])
          v[p[i]]=cnt;
        else v[p[i]]=++cnt;
       anti[cnt]=w[p[i]];
    }
    for (int i=1;i<=n;i++){
        father[i]=i;num[i]=1;
    }
    memset(p,0,sizeof(p));
    for (int i=1;i<=m;i++){
        int x,y,r1,r2;
        scanf("%d%d",&x,&y);
        add(x,y);add(y,x);
        r1=find(x);r2=find(y);
        if (r1!=r2){
            father[r2]=r1;
            num[r1]+=num[r2];
        }
    }
    for (int i=1;i<=n;i++)
      if (deep[i]==0){
          int rt=find(i);
          dfs(rt,0);
      }
    for (int i=1;i<=T;i++){
        char c=getchar();
        int x,y,k,lca;
        while (c!='L'&&c!='Q') c=getchar();
        scanf("%d%d",&x,&y);
        //x^=lastans;y^=lastans;
        if (c=='Q'){
            scanf("%d",&k);
            //k^=lastans;
            lca=find_lca(x,y);
            lastans=query(root[x],root[y],root[lca],root[f[lca][0]],1,cnt,k);
            lastans=anti[lastans];
            printf("%d\n",lastans);
        }else{
            int r1,r2;
            add(x,y);add(y,x);//ÿ�ζ�Ҫ�ӱ��Ա��´α���
            r1=find(x);r2=find(y);
            if (num[r1]<num[r2]){
                swap(x,y);swap(r1,r2);
            }
            father[r2]=r1;num[r1]+=num[r2];
            f[y][0]=x;dfs(y,x);
        }
    }
    return 0;
}
