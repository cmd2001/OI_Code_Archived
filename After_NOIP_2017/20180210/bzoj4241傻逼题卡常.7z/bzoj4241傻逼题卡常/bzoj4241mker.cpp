#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli lrand() {
    return rand() ^ ( (lli)rand()<<15) ^ ((lli)rand()<<31);
}
inline int _(int r=1e9) {
    return lrand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    int n = 1e5 , q = 1e5;
    printf("%d %d\n",n,q);
    for(int i=1;i<=n;i++)
        printf("%d%c",rand() + 99999,i!=n?' ':'\n');
    while(q--) {
        int x = _(n) , y = _(n);
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
