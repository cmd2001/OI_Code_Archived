#include <cstdio>

namespace Pal
{
    const int siz = 1000005;
    int next[siz][26];
    int fail[siz];
    int cnt[siz];
    int len[siz];
    int str[siz];
    int last;
    int tot;
    int n;
    
    inline int node(int l)
    {
        len[tot] = l;
        return tot++;
    }
    
    inline void init(void)
    {
        node(0);
        node(-1);
        last = 0;
        str[0] = -1;
        fail[0] = 1;
    }
    
    inline int getFail(int t)
    {
        while (str[n - len[t] - 1] != str[n])
            t = fail[t];
        return t;
    }
    
    inline void insert(int c)
    {
        str[++n] = c;
        int cur = getFail(last), now;
        if (!next[cur][c])
        {
            now = node(len[cur] + 2);
            fail[now] = next[getFail(fail[cur])][c];
            next[cur][c] = now;
        }
        ++cnt[last = next[cur][c]];
    }
    
    inline void count(void)
    {
        for (int i = tot - 1; ~i; --i)
            cnt[fail[i]] += cnt[i];
    }
    
    inline long long answer(void)
    {
        long long ret = 0;
        
        for (int i = tot - 1; i > 1; --i)
            if (ret < (long long)len[i] * cnt[i])
                ret = (long long)len[i] * cnt[i];
                
        return ret;
    }
}

const int siz = 300005;

char s[siz];

signed main(void)
{
    scanf("%s", s);
    
    Pal::init();
    
    for (char *t = s; *t; ++t)
        Pal::insert(*t - 'a');
        
    Pal::count();
    
    printf("%lld\n", Pal::answer());
}
