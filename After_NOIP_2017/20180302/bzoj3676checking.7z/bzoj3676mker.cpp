#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2) {
    return rand() % r;
}

int main() {
    static int n = 3e5;
    srand((unsigned long long)new char);
    for(int i=1;i<=n;i++) putchar('a'+_());
    puts("");
    return 0;
}
