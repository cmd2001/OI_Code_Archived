#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 100;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    printf("%d\n",m);
    while(m--) {
        if( m - 1 & 1 ) puts("G");
        else printf("C %d\n",_(n));
    }
    return 0;
}
