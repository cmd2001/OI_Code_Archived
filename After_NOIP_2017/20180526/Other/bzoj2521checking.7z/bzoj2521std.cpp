#include<iostream>  
#include<cstdio>  
#include<cstring>  
#include<cmath>  
#include<algorithm>  
#include<queue>  
#define N 20000  
using namespace std;  
int n,m,id;  
int tot,point[N],nxt[N],remain[N],v[N],num[N],deep[N],cur[N],last[N];  
struct data  
{  
    int x,y,w;  
    int pd;  
}a[N];  
int cmp(data a,data b)  
{  
    return a.w<b.w||a.w==b.w&&a.pd<b.pd;  
}  
void add(int x,int y,int z)  
{  
    tot++; nxt[tot]=point[x]; point[x]=tot; v[tot]=y; remain[tot]=z;  
    tot++; nxt[tot]=point[y]; point[y]=tot; v[tot]=x; remain[tot]=0;  
}  
int addflow(int s,int t)  
{  
    int now=t,ans=1000000000;  
    while(now!=s)  
    {  
        ans=min(ans,remain[last[now]]);  
        now=v[last[now]^1];  
    }  
    now=t;  
    while(now!=s)  
    {  
        remain[last[now]]-=ans;  
        remain[last[now]^1]+=ans;  
        now=v[last[now]^1];  
    }  
    return ans;  
}  
void dfs(int s,int t)  
{  
    for (int i=1;i<=n;i++)  
        deep[i]=n;  
    queue<int> p;  
    deep[t]=0; p.push(t);  
    while(!p.empty())  
    {  
        int now=p.front(); p.pop();  
        for (int i=point[now];i!=-1;i=nxt[i])  
            if (deep[v[i]]==n&&remain[i^1])  
            deep[v[i]]=deep[now]+1,p.push(v[i]);  
    }  
}  
int isap(int s,int t)  
{  
    dfs(s,t);  
    for (int i=1;i<=n;i++)  cur[i]=point[i];  
    for (int i=1;i<=n;i++)  num[deep[i]]++;  
    int now=s,ans=0;  
    while(deep[s]<n)  
    {  
        if (now==t)  
            {  
            ans+=addflow(s,t);  
            now=s;  
            }  
        bool f=false;  
        for (int i=point[now];i!=-1;i=nxt[i])  
            if (deep[v[i]]+1==deep[now]&&remain[i])  
            {  
            f=true;  
            cur[now]=i;  
            last[v[i]]=i;  
            now=v[i];  
            break;  
            }  
        if (!f)  
        {  
            int minn=n;  
            for (int i=point[now];i!=-1;i=nxt[i])  
                if (remain[i])  minn=min(minn,deep[v[i]]);  
            if (!--num[deep[now]]) break;  
            deep[now]=minn+1;  
            num[deep[now]]++;  
            cur[now]=point[now];  
            if (now!=s)  
                now=v[last[now]^1];  
        }  
    }  
    return ans;  
}  
int main()  
{  
    scanf("%d%d%d",&n,&m,&id);  
    tot=-1;  
    memset(nxt,-1,sizeof(nxt));  
    memset(point,-1,sizeof(point));  
    int wid=0;  
    for (int i=1;i<=m;i++)  
        {  
        scanf("%d%d%d",&a[i].x,&a[i].y,&a[i].w);  
        if (i==id) a[i].pd=1,wid=a[i].w;  
        else a[i].pd=0;  
        }  
    sort(a+1,a+m+1,cmp);  
    int now=0;  
    for (int i=1;i<=m;i++)  
        {  
        if (a[i].pd==1)   
            {  
                now=i;  
                break;  
            }  
        add(a[i].x,a[i].y,wid-a[i].w+1);  
        add(a[i].y,a[i].x,wid-a[i].w+1);  
        }  
    printf("%d\n",isap(a[now].x,a[now].y));  
}  