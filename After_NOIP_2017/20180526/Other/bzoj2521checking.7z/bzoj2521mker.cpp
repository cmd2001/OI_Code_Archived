#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e6) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long )new char);
    int n = 500 , m = 800 , tar = _(m);
    printf("%d %d %d\n",n,m,tar);
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,_(i-1),_());
    for(int i=n,x,y,w;i<=m;i++) {
        x = _(n) , y = _(n) , w = _();
        while( x == y ) x = _(n) , y = _(n);
        printf("%d %d %d\n",x,y,w);
    }
    return 0;
}