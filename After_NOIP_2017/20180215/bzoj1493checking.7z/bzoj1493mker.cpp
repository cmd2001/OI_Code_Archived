#include<bits/stdc++.h>
using namespace std;

int main() {
    srand((unsigned long long)new char);
    int n = 10 , m = 10;
    printf("%d %d\n",n,0);
    for(int i=1;i<=n;i++) printf("%d%c",rand()%10+1,i!=n?' ':'\n');
    printf("%d\n",m);
    for(int i=1;i<=m;i++) {
        int t = rand() % 6;
        if( t == 0 ) printf("R %d\n",rand()%(n-1)+1);
        else if( t == 1 ) printf("F\n");
        else if( t == 2 ) printf("S %d %d\n",rand()%n+1,rand()%n+1);
        else if( t == 3 ) printf("P %d %d %d\n",rand()%n+1,rand()%n+1,rand()%10+1);
        else if( t == 4 ) printf("C\n");
        else if( t == 5 ) printf("CS %d %d\n",rand()%n+1,rand()%n+1);
    }
    return 0;
}
