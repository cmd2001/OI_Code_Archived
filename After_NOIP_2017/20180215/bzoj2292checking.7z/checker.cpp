#include<bits/stdc++.h>
using namespace std;

int main() {
    static int cse = 0;
    while( 1 ) {
        printf("Making Data\n");
        system("bzoj2292mker.exe > dat.txt");
        printf("Data Made\n");
        printf("Running Mine\n");
        system("bzoj2292.exe < dat.txt > my.txt");
        printf("Running std\n");
        system("bzoj2292std.exe < dat.txt > std.txt");
        if( system("diff my.txt std.txt") ) {
            puts("====================!!!WA!!!===================");
            getchar() , getchar();
        }
    }
}
