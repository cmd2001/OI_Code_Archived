#include<bits/stdc++.h>  
using namespace std;  
int read(){  
    int x=0,f=1;char ch=getchar();  
    while (ch<'0'||ch>'9'){if (ch=='-') f=-1;ch=getchar();}  
    while (ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+ch-'0';ch=getchar();}  
    return x*f;  
}  
const int   
    N=100005,  
    M=1000005;  
int Ecnt,n,m;  
int dist[N];  
bool vis[N];  
struct Heap{int num,val;};  
#define qq(a,b) (Heap){a,b}  
priority_queue<Heap,vector<Heap> >Q;  
bool operator <(Heap x,Heap y){return x.val>y.val;}  
struct Edge{  
    int next,to,val;  
}E[M];int head[N];  
  
void add(int u,int v,int w){  
    E[++Ecnt].next=head[u];  
    E[Ecnt].to=v;  
    E[Ecnt].val=w;  
    head[u]=Ecnt;  
}  
void dijkstra(int s,int t){  
    memset(vis,0,sizeof(vis));  
    memset(dist,100,sizeof(dist));  
    dist[s]=0;  
    Q.push(qq(s,0));  
    while ((!Q.empty())){  
        Heap mi=Q.top();Q.pop();  
        if (vis[mi.num]) continue;  
        vis[mi.num]=1;  
        for (int j=head[mi.num];j;j=E[j].next){  
            int q=E[j].to;  
            if (vis[q]) continue;  
            if (E[j].val+mi.val<dist[q]){  
                dist[q]=E[j].val+mi.val;  
                Q.push(qq(q,dist[q]));  
            }  
        }  
    }  
}  
int main() {
    scanf("%d%d",&n,&m);  
    int x,y,z;  
    while (m--){  
        scanf("%d%d%d",&x,&y,&z);  
        add(x,y,z);  
    }  
    dijkstra(1,n);  
    printf("%d\n",dist[n]);  
    return 0;  
}  
