#include<bits/stdc++.h>
using namespace std;

vector<pair<pair<int,int>,int> > v;
int main() {
    const int n = 1e5 , m = 1e6;
    for(int i=2;i<=n;i++) v.push_back(make_pair(make_pair(rand()%(i-1)+1,i),(rand()&1)+1));
    for(int i=n;i<=m;i++) v.push_back(make_pair(make_pair(rand()%n+1,rand()%n+1),(rand()&1)+1));
    printf("%d %d\n",n,m);
    random_shuffle(v.begin(),v.end());
    for(int i=0;i<m;i++)
        printf("%d %d %d\n",v[i].first.first,v[i].first.second,v[i].second);
    return 0;
}
