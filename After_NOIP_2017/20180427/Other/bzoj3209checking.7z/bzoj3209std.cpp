#include<iostream>  
#include<cstring>  
#include<cstdio>  
#define P 10000007  
#define ll long long  
ll f[100][100],g[100][100],n;  
using namespace std;  
ll power(ll a,ll b){  
  ll ans(1);  
  for (ll i=b;i;i>>=1,(a*=a)%=P) if (i&1) (ans*=a)%=P;  
  return ans;     
}  
ll cal(ll x){  
  ll t(0),c(0),ans(1);  
  for (t=0;1ll<<t<=x;t++);  
  for (;t;t--){  
    if ((1ll<<t-1)&x){  
      for (int i=1;i<=t;i++)  
        (ans*=power(i+c,f[t][i]))%=P;
      if (c)(ans*=c)%=P;c++;  
    }     
  }  
  return (ans*c)%P;  
}  
int main(){  
  scanf("%lld",&n);  
  f[1][0]=1;g[1][1]=1;  
  for (int i=2;i<=60;i++)  
    for (int j=0;j<=i;j++){  
     f[i][j]=(f[i-1][j]+g[i-1][j]);  
     if (j!=0)g[i][j]=(f[i-1][j-1]+g[i-1][j-1]);  
    }  
  printf("%lld",cal(n));  
}  
