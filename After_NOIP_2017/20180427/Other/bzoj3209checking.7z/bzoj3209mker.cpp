#include<bits/stdc++.h>
typedef long long int lli;
using namespace std;

inline lli Rand() {
    #ifdef WIN32
    return rand() | ( rand() << 16 ) | ((lli)rand()<<32) | ((lli)rand()<<48);
    #endif
    return rand();
}
inline lli _(lli r=1000000000000000ll) {
    return Rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    printf("%lld\n",_());
    return 0;
}
