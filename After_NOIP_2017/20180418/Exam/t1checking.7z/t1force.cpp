#include<bits/stdc++.h>
#define debug cout
using namespace std;
const int maxn=1e2+1e1,maxe=1e4+1e2;

int in[maxn],n,ans;
int x[maxe],y[maxe],c[maxe],cnt;

int main() {
    scanf("%d",&n);
    for(int i=1;i<=n;i++) scanf("%d",in+i);
    for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) if( in[i] == in[j] ) x[++cnt] = i , y[cnt] = j , c[cnt] = in[i];
    //for(int i=1;i<=cnt;i++) debug<<x[i]<<" "<<y[i]<<" "<<c[i]<<endl;
    for(int i=1;i<=cnt;i++) for(int j=i+1;j<=cnt;j++) if( x[i] < x[j] && y[i] < y[j] && y[i] > x[j] && c[i] != c[j] ) ++ans;
    printf("%d\n",ans);
    return 0;
}
