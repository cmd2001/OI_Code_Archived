#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    return 0;
}
