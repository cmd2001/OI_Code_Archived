#include<bits/stdc++.h>
using namespace std;

int base[100010];
int main() {
    srand((unsigned long long)new char);
    int n = 1e4 , m = 1e4 , q = 4;
    printf("%d %d %d\n",n,m,q);
    for(int i=0;i<m;i++)
        base[i+1] = i % n + 1;
    random_shuffle(base+1,base+1+m);
    while( m-- )
        printf("%d %d %d\n",base[m+1],rand()%n+1,rand()%1000+1);
    return 0;
}
