#include<bits/stdc++.h>
using namespace std;

inline int _(int r=32768) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1000000;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",_()+2147440879,i!=n?' ':'\n');
    return 0;
}
