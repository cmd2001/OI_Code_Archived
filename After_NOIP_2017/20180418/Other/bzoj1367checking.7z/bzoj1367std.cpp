#include<cstdio>
#include<vector>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#define LL long long
using namespace std;
const int maxn=1000000+10;
struct LeftIstTree{
    struct treenode{
        int v,l,r,d;
        treenode(){d=l=r=v=0;}
        bool operator<(const treenode&a)const{return v<a.v;}
    };
    treenode T[maxn];
    int merge(int a,int b){
        if(a==0||b==0)return a+b;
        if(T[a]<T[b])swap(a,b);
        T[a].r=merge(T[a].r,b);
        if(T[T[a].l].d<T[T[a].r].d)swap(T[a].l,T[a].r);
        T[a].d=T[a].r?T[T[a].r].d+1:0;
        return a;
    }
    int root[maxn],m,size[maxn];
    void solve(int n){
        T[0].d=-1;
        for(int i=1;i<=n;i++){
            scanf("%d",&T[i].v);
            T[i].v-=i; root[++m]=i; size[m]=1;
            while(m>1&&T[root[m]].v<T[root[m-1]].v){
                int k=size[m]&size[m-1]&1;
                root[m-1]=merge(root[m-1],root[m]);
                if(k)root[m-1]=merge(T[root[m-1]].l,T[root[m-1]].r);
                size[m-1]+=size[m]; m--;
            }
        }
        int cur=1; LL ans=0;
        //printf("cnt = %d\n",m);
        //for(int i=1;i<=m;i++) printf("%d ",size[i]); puts("");
        for(int i=1;i<=m;i++)
            for(int j=1;j<=size[i];j++,cur++)ans+=abs(T[root[i]].v-T[cur].v) ;//, printf("root = %d\n",T[root[i]].v);
        printf("%lld\n",ans);
    }
}Left_Ist_Tree;

int main(){
    int n; scanf("%d",&n);
    Left_Ist_Tree.solve(n);
}
