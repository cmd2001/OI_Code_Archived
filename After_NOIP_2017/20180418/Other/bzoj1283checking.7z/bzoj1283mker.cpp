#include<bits/stdc++.h>
using namespace std;

inline int _(int r=20000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1000 , m = 500 , k = 40;
    printf("%d %d %d\n",n,m,k);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    return 0;
}