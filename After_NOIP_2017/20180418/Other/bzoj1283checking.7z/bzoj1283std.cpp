#include <cstdio>
#include <cstring>
#include <queue>
#define N 1500
#define M 30000
#define inf 0x3f3f3f3f
using namespace std;
queue<int> q;
int head[N] , to[M] , val[M] , cost[M] , nxt[M] , cnt = 1 , s , t , dis[N] , from[N] , pre[N];
void add(int x , int y , int v , int c)
{
    to[++cnt] = y , val[cnt] = v , cost[cnt] = c , nxt[cnt] = head[x] , head[x] = cnt;
    to[++cnt] = x , val[cnt] = 0 , cost[cnt] = -c , nxt[cnt] = head[y] , head[y] = cnt;
}
bool spfa()
{
    int x , i;
    memset(from , -1 , sizeof(from));
    memset(dis , 0x3f , sizeof(dis));
    dis[s] = 0 , q.push(s);
    while(!q.empty())
    {
        x = q.front() , q.pop();
        for(i = head[x] ; i ; i = nxt[i])
            if(val[i] && dis[to[i]] > dis[x] + cost[i])
                dis[to[i]] = dis[x] + cost[i] , from[to[i]] = x , pre[to[i]] = i , q.push(to[i]);
    }
    return ~from[t];
}
int mincost()
{
    int ans = 0 , i , k;
    while(spfa())
    {
        k = inf;
        for(i = t ; i != s ; i = from[i]) k = min(k , val[pre[i]]);
        ans += k * dis[t];
        for(i = t ; i != s ; i = from[i]) val[pre[i]] -= k , val[pre[i] ^ 1] += k;
    }
    return ans;
}
int main()
{
    int n , m , k , i , x;
    scanf("%d%d%d" , &n , &m , &k) , s = 0 , t = n - m + 3;
    add(s , 1 , k , 0) , add(n - m + 2 , t , k , 0);
    for(i = 1 ; i <= n - m + 1 ; i ++ ) add(i , i + 1 , inf , 0);
    for(i = 1 ; i <= n ; i ++ )
    {
        scanf("%d" , &x);
        if(i <= m) add(1 , i + 1 , 1 , -x);
        else if(i > n - m) add(i - m + 1 , n - m + 2 , 1 , -x);
        else add(i - m + 1 , i + 1 , 1 , -x);
    }
    printf("%d\n" , -mincost());
    return 0;
}