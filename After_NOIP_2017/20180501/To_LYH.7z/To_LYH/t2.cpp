#include<bits/stdc++.h>
typedef long long int lli;
const int maxn=1e5+1e2,maxe=1e7+1e2;

int n;
lli ans;

struct SegmentTree {
    int lson[maxe],rson[maxe],sum[maxe],cnt;
    inline void insert(int &pos,int l,int r,const int &tar) {
        if( !pos ) pos = ++cnt;
        ++sum[pos];
        if( l == r ) return;
        const int mid = ( l + r ) >> 1;
        tar <= mid ? insert(lson[pos],l,mid,tar) : insert(rson[pos],mid+1,r,tar);
    }
    inline int query(int pos,int l,int r,const int &ll,const int &rr) {
        if( !pos || ( ll <= l && r <= rr ) ) return sum[pos];
        const int mid = ( l + r ) >> 1;
        if( rr <= mid ) return query(lson[pos],l,mid,ll,rr);
        else if( ll > mid ) return query(rson[pos],mid+1,r,ll,rr);
        else return query(lson[pos],l,mid,ll,rr) + query(rson[pos],mid+1,r,ll,rr);
    }
}sgt;

struct BinaryIndexTree {
    int rt[maxn];
    #define lowbit(x) (x&-x)
    inline void update(int x,int y) {
        while( x <= n ) sgt.insert(rt[x],1,n,y) , x += lowbit(x);
    }
    inline int query(int x,int y) {
        int ret = 0; --x , --y;
        while( x ) ret += sgt.query(rt[x],1,n,1,y) , x -= lowbit(x);
        return ret;
    }
}bit;

struct Point {
    int z,x,y;
    friend bool operator < (const Point &a,const Point &b) {
        return a.z < b.z;
    }
}ps[maxn];

int main() {
    scanf("%d",&n);
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].z = i; 
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].x = i; 
    for(int i=1,t;i<=n;i++) scanf("%d",&t) , ps[t].y = i; 
    std::sort(ps+1,ps+1+n);
    for(int i=1;i<=n;i++) ans += bit.query(ps[i].x,ps[i].y) , bit.update(ps[i].x,ps[i].y);
    return printf("%lld\n",ans) , 0;
}

