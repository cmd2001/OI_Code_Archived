#include<bits/stdc++.h>
const int maxe=1e6+1e2;

std::vector<int> v[maxe];

int main() {
    static int n,m,k,t,sel=-1;
    scanf("%d%d%d",&n,&k,&m) , assert(m&&m<=1e6);
    while(n--) scanf("%d",&t) , v[t%m].push_back(t);
    for(int i=0;i<m;i++) {
        if( v[i].size() ) std::sort(v[i].begin(),v[i].end() );
        if( (signed) v[i].size() >= k && ( !~sel || v[sel].begin() > v[i].begin() ) ) sel = i;
    }
    if( !~sel ) return puts("NO"),0;
    puts("YES");
    for(int i=0;i<k;i++) printf("%d%c",v[sel][i],i!=k-1?' ':'\n');
    return 0;
}
