#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    static int n = 100 , m = 100;
    printf("%d %d\n",n,m);
    srand((unsigned long long)new char);
    while(m--) {
        int x = _(n) , y = _(n);
        if( x > y ) swap(x,y);
        printf("%d %d %d\n",_(2),x,y);
    }
    return 0;
}