#include<bits/stdc++.h>
#define debug cout
typedef long long int lli;
using namespace std;
const int maxn=1e5+1e2;
const lli mul = 1e13+1e10;

lli ina[maxn],inb[maxn],f[maxn],ff[maxn],add,ans,sel,lst;
lli stk[maxn],cst[maxn],id[maxn];
int n,top;

int main() {
    freopen("dat.wa3.txt","r",stdin);
    scanf("%d",&n) , add = (lli) n * ( n + 1 ) >> 1;
    for(int i=1;i<=n;i++) scanf("%lld",ina+i) , ina[i] -= i;
    for(int i=1;i<=n;i++) {
        scanf("%lld",inb+i);
        if( ina[i] >= 0 ) {
            stk[++top] = ina[i] , id[top] = i ,  cst[top] = mul - inb[i] - ina[i] * ( n - i + 1 ) ;
        }
    }
    for(int i=1;i<=top;i++) {
        for(int j=0;j<i;j++)
            if( stk[j] <= stk[i] ) f[i] = max( f[i] , f[j] + stk[j] * ( n - id[i] + 1 ) );
        f[i] += cst[i] , ans = max( ans , f[i] );
    }
    ans -= add;
    sel = ( ans + mul ) / mul;
    lst = mul * sel - ans;
    printf("%lld %lld\n",sel,lst);
    return 0;
}

/*
6
10 19 16 15 16 20
7 17 6 19 6 1

6
10 1 1 15 16 20
7 17 6 19 6 1

5
4959 899 6588 21781 21292
2547 20011 5320 24661 21494

*/
