#include<bits/stdc++.h>
#define debug cerr

namespace Maker {
    typedef long long int lli;
    inline void init() {
        srand(((unsigned long long)new char)^time(0));
    }
    inline lli Rand() {
        lli ret = rand();
        ret ^= (lli) rand() << 16 ,
        ret ^= (lli) rand() << 31 ,
        ret ^= (lli) rand() << 45 ;
        return ret;
    }
    inline lli _(int r) {
        return rand() % r + 1;
    }
    inline lli _(int l,int r) {
        return rand() % ( r - l + 1 ) + l;
    }
    inline void rerand(int &x) {
        x = _(0.9*x,x);
    }
    inline void makeseq(int n,int r) {
        for(int i=1;i<=n;i++) printf("%lld%c",_(r),i!=n?' ':'\n');
    }
    inline void makeseq(int n,int l,int r) {
        for(int i=1;i<=n;i++) printf("%lld%c",_(l,r),i!=n?' ':'\n');
    }
    
    FILE *tin,*tout;
    inline void topen(const char* s) {
        tin = fopen(s,"r");
    }
    inline void tread(int &x) {
        fscanf(tin,"%d",&x);
    }
    
    char ss[1000];
    inline void outopen(const char* s) {
        tout = fopen(s,"w");
        int len = strlen(s);
        memcpy(ss,s,sizeof(char)*len);
    }
    inline void twrite(const int &x) {
        fprintf(tout,"%d\n",x);
    }
    inline void tflush() {
        static char com[1000];
        fclose(tout) , sprintf(com,"del %s",ss);
        system(com);
        tout = fopen(ss,"w");
    }
    inline void tclose() {
        fclose(tout);
    }
}
