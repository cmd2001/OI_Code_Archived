#include<bits/stdc++.h>
#define maxn 100010
#define ll long long
using namespace std;

struct pnt{
    ll x,y;
    pnt(ll _x=0,ll _y=0){
        x=_x,y=_y; 
    }
    friend bool operator <(const pnt &lhs,const pnt &rhs){
        return lhs.x<rhs.x;
    }
};
struct data{
    int a,b,idx;
    ll g,f;
}ds[maxn],c[maxn];
int a[maxn],b[maxn],n,len=0;
ll ans=0;//f[i]������i����С���ۣ�����1~iѡiΪ��β��LIS����g[i]��1~i��LIS���� 
const ll INF=1LL<<60;
set<pnt> st;
set<pnt>::iterator it,itl,itr;
inline bool cmpa(const data &lhs,const data &rhs){
    return lhs.a-lhs.idx<rhs.a-rhs.idx;
}
inline bool cmpidx(const data &lhs,const data &rhs){
    return lhs.idx<rhs.idx;
}
inline ll crs(pnt a,pnt b,pnt std){
    return (a.x-std.x)*(b.y-std.y)-(a.y-std.y)*(b.x-std.x);
}
inline ll getslp(pnt a,pnt b){
    return (b.y-a.y)/(b.x-a.x);
}
void Insert(pnt x){
    if(st.size()<=1){
        st.insert(x);
        return;
    }
    itl=st.lower_bound(x);
    if(itl==st.begin()){
        itr=itl,++itr;
        while(itr!=st.end()&&crs(*itl,*itr,x)<=0)
            st.erase(*itl),itl=itr,++itr;
        st.insert(x);
        return;
    }
    else if(itl==st.end()){
        --itl,itr=itl,--itl;
        while(1){
            if(itl==st.begin()){        
                if(crs(*itl,*itr,x)<=0)
                    st.erase(*itr);
                break;
            }
            if(crs(*itl,*itr,x)<=0)
                st.erase(*itr),itr=itl,itl--;
            else
                break;
        }
        st.insert(x);
        return;
    }
    else{
        itr=itl,--itl;
        if(crs(x,*itr,*itl)>=0)
            return;
        --itl,--itr;
        while(1){
            if(itl==st.begin()){        
                if(crs(*itl,*itr,x)<=0)
                    st.erase(*itr);
                break;
            }
            if(crs(*itl,*itr,x)<=0)
                st.erase(*itr),itr=itl,itl--;
            else
                break;
        }
        itl=st.lower_bound(x);
        itr=itl,++itr;
        while(itr!=st.end()&&crs(*itl,*itr,x)<=0)
            st.erase(*itl),itl=itr,++itr;
        st.insert(x);
    }
}
ll query(int slp){
    if(st.size()==1){
        pnt tmp=*(st.begin());
        return tmp.y+tmp.x*slp;
    }
    ll l=0,r=1LL<<30;
    ll ret=INF;
    while(l<r){
        int mid=l+r>>1;
        pnt tmp=pnt(mid,0);
        it=st.lower_bound(tmp);
        if(it==st.end())
            --it;
        else if(it==st.begin())
            ++it,++it;
        itl=it,--itl;
        ret=min(ret,itl->y+itl->x*slp);
        if(getslp(*itl,*it)<=slp)
            l=mid+1;
        else
            r=mid;
    }
    pnt tmp=*(st.begin());
    ret=min(ret,tmp.y+tmp.x*slp);
    it=st.end(),--it,tmp=*it;
    ret=min(ret,tmp.y+tmp.x*slp);
    return ret;
}
void solve(int l,int r){
    if(l==r)
        return;
    int mid=l+r>>1;
    solve(l,mid);
    sort(ds+l,ds+mid+1,cmpa),sort(ds+mid+1,ds+r+1,cmpa);
    int L=l-1;
    ll g=-INF;
    st.clear(),st.insert(pnt(0,0));
    for(int R=mid+1;R<=r;R++){
        while(L<mid&&ds[L+1].a-ds[L+1].idx<=ds[R].a-ds[R].idx){
            L++;
            if(ds[L].g>g){
                g=ds[L].g,st.clear();
                int k=ds[L].idx,a=ds[L].a;
                Insert(pnt(2*a-2*k,2*ds[L].f-1LL*(2*a-k)*(k+1)));
            }
            else if(ds[L].g==g){
                int k=ds[L].idx,a=ds[L].a;
                Insert(pnt(2*a-2*k,2*ds[L].f-1LL*(2*a-k)*(k+1)));
            }   
        }
        int i=ds[R].idx;
        ll upd=1LL*i*(i-1)/2+query(i)/2+ds[R].a+ds[R].b;
        if(ds[R].g<g+1||(ds[R].g==g+1&&ds[R].f>upd))
            ds[R].g=g+1,ds[R].f=upd; 
    }
    sort(ds+l,ds+r+1,cmpidx);
    solve(mid+1,r);
}
int main(){
//  freopen("tst.in","r",stdin);
freopen("dat.wa3.txt","r",stdin);
    int b;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&ds[i].a),ds[i].idx=i,ds[i].g=-INF,ds[i].f=INF;
    for(int i=1;i<=n;i++)
        scanf("%d",&ds[i].b);
    solve(0,n);
    for(int i=1;i<=n;i++){
        if(ds[i].g>len||(ds[i].g==len&&ds[i].f+1LL*(n-i)*(ds[i].a+1+ds[i].a+n-i)/2<ans))
            len=ds[i].g,ans=ds[i].f+1LL*(n-i)*(ds[i].a+1+ds[i].a+n-i)/2;
    }
    printf("%d %lld\n",len,ans);
    return 0;
} 
