#include"mker.hpp"
using namespace std;
using namespace Maker;

int main() {
    static int n = 10;
    init();
    printf("%d\n",n);
    makeseq(n,3,1e8) , makeseq(n,1e3,1e8);
    return 0;
}
