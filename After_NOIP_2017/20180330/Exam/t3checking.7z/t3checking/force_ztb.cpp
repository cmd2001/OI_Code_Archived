#include<bits/stdc++.h>
#define maxn 5010
#define ll long long
using namespace std;

int n;
ll a[maxn],b[maxn],f[maxn],g[maxn];
int main(){
//  freopen("tst.in","r",stdin);]
freopen("dat.wa3.txt","r",stdin);
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%lld",&a[i]);
    for(int i=1;i<=n;i++)
        scanf("%lld",&b[i]);
    memset(g,0xcf,sizeof(g)),memset(f,0x3f,sizeof(f));
    g[0]=f[0]=0;
    for(int i=1;i<=n;i++){
        for(int j=0;j<i;j++){
            if(a[j]-j>a[i]-i)
                continue;
            if(g[j]+1>g[i])
                g[i]=g[j]+1,f[i]=(a[j]+1+a[j]+i-j-1)*(i-j-1)/2+f[j]+a[i]+b[i];
            else if(g[j]+1==g[i])
                f[i]=min(f[i],(a[j]+1+a[j]+i-j-1)*(i-j-1)/2+f[j]+a[i]+b[i]);
        }
    }
    int len=0;
    ll ans=0;
    for(int i=1;i<=n;i++){
        if(g[i]>len)
            len=g[i],ans=f[i]+1LL*(n-i)*(a[i]+1+a[i]+n-i)/2;
        else if(g[i]==len)
            ans=min(ans,f[i]+1LL*(n-i)*(a[i]+1+a[i]+n-i)/2);
    }
    printf("%d %lld\n",len,ans);
    return 0;
}
