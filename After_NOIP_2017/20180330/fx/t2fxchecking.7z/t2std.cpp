#include <cstdio>
#include <cstring>
#include <iostream>
#include <queue>
#define debug cout
using namespace std;
const int maxn=10010;
const int maxm=100010;
int n,m,cnt;
int to[maxm],nxt[maxm],val[maxm],head[maxn],d[maxn],s[maxn],pa[maxm],pb[maxm],pc[maxm];
long double ans;
long double p[maxn],f[maxn];
queue<int> q;
inline void add(int a,int b,int c)
{
    to[cnt]=b,val[cnt]=c,nxt[cnt]=head[a],head[a]=cnt++;
}
inline int rd()
{
    int ret=0,f=1;  char gc=getchar();
    while(gc<'0'||gc>'9') {if(gc=='-')    f=-f;   gc=getchar();}
    while(gc>='0'&&gc<='9')   ret=ret*10+(gc^'0'),gc=getchar();
    return ret*f;
}
int main()
{
    n=rd(),m=rd();
    int i,u,a,b,c;
    memset(head,-1,sizeof(head)),cnt=0;
    for(i=1;i<=m;i++)    a=pa[i]=rd()+1,b=pb[i]=rd()+1,c=pc[i]=rd(),add(b,a,c),s[a]+=c,d[a]++;
    for(i=1;i<=n;i++)    if(!d[i])   q.push(i);
    while(!q.empty())
    {
        u=q.front(),q.pop();
        for(i=head[u];i!=-1;i=nxt[i])
        {
            d[to[i]]--,f[to[i]]+=(f[u]+1)*val[i]/s[to[i]];
            if(!d[to[i]])   q.push(to[i]);
        }
    }
    memset(head,-1,sizeof(head)),cnt=0;
    for(i=1;i<=m;i++)    add(pa[i],pb[i],pc[i]),d[pb[i]]++;
    p[1]=1;
    for(i=1;i<=n;i++)    if(!d[i])   q.push(i);
    while(!q.empty())
    {
        u=q.front(),q.pop();
        for(i=head[u];i!=-1;i=nxt[i])
        {
            d[to[i]]--,p[to[i]]+=p[u]*val[i]/s[u];
            if(!d[to[i]])   q.push(to[i]);
        }
    }
    ans=f[1];
    for(i=1;i<=m;i++)
    {
        a=pa[i],b=pb[i],c=pc[i];
        long double g=(f[a]-(f[b]+1)*c/s[a])*s[a]/(s[a]-c)-f[a];
        //debug<<"g = "<<g<<endl;
        ans=max(ans,f[1]+g*p[a]);
    }
    //for(int i=1;i<=n;i++) debug<<f[i]<<" "<<p[i]<<endl;
    printf("%0.6Lf",ans);
    return 0;
}
