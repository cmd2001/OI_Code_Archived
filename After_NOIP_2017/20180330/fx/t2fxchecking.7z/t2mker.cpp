#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
vector<pair<int,int> > v;
vector<int> len;

int main() {
    srand((unsigned long long)new char);
    static int n = 5;
    for(int i=2;i<=n;i++) {
        int lim = _(i-1);
        for(int j=1;j<=lim*0.9;j++) v.push_back(make_pair(_(i-1),i)) , len.push_back(_(10));
    }
    printf("%d %llu\n",n,v.size());
    for(unsigned i=0;i<v.size();i++) printf("%d %d %d\n",v[i].first-1,v[i].second-1,len[i]);
    return 0;
}

