#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+1e2;

int main() {
    srand((unsigned long long)new char);
    static int n = 10000 , dat[maxn];
    printf("10\n");
    for(int i=1;i<=10;i++) {
        printf("%d\n",n);
        for(int i=1;i<=n;i++) dat[i] = i;
        //random_shuffle(dat+1,dat+1+n);
        for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    }
    return 0;
}
