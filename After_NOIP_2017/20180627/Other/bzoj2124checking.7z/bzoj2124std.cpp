#include<algorithm>
#include<iostream>
#include<cstdlib>
#include<cstring>
#include<cstdio>
#include<vector>
#include<queue>
#include<cmath>
#include<set>
#include<map>
#define N 50550
#define ll unsigned long long
using namespace std;
int sc()
{
    int i=0,f=1;char c=getchar();
    while(c>'9'||c<'0'){if(c=='-')f=-1;c=getchar();}
    while(c>='0'&&c<='9')i=i*10+c-'0',c=getchar();
    return i*f;
}
ll t[N][2],bin[N];
int n,a[N],flag;
void change(int x,int l,int r,int p)
{
    if(l==r)
    {
        t[x][0]=t[x][1]=233;
        return;
    }
    int mid=l+r>>1;
    if(p<=mid)change(x<<1,l,mid,p);
    else change(x<<1|1,mid+1,r,p);
    t[x][0]=t[x<<1][0]*bin[r-mid]+t[x<<1|1][0];
    t[x][1]=t[x<<1|1][1]*bin[mid-l+1]+t[x<<1][1];
}
ll ask(int x,int L,int R,int l,int r,int d)
{
    if(L==l&&R==r)return t[x][d];
    int mid=L+R>>1;
    if(r<=mid)return ask(x<<1,L,mid,l,r,d);
    else if(l>mid)return ask(x<<1|1,mid+1,R,l,r,d);
    else if(d==0) return ask(x<<1,L,mid,l,mid,d)*bin[r-mid]+ask(x<<1|1,mid+1,R,mid+1,r,d);
    else if(d==1) return ask(x<<1|1,mid+1,R,mid+1,r,d)*bin[mid-l+1]+ask(x<<1,L,mid,l,mid,d);
}
void solve(int x)
{
    int L=min(x-1,n-x);
    change(1,1,n,x);
    if(x==1||x==n)return;
    ll ls=ask(1,1,n,x-L,x-1,0);
    ll rs=ask(1,1,n,x+1,x+L,1);
    if(ls!=rs)flag=1;
}
int main()
{
    bin[0]=1;for(int i=1;i<=10000;i++)bin[i]=bin[i-1]*233;
    int T=sc();
    while(T--)
    {
        memset(t,0,sizeof(t));
        flag=0;n=sc();
        for(int i=1;i<=n;i++)
        {
            int x=sc();
            if(!flag)solve(x);
        }
        if(flag)puts("Y");else puts("N");
    }
    return 0;
}