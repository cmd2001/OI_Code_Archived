#include<bits/stdc++.h>
using namespace std;

int _(int r) {
    return rand()%r+1;
}

int main() {
    srand((unsigned long long)new char);
    int n = 500 , m = 2000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++)
        if( i & 1 ) printf("-1 ");
        else printf("%lld ",(long long)rand()*rand()%100000000+900000000);
    puts("");
    while( m-- )
        printf("%d %d\n",_(n),_(n));
    return 0;
}
