#include<iostream>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<cmath>
#define ll long long
#define inf 1000000000 
using namespace std;
inline int read()
{
    int x=0,f=1;char ch=getchar();
    while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
ll ans1,ans2;
int bin[35];
int n,m,cnt,T;
int a[505],u[2005],v[2005],val[505];
int h[505],q[505],cur[505],last[505];
bool mark[505];
struct edge{
    int to,next,v;
}e[200005];
void insert(int u,int v,int w)
{
//	cout<<u<<' '<<v<<' '<<w<<endl;
    e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;e[cnt].v=w;
    e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;e[cnt].v=0;
}
void dfs(int x)
{
	mark[x]=1;
	for(int i=last[x];i;i=e[i].next)
		if(e[i^1].v&&!mark[e[i].to])dfs(e[i].to);
}
bool bfs()
{
    int head=0,tail=1;
    for(int i=0;i<=T;i++)h[i]=-1;
    q[0]=0;h[0]=0;
    while(head!=tail)
    {
        int now=q[head];head++;
        for(int i=last[now];i;i=e[i].next)
            if(h[e[i].to]==-1&&e[i].v)
            {
                h[e[i].to]=h[now]+1;
                q[tail++]=e[i].to;
            }
    }
    return h[T]!=-1;
}
int dfs(int x,int f)
{
    if(x==T)return f;
    int w,used=0;
    for(int i=cur[x];i;i=e[i].next)
        if(h[e[i].to]==h[x]+1)
        {
            w=dfs(e[i].to,min(e[i].v,f-used));
            e[i].v-=w;e[i^1].v+=w;
            if(e[i].v)cur[x]=i;
            used+=w;if(used==f)return f;
        }
    if(!used)h[x]=-1;
    return used;
}
int dinic()
{
	int tmp=0;
    while(bfs())
    {
        for(int i=0;i<=T;i++)
            cur[i]=last[i];
        tmp+=dfs(0,inf);
    }
	return tmp;
}
void build(int x)
{
//	cout<<endl;
	cnt=1;T=n+1;
	memset(last,0,sizeof(last));
	for(int i=1;i<=n;i++)
		if(a[i]>=0)
		{
			if(a[i]&x)insert(i,T,inf);
			else insert(0,i,inf);
		}
	for(int i=1;i<=m;i++)
	{
		insert(u[i],v[i],1);
		insert(v[i],u[i],1);
	}
}
int main()
{
	bin[0]=1;for(int i=1;i<=30;i++)bin[i]=bin[i-1]<<1;
	n=read();m=read();
	for(int i=1;i<=n;i++)
		a[i]=read();
	for(int i=1;i<=m;i++)
		u[i]=read(),v[i]=read();
	for(int i=0;i<=30;i++)
	{
		build(bin[i]);
		ans1+=(ll)bin[i]*dinic();
		memset(mark,0,sizeof(mark));
		dfs(T);
		for(int j=1;j<=n;j++)
		{
			if(mark[j])val[j]+=bin[i];
		}
	}
	printf("%lld\n",ans1);
	for(int i=1;i<=n;i++)
		if(a[i]>0)ans2+=a[i];
		else ans2+=val[i];
	printf("%lld\n",ans2);
	return 0;
}
