#include<bits/stdc++.h>
using namespace std;

int base[100010],qs[1000],pts[1000];
int main() {
    srand((unsigned long long)new char);
    int n = 5 , m = 10 , q = 5;
    printf("%d %d %d\n",n,m,q);
    for(int i=0;i<m;i++)
        base[i+1] = i % n + 1;
    random_shuffle(base+1,base+1+m);
    while( m-- )
        printf("%d %d %d\n",base[m+1],rand()%n+1,rand()%10+1);
    for(int i=1;i<=q;i++)
        qs[i] = (i-1) % (q>>1) + 1 ,
        pts[i] = i;
    random_shuffle(qs+1,qs+1+q);
    random_shuffle(pts+1,pts+1+q);
    for(int i=1;i<=q;i++)
        printf("%d %d\n",qs[i],pts[i]);
    return 0;
}
