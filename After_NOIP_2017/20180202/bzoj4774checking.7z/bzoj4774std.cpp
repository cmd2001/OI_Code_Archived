#include <cstdio>  
#include <cctype>  
#include <cstring>  
#include <queue>  
#define N 10010  
using namespace std;  
  
struct side{  
    int to,w,nt;  
}s[N<<1];  
queue <int> que;  
int n,m,d,x,y,w,num,h[N],f[N][260],INF,sum,ans[260];  
bool b[N];  
  
inline char nc(){
    return getchar();
    static char ch[100010],*p1=ch,*p2=ch;  
    return p1==p2&&(p2=(p1=ch)+fread(ch,1,100010,stdin),p1==p2)?EOF:*p1++;  
}  
  
inline void read(int &a){  
    static char c=nc();int f=1;  
    for (;!isdigit(c);c=nc()) if (c=='-') f=-1;  
    for (a=0;isdigit(c);a=a*10+c-'0',c=nc());  
    a*=f;return;  
}  
  
inline void add(int x,int y,int w){  
    s[++num]=(side){y,w,h[x]},h[x]=num;  
    s[++num]=(side){x,w,h[y]},h[y]=num;  
}  
  
inline void calc(){  
    memset(f,0x3f,sizeof f),INF=f[0][0],num=0;  
    for (int i=1; i<=d; ++i) f[i][1<<num++]=0;  
    for (int i=n-d+1; i<=n; ++i) f[i][1<<num++]=0;  
    sum=(1<<num)-1;  
}  
  
inline int min(int a,int b){  
    return a<b?a:b;  
}  
  
inline void spfa(int opt){  
    while (!que.empty()){  
        int p=que.front();que.pop(),b[p]=0;  
        for (int i=h[p]; i; i=s[i].nt)  
            if (f[s[i].to][opt]>f[p][opt]+s[i].w){  
                f[s[i].to][opt]=f[p][opt]+s[i].w;  
                if (!b[s[i].to]) que.push(s[i].to),b[s[i].to]=1;  
            }  
    }  
}  
  
inline void work(){  
    for (int opt=0; opt<=sum; ++opt){  
        for (int i=1; i<=n; ++i){  
            for (int sub=opt; sub; sub=(sub-1)&opt)  
                f[i][opt]=min(f[i][opt],f[i][sub]+f[i][opt^sub]);  
            if (f[i][opt]!=INF) que.push(i),b[i]=1;  
        }  
        spfa(opt);  
    }  
}  
  
inline bool check(int opt){  
    for (int i=0,j=(d<<1)-1; i<d; ++i,--j)  
        if (((opt&(1<<i))==0)!=((opt&(1<<j))==0)) return 0;  
    return 1;  
}  
  
int main(void){  
    read(n),read(m),read(d);  
    for (int i=1; i<=m; ++i) read(x),read(y),read(w),add(x,y,w);  
    calc(),work(),memset(ans,0x3f,sizeof ans);  
    for (int opt=0; opt<=sum; ++opt)  
        if (check(opt))   
            for (int i=1; i<=n; ++i)  
                ans[opt]=min(ans[opt],f[i][opt]);  
    for (int opt=0; opt<=sum; ++opt)  
        for (int sub=opt; sub; sub=(sub-1)&opt)  
            ans[opt]=min(ans[opt],ans[sub]+ans[opt^sub]);  
    printf("%d\n",ans[sum]==INF?-1:ans[sum]);  
    return 0;  
}  
