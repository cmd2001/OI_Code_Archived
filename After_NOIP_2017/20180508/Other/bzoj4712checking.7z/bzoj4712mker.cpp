#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 200000 , m = 200000;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    printf("%d\n",m);
    for(int i=1;i<=m;i++) {
        int o = _(2) - 1;
        if( !o ) printf("Q %d\n",_(n));
        else printf("C %d %d\n",_(n),_());
    }
    return 0;
}
