#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    static int n = 100000 , m = 500000;
    srand((unsigned long long)new char ^ time(0));
    printf("%d %d\n",n,m);
    for(int i=1,o,l,r;i<=m;i++) {
        o = _(2);
        if( o == 1 ) printf("C %d %d %d\n",_(n),_(n),_(n));
        else l = _(n) , r = _(n) , printf("Q %d %d\n",min(l,r),max(l,r));
    }
}