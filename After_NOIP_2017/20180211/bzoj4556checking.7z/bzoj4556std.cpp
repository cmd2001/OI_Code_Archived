#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#define N 200005
using namespace std;
inline int read()
{
    int p=0;char c=getchar();
    while(c<'0'||c>'9')c=getchar();
    while(c>='0'&&c<='9')p=p*10+c-'0',c=getchar();
    return p;
}
int wb[N],rnk[N],sa[N],sum[N];
int mnn(int x,int y)
{
    if(x<y)return x;return y;
}
char s[N];
void da(int n,int m)
{
    int *x=rnk,*y=wb;
    for(int i=0;i<m;i++)sum[i]=0;
    for(int i=0;i<n;i++)sum[x[i]=s[i]]++;
    for(int i=1;i<m;i++)sum[i]+=sum[i-1];
    for(int i=n-1;i>=0;i--)sa[--sum[x[i]]]=i;
    int p=1;
    for(int j=1;p<n;j<<=1,m=p)
    {
        //printf("j = %d\n",j);
        p=0;
        for(int i=n-j;i<n;i++)y[p++]=i;
        for(int i=0;i<n;i++)if(sa[i]>=j)y[p++]=sa[i]-j;
        for(int i=0;i<m;i++)sum[i]=0;
        for(int i=0;i<n;i++)sum[x[i]]++;
        for(int i=1;i<m;i++)sum[i]+=sum[i-1];
        for(int i=n-1;i>=0;i--)sa[--sum[x[y[i]]]]=y[i];
        swap(x,y);x[sa[0]]=0;p=1;
        for(int i=1;i<n;i++)
         x[sa[i]]=y[sa[i]]==y[sa[i-1]]&&y[sa[i-1]+j]==y[sa[i]+j]?p-1:p++;
    }
    return ;
}
int h[N];
void cal(int n)
{
    int k=0;
    for(int i=1;i<=n;i++)rnk[sa[i]]=i;
    for(int i=0;i<n;i++)
    {
        if(k)k--;
        int j=sa[rnk[i]-1];
        while(s[j+k]==s[i+k])k++;
        h[rnk[i]]=k;
    }
}
int n,m;
int mn[N][20];
int lg[N];
int root[N];
void st()
{
    int now=0;
    for(int i=1;i<=n;i<<=1)
    {
        for(int j=i;j<i<<1;j++)
        {
            lg[j]=now;
        }
        now++;
    }
    for(int i=1;i<=n;i++)mn[i][0]=h[i];
    for(int i=1;i<=18;i++)
    {
        int k=(1<<(i-1));
        for(int j=1;j<=n;j++)
        {
            if(j+k<=n)mn[j][i]=mnn(mn[j][i-1],mn[j+k][i-1]);
            else mn[j][i]=mn[j][i-1];
        }
    }return ;
}
struct node
{
    int l,r,sum;
}a[N*20];int cnt;
void merge(int x,int y,int l,int r,int pos)
{
    if(l==r)
    {
        a[x].sum=1;
        return ;
    }
    int mid=(l+r)>>1;
    if(pos<=mid)
    {
        a[x].l=++cnt;
        a[x].r=a[y].r;
        merge(a[x].l,a[y].l,l,mid,pos);
    }
    else
    {
        a[x].r=++cnt;
        a[x].l=a[y].l;
        merge(a[x].r,a[y].r,mid+1,r,pos);
    }
    a[x].sum=a[a[x].l].sum+a[a[x].r].sum;
}
bool qur(int x,int y,int l,int r,int ll,int rr)
{
    if(a[x].sum==a[y].sum)return 0;
    if(l>=ll&&r<=rr)return a[x].sum!=a[y].sum;
    int mid=(l+r)>>1;
    if(ll<=mid)if(qur(a[x].l,a[y].l,l,mid,ll,rr))return 1;
    if(rr>mid)if(qur(a[x].r,a[y].r,mid+1,r,ll,rr))return 1;
    return 0;
}
int t1,t2,t3,t4;
inline int qr(int l,int r)
{
    if(l>r)return N;
    int k=lg[r-l+1];
    return mnn(mn[l][k],mn[r-(1<<k)+1][k]);
}
bool pan(int x)
{
     int pos=rnk[t3-1];
     int ll,rr;
     int l=pos,r=n,mid;
     while(l<=r)
     {
         mid=(l+r)>>1;
         if(qr(pos+1,mid)<x)r=mid-1;
         else l=mid+1;
     }
     rr=r;
     l=1,r=pos;
     while(l<=r)
     {
         mid=(l+r)>>1;
         if(qr(mid+1,pos)<x)l=mid+1;
         else r=mid-1;
     }
     ll=l;
     //printf("ll = %d , rr = %d\n",ll,rr);
     return qur(root[rr],root[ll-1],1,n,t1,t2-x+1);
}

int main()
{
    //freopen("dat.txt","r",stdin);
    scanf("%d%d",&n,&m);
    scanf("%s",s);
    da(n+1,256);cal(n);
    st();
    for(int i=1;i<=n;i++)
    {
        root[i]=++cnt;
        merge(root[i],root[i-1],1,n,sa[i]+1);
    }
    for(int i=1;i<=m;i++)
    {
        t1=read();t2=read();t3=read();t4=read();
        int l=0;int r=min(t2-t1+1,t4-t3+1);
        while(l<=r)
        {
            int mid=(l+r)>>1;
            if(pan(mid))l=mid+1;
            else r=mid-1;
        }
        printf("%d\n",r);
    }
    return 0;
}
/*
5 2
ababaa
1 4 2 5
1 4 2 3
*/
