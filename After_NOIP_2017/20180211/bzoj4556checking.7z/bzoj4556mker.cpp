#include<bits/stdc++.h>
using namespace std;

_(int r=26) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    int n = 1e5 , m = 1e5;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%c",'a'+_(2));
    puts("");
    while( m-- ) {
        for(int t=1;t<=2;t++) {
            int x = _(n) + 1 , y = _(n) + 1;
            if( x > y ) swap(x,y);
            printf("%d %d%c",x,y,t!=2?' ':'\n');
        }
    }
    return 0;
}
