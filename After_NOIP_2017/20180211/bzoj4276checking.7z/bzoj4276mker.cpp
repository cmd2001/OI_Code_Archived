#include<bits/stdc++.h>
using namespace std;

_(int r=4999) {
    return rand()%r+1;
}

int main() {
    srand((unsigned long long)new char);
    int m = 50;
    printf("%d\n",m);
    while(m--) {
        int x = _() , y = _();
        if( x > y ) swap(x,y);
        printf("%d %d %d\n",x,y+1,_(10000));
    }
    return 0;
}
