#include<bits/stdc++.h>
using namespace std;
inline int rv() {
    return rand() % 1000000000 + 1;
}

vector<pair<int,int>> es;

int main() {
    //freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char);
    const int n = 100000 , m = 200000 , q = 10000;
    int s = n , t = 1;
    for(int i=2;i<=n;i++)
        es.push_back(make_pair(i,rand()%(i-1)+1));
    for(int i=n;i<=m;i++)
        es.push_back(make_pair(rand()%n+1,rand()%n+1));
    random_shuffle(es.begin(),es.end());
    printf("%d %d\n",n,m);
    for(int i=0;i<m;i++)
        printf("%d %d %d\n",es[i].first,es[i].second,rv());
    printf("%d %d\n",s,t);
    printf("%d\n",q);
    for(int i=1;i<=q;i++) {
        int id = rand() % m;
        if( rand() & 1 ) printf("%d %d\n",es[id].first,es[id].second);
        else printf("%d %d\n",es[id].second,es[id].first);
    }
}