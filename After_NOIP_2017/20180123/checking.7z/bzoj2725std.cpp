#include <map>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define M 200200
using namespace std;

struct Segtree{
    Segtree *ls,*rs;
    long long val;
    void* operator new (size_t)
    {
        static Segtree mempool[M<<1],*C=mempool;
        C->val=0x3f3f3f3f3f3f3f3fll;
        return C++;
    }
    void Build_Tree(int x,int y)
    {
        int mid=x+y>>1;
        if(x==y)
            return ;
        (ls=new Segtree)->Build_Tree(x,mid);
        (rs=new Segtree)->Build_Tree(mid+1,y);
    }
    void Modify(int x,int y,int l,int r,long long val)
    {
        int mid=x+y>>1;
        if(x==l&&y==r)
        {
            this->val=min(this->val,val);
            return ;
        }
        if(r<=mid)
            ls->Modify(x,mid,l,r,val);
        else if(l>mid)
            rs->Modify(mid+1,y,l,r,val);
        else
            ls->Modify(x,mid,l,mid,val) , rs->Modify(mid+1,y,mid+1,r,val) ;
    }
    long long Query(int x,int y,int pos)
    {
        int mid=x+y>>1;
        if(x==y)
            return val;
        if(pos<=mid)
            return min(ls->Query(x,mid,pos),val);
        else
            return min(rs->Query(mid+1,y,pos),val);
    }
}*tree=new Segtree;

struct edge{
    int x,y,z;
}edges[M];

struct abcd{
    int to,f,next;
}table[M<<1];
int head[M],tot;

int n,m,q,s,t;
long long f[M],g[M];
int from1[M],from2[M],from3[M];
int pos[M],stack[M],top;
map<pair<int,int>,int> relabel;

void Add(int x,int y,int z)
{
    table[++tot].to=y;
    table[tot].f=z;
    table[tot].next=head[x];
    head[x]=tot;
}
namespace Heap{
    int heap[M],pos[M],top;
    void Push_Up(int t)
    {
        while(t>1)
        {
            if( f[heap[t]]<f[heap[t>>1]] )
                swap(heap[t],heap[t>>1]),swap(pos[heap[t]],pos[heap[t>>1]]),t>>=1;
            else
                break;
        }
    }
    void Insert(int x)
    {
        heap[++top]=x;
        pos[x]=top;
        Push_Up(top);
    }
    void Pop()
    {
        pos[heap[1]]=0;
        heap[1]=heap[top--];
        if(top) pos[heap[1]]=1;
        int t=2;
        while(t<=top)
        {
            if( t<top && f[heap[t+1]]<f[heap[t]] )
                ++t;
            if( f[heap[t]]<f[heap[t>>1]] )
                swap(heap[t],heap[t>>1]),swap(pos[heap[t]],pos[heap[t>>1]]),t<<=1;
            else
                break;
        }
    }
}
void Dijkstra1()
{
    int i;
    memset(f,0x3f,sizeof f);f[s]=0;
    for(i=1;i<=n;i++)
        Heap::Insert(i);
    while(Heap::top)
    {
        int x=Heap::heap[1];Heap::Pop();
        for(i=head[x];i;i=table[i].next)
            if(f[x]+table[i].f<f[table[i].to])
            {
                f[table[i].to]=f[x]+table[i].f;
                from1[table[i].to]=x;
                Heap::Push_Up(Heap::pos[table[i].to]);
            }
    }
}
void Dijkstra2()
{
    int i;
    memset(f,0x3f,sizeof f);f[s]=0;
    for(i=1;i<=n;i++)
        Heap::Insert(i);
    while(Heap::top)
    {
        int x=Heap::heap[1];Heap::Pop();
        if(pos[x]) from2[x]=x;
        for(i=head[x];i;i=table[i].next)
            if(f[x]+table[i].f<f[table[i].to])
            {
                f[table[i].to]=f[x]+table[i].f;
                from2[table[i].to]=from2[x];
                Heap::Push_Up(Heap::pos[table[i].to]);
            }
    }
}
void Dijkstra3()
{
    int i;
    memset(f,0x3f,sizeof f);f[t]=0;
    for(i=1;i<=n;i++)
        Heap::Insert(i);
    while(Heap::top)
    {
        int x=Heap::heap[1];Heap::Pop();
        if(pos[x]) from3[x]=x;
        for(i=head[x];i;i=table[i].next)
            if(f[x]+table[i].f<f[table[i].to])
            {
                f[table[i].to]=f[x]+table[i].f;
                from3[table[i].to]=from3[x];
                Heap::Push_Up(Heap::pos[table[i].to]);
            }
    }
    memcpy(g,f,sizeof g);
}
int main()
{
    #ifdef PoPoQQQ
    freopen("2725.in","r",stdin);
    freopen("2725.out","w",stdout);
    #endif
    int i,x,y,z;
    cin>>n>>m;
    for(i=1;i<=m;i++)
    {
        scanf("%d%d%d",&x,&y,&z);
        if(x>y) swap(x,y);
        Add(x,y,z);Add(y,x,z);
        edges[i].x=x;
        edges[i].y=y;
        edges[i].z=z;
    }
    cin>>s>>t;
    if(s==t)
    {
        cin>>q;
        for(i=1;i<=q;i++)
            puts("0");
        return 0;
    }
    Dijkstra1();
    for(i=t;i;i=from1[i])
        stack[++top]=i;
    for(i=top;i;i--)
        pos[stack[i]]=top-i+1;
    for(i=top;i>1;i--)
    {
        x=stack[i];
        y=stack[i-1];
        if(x>y) swap(x,y);
        relabel[pair<int,int>(x,y)]=top-i+1;
    }
    Dijkstra3();
    Dijkstra2();
    tree->Build_Tree(1,top-1);
    for(i=1;i<=m;i++)
    {
        if( relabel.find(pair<int,int>(edges[i].x,edges[i].y))!=relabel.end() )
            continue;
        x=pos[from2[edges[i].x]];
        y=pos[from3[edges[i].y]]-1;
        if(x<=y)
            tree->Modify(1,top-1,x,y,f[edges[i].x]+g[edges[i].y]+edges[i].z);
        swap(edges[i].x,edges[i].y);
        x=pos[from2[edges[i].x]];
        y=pos[from3[edges[i].y]]-1;
        if(x<=y)
            tree->Modify(1,top-1,x,y,f[edges[i].x]+g[edges[i].y]+edges[i].z);
    }
    cin>>q;
    for(i=1;i<=q;i++)
    {
        scanf("%d%d",&x,&y);
        if(x>y) swap(x,y);
        long long ans;
        if(relabel.find(pair<int,int>(x,y))==relabel.end())
            ans=f[t];
        else
            ans=tree->Query(1,top-1,relabel[pair<int,int>(x,y)]);
        if(ans==0x3f3f3f3f3f3f3f3fll)
            puts("Infinity");
        else
        #ifdef PoPoQQQ
            printf("%I64d\n",ans);
        #else
            printf("%lld\n",ans);
        #endif
    }
    return 0;
}