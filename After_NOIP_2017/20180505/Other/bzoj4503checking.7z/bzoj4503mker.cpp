#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r;
}
int main() {
    srand((unsigned long long)new char);
    int n = 1e5 , m = _(100000);
    for(int i=1;i<=n;i++) putchar(_(26)+'a');
    puts("");
    for(int i=1,t;i<=m;i++) t = _(27) , putchar(t==0?'?':t+'a'-1);
    return 0;
}