#include<bits/stdc++.h>
using namespace std;

int dat[1010];

inline int _(int r=100) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = 1000 , m = 0 , k = rand() % 100;
    for(int i=1;i<=n;i++) dat[i] = _() , m += dat[i];
    printf("%d %d %d\n",n,m,k);
    for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    return 0;
}