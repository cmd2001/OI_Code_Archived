#include<stdio.h>  
#include<iomanip>  
#include<string.h>  
#include<iostream>  
#include<algorithm>  
#define N 1001  
using namespace std;  
typedef double ld;  
struct matrix  
{  
    ld a[N];  
}now,T,In,ret_mul,ret_pow;  
int n;  
void mul(matrix &x,matrix &y,matrix &p)  
{  
    memset(&ret_mul,0,sizeof(matrix));  
    for(int i=1;i<=n;i++)  
    {  
        ret_mul.a[i]=0;  
        for(int j=1;j<=n;j++)  
            ret_mul.a[i]+=x.a[j]*y.a[(i-j+n)%n+1];  
    }  
    p=ret_mul;  
}  
void pow(matrix &x,int y,matrix &p)  
{  
    ret_pow=In;  
    while(y)  
    {  
        if(y&1)  
            mul(ret_pow,x,ret_pow);  
        mul(x,x,x);  
        y>>=1;  
    }  
    p=ret_pow;  
}  
int main()  
{  
    int m,i,j,k;  
    scanf("%d%d%d",&n,&m,&k);  
    for(i=1;i<=n;i++)  
        cin>>now.a[i];  
    In.a[1]=1;  
    T.a[1]=1-1.0/m,T.a[2]=1.0/m;  
    pow(T,k,T);  
    mul(now,T,now);  
    cout<<fixed<<setprecision(3);  
    for(i=1;i<=n;i++)  
        cout<<now.a[i]<<endl;  
    return 0;  
}
