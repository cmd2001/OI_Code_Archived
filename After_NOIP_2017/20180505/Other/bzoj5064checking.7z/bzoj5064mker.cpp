#include<bits/stdc++.h>
typedef long long int lli;
using namespace std;

inline lli Rand() {
    return rand() | ( (lli) rand() << 16 ) | ( (lli) rand() << 32 ) |  ( (lli) rand() << 48 );
}
inline lli _(lli r=1e15) {
    return Rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    printf("%lld\n",_());
    return 0;
}