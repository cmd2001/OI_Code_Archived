#include <cstdio>
typedef long long ll;
ll b[17] , f[17][13][10][2];
int main()
{
    int i , j , k , l , m , di = 1 , flag = 0;
    ll n , now = 0 , ans = 0;
    b[0] = f[0][0][0][0] = 1;
    for(i = 1 ; i <= 16 ; i ++ )
    {
        b[i] = b[i - 1] * 10;
        for(j = 0 ; j < 13 ; j ++ )
            for(k = 0 ; k < 10 ; k ++ )
                for(l = 0 ; l < 10 ; l ++ )
                    for(m = 0 ; m < 2 ; m ++ )
                        f[i][(j + k * b[i - 1]) % 13][k][m || (k == 1 && l == 3)] += f[i - 1][j][l][m];
    }
    scanf("%lld" , &n) , n ++ ;
    for(i = 1 ; b[i] <= n ; i ++ )
        for(j = 1 ; j < 10 ; j ++ )
            ans += f[i][0][j][1];
    for( ; i ; i -- )
    {
        for(j = di ; j < n / b[i - 1] % 10 ; j ++ )
            ans += f[i][(13 - now * b[i] % 13) % 13][j][1] + (flag || (n / b[i] % 10 == 1 && j == 3)) * f[i][(13 - now * b[i] % 13) % 13][j][0];
        now = (now * 10 + n / b[i - 1] % 10) % 13 , di = 0;
        if(n / b[i] % 10 == 1 && n / b[i - 1] % 10 == 3) flag = 1;
    }
    printf("%lld\n" , ans);
    return 0;
}