#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100000 , m = 100000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(100000),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) printf("%d %d\n",_(2),_(n));
    return 0;
}