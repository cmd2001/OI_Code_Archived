#include <stdio.h>
#include <string.h>
#include <algorithm>
#define rep(i,st,ed) for (int i=st;i<=ed;++i)

typedef long long LL;
const LL INF=1e15;
const int N=400005;

struct treeNode {int son[2],fa; LL v; int size,lazy;} t[N];

LL a[N];

int root,tot;

int read() {
    int x=0,v=1; char ch=getchar();
    for (;ch<'0'||ch>'9';v=(ch=='-')?(-1):(v),ch=getchar());
    for (;ch<='9'&&ch>='0';x=x*10+ch-'0',ch=getchar());
    return x*v;
}

void push_up(int x) {
    t[x].size=t[t[x].son[0]].size+t[t[x].son[1]].size+1;
}

void push_down(int x) {
    if (!t[x].lazy) return ;
    t[t[x].son[0]].v-=t[x].lazy;
    t[t[x].son[1]].v-=t[x].lazy;
    t[t[x].son[0]].lazy+=t[x].lazy;
    t[t[x].son[1]].lazy+=t[x].lazy;
    t[x].lazy=0;
}

void rotate(int x) {
    int y=t[x].fa; int z=t[y].fa;
    int k=t[y].son[1]==x;
    t[z].son[t[z].son[1]==y]=x; t[x].fa=z;
    t[y].son[k]=t[x].son[!k]; t[t[x].son[!k]].fa=y;
    t[x].son[!k]=y; t[y].fa=x;
    push_up(y); push_up(x);
}

void remove(int x,int goal) {
    if (!x) return ;
    remove(t[x].fa,goal);
    push_down(x);
}

void splay(int x,int goal=0) {
    remove(x,goal);
    while (t[x].fa!=goal) {
        int y=t[x].fa; int z=t[y].fa;
        if (z!=goal) {
            if ((t[z].son[1]==y)^(t[y].son[1]==x)) rotate(x);
            else rotate(y);
        }
        rotate(x);
    }
    if (!goal) root=x;
}

int kth(int k) {
    int x=root;
    while (233) {
        push_down(x);
        if (t[t[x].son[0]].size+1==k) {
            splay(x);
            return t[x].v;
        }
        if (t[t[x].son[0]].size>=k) x=t[x].son[0];
        else k-=t[t[x].son[0]].size+1,x=t[x].son[1];
    }
}

int lower(int k) {
    int x=root,y;
    while (x) {
        push_down(x);
        if (t[x].v<k) y=x,x=t[x].son[1];
        else x=t[x].son[0];
    }
    return y;
}

int upper(int k) {
    int x=root,y;
    while (x) {
        push_down(x);
        if (t[x].v>k) y=x,x=t[x].son[0];
        else x=t[x].son[1];
    }
    return y;
}

void insert(int d,int x) {
    push_down(d);
    if (t[x].v<=t[d].v) {
        if (!t[d].son[0]) {
            t[d].son[0]=x;
            t[x].fa=d; t[x].size=1;
            splay(x);
        } else insert(t[d].son[0],x);
    } else {
        if (!t[d].son[1]) {
            t[d].son[1]=x;
            t[x].fa=d; t[x].size=1;
            splay(x);
        } else insert(t[d].son[1],x);
    }
}

void build(int x,int k) {
    if (!x) return ;
    push_down(x);
    build(t[x].son[0],k);
    build(t[x].son[1],k);
    t[x].v-=k;
    t[x].son[0]=t[x].son[1]=0;
    insert(root,x);
}

void solve(int k) {
    int l=lower(k+1);
    int r=upper(k*2);
    splay(l); splay(r,l);
    int x=t[r].son[0]; t[r].son[0]=0;
    t[r].lazy+=k; t[r].v-=k;
    build(x,k);
}

int build_tree(int l,int r,int fa) {
    int mid=(l+r)>>1;
    t[mid].v=a[mid]; t[mid].size=1; t[mid].fa=fa;
    if (l<mid) t[mid].son[0]=build_tree(l,mid-1,mid);
    if (mid<r) t[mid].son[1]=build_tree(mid+1,r,mid);
    push_up(mid);
    return mid;
}

int main(void) {
    int n=read(),m=read();
    a[1]=0; a[n+2]=INF;
    rep(i,1,n) a[i+1]=read();
    std:: sort(a+1,a+n+3); tot=n+2;
    root=build_tree(1,n+2,0);
    while (m--) {
        int opt=read(),x=read();
        if (opt==1) printf("%d\n", kth(x+1));
        else solve(x);
    }
    return 0;
}