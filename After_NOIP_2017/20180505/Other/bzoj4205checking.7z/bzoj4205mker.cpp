#include<bits/stdc++.h>
using namespace std;

inline int _(int r=200) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = _(30000) , m = _(30000);
    printf("%d %d\n",n,m);
    for(int i=1;i<=n+m;i++) for(int j=1;j<=3;j++) printf("%d%c",_(),j!=3?' ':'\n');
    return 0;
}