#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 800 , m = 8000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) {
        int x = _(n) , y = _(n) , p = _();
        if( x > y ) swap(x,y);
        printf("%d %d %d\n",x,y,p);
    }
    return 0;
}
