#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <string>
#include <cstring>
#include <algorithm>
#define RG register
const double eps = 1e-9;
const double inf = 1e20;
 
using namespace std;
 
int gi(){
    char ch=getchar();int x=0;
    while(ch<'0' || ch>'9') ch=getchar();
    while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
    return x;
}
 
int n,m;
double a[1050][10050];
int b[10050];
 
void pivot(int l,int e){
    double k=a[l][e];a[l][e]=1;
    for (RG int i=0; i<=n; ++i) a[l][i]/=k;
    int len=0;
    for (RG int i=0; i<=n; ++i) if (fabs(a[l][i])>eps) b[++len]=i;
    for (RG int i=0; i<=m; ++i)
        if (i!=l && fabs(a[i][e])>eps){
            k=a[i][e];a[i][e]=0;
            for (RG int j=1; j<=len; ++j) a[i][b[j]]-=k*a[l][b[j]];
        }
}
 
double simplex(){
    while(1){
        RG int l,e;
        for (e=1; e<=n; ++e) if (a[0][e]>eps) break;
        if (e==n+1) return -a[0][0];
        double tmp=inf;
        //printf("e = %d\n",e);
        for (RG int i=1; i<=m; ++i)
            if (a[i][e]>eps && a[i][0]/a[i][e]<tmp) tmp=a[i][0]/a[i][e],l=i;
        if (tmp==inf) return inf;
        //printf("id = %d\n",l);
        pivot(l,e);
        //printf("now ret = %.0lf\n",-a[0][0]);
    }
}
 
int main(){
    n=gi(),m=gi();
    for (RG int i=1; i<=n; ++i) a[i][0]=gi();
    for (RG int i=1; i<=m; ++i){
        int l=gi(),r=gi();
        for (RG int j=l; j<=r; ++j) a[j][i]=1;
        a[0][i]=gi();
    }
    swap(n,m);
    printf("%lld",(long long)(floor(simplex()+0.5)));
}
