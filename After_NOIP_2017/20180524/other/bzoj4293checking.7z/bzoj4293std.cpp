#include<cstdio>
#include<cctype>
#include<queue>
#include<cstring>
#include<algorithm>
#define rep(i,s,t) for(int i=s;i<=t;i++)
#define dwn(i,s,t) for(int i=s;i>=t;i--)
#define ren for(int i=first[x];i;i=next[i])
using namespace std;
const int BufferSize=1<<16;
char buffer[BufferSize],*head,*tail;
inline char Getchar() {
    if(head==tail) {
        int l=fread(buffer,1,BufferSize,stdin);
        tail=(head=buffer)+l;
    }
    return *head++;
}
typedef long long ll;
inline ll read() {
    ll x=0,f=1;char c=Getchar();
    for(;!isdigit(c);c=Getchar()) if(c=='-') f=-1;
    for(;isdigit(c);c=Getchar()) x=x*10+c-'0';
    return x*f;
}
const int maxn=500010;
int n,m,A[maxn];
ll setv[maxn<<2],sett[maxn<<2],suma[maxn<<2],sumv[maxn<<2],maxv[maxn<<2],maxt[maxn<<2];
void maintain(int o,int l,int r) {
    int lc=o<<1,rc=lc|1;
    if(setv[o]>=0) {
        sumv[o]=setv[o]*(r-l+1)-sett[o]*suma[o];
        maxv[o]=setv[o];maxt[o]=sett[o];
    }
    else if(l<r) {
        sumv[o]=sumv[lc]+sumv[rc];
        maxv[o]=maxv[rc];maxt[o]=maxt[rc];
    }
}
void pushdown(int o,int l,int r) {
    int lc=o<<1,rc=lc|1,mid=l+r>>1;
    if(setv[o]>=0) {
        setv[lc]=setv[rc]=setv[o];
        sett[lc]=sett[rc]=sett[o];
        maxt[lc]=maxt[rc]=sett[o];
        sumv[lc]=setv[o]*(mid-l+1)-sett[o]*suma[lc];
        sumv[rc]=setv[o]*(r-mid)-sett[o]*suma[rc];
        maxv[lc]=maxv[rc]=setv[o];
        setv[o]=sett[o]=-1;
    }
}
void build(int o,int l,int r) {
    if(l==r) suma[o]=A[l];
    else {
        setv[o]=-1;
        int mid=l+r>>1,lc=o<<1,rc=lc|1;
        build(lc,l,mid);build(rc,mid+1,r);
        suma[o]=suma[lc]+suma[rc];
    }
}
ll ans,d,b;
int findst(int o,int l,int r) {
    if(l==r) return l;
    else {
        pushdown(o,l,r);
        int mid=l+r>>1,lc=o<<1,rc=lc|1;
        if(maxv[lc]+(d-maxt[lc])*A[mid]>b) return findst(lc,l,mid);
        return findst(rc,mid+1,r);
    }
}
void update(int o,int l,int r,int ql,int qr) {
    if(ql<=l&&r<=qr) {
        ans+=sumv[o]+d*suma[o]-b*(r-l+1);
        setv[o]=b;sett[o]=d;
    }
    else {
        pushdown(o,l,r);
        int mid=l+r>>1,lc=o<<1,rc=lc|1;
        if(ql<=mid) update(lc,l,mid,ql,qr);
        if(qr>mid) update(rc,mid+1,r,ql,qr);
    }
    maintain(o,l,r);
}
int main() {
    n=read();m=read();
    rep(i,1,n) A[i]=read();
    sort(A+1,A+n+1);
    build(1,1,n);
    rep(i,1,m) {
        d=read();b=read();
        if(maxv[1]+(d-maxt[1])*A[n]<=b) puts("0");
        else {
            int s=findst(1,1,n);ans=0;
            update(1,1,n,s,n);printf("%lld\n",ans);
        }
    }
    return 0;
}