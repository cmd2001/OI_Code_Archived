#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e6) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5e5 , m = 5e5;
    static long long lst,tp;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(1e3),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) tp = lst + _() , printf("%lld %d\n",tp,_()) , lst = tp;
    return 0;
}