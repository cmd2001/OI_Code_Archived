#include<bits/stdc++.h>
using namespace std;
const int lim = 1e9;

inline int _rand(int r=lim) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    const int n = 1e5;
    printf("%d\n",n);
    for(int i=2;i<=n;i++)
        printf("%d %d %d\n",i,i-1,_rand());
    for(int i=1;i<n;i++)
        printf("%d %d\n",_rand(),_rand());
    return 0;
}
