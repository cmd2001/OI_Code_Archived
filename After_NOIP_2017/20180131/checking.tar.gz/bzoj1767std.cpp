#include<iostream>
#include<cstdio>
#include<climits>
#include<cstring>
#include<algorithm>
using namespace std;
#define LL long long
#define db double
LL read(){
    LL q=0,w=1;char ch=' ';
    while(ch!='-'&&(ch<'0'||ch>'9'))ch=getchar();
    if(ch=='-')w=-1,ch=getchar();
    while(ch>='0'&&ch<='9')q=q*10+(LL)(ch-'0'),ch=getchar();
    return q*w;
}
const int N=100050;
int n,tot,top;
int h[N],to[N<<1],ne[N<<1];LL lo[N<<1];
LL s[N],v[N],f[N],dis[N];
int q[N];
void add(int x,int y,LL z){to[++tot]=y,ne[tot]=h[x],h[x]=tot,lo[tot]=z;}
db g(int j,int k){return (db)(f[j]*1.0-f[k]*1.0)/(db)(dis[j]*1.0-dis[k]*1.0);}
int sfind(int l,int r,LL x){//二分找队首最优决策
    int mid=0;
    while(l<=r){
        mid=(l+r)>>1;
        if(g(q[mid+1],q[mid])<v[x])l=mid+1;
        else if(g(q[mid],q[mid-1])>v[x])r=mid-1;
        else return mid;
    }
    return mid;
}
int tfind(int l,int r,int x){//二分找x应插入到队尾的什么地方（mid后面）
    int mid=0;
    while(l<=r){
        mid=(l+r)>>1;
        if(g(q[mid+1],q[mid])<g(x,q[mid]))l=mid+1;
        else if(g(q[mid],q[mid-1])>g(q[mid],x))r=mid-1;
        else return mid;
    }
    return mid;
}
void dfs(int x,int las){
    int i,j,fg,kls,kltop;
    fg=sfind(1,top,x);
    f[x]=f[q[fg]]+(dis[x]-dis[q[fg]])*v[x]+s[x];//dp
    fg=tfind(1,top,x);
    kls=q[fg+1],kltop=top,top=fg+1,q[top]=x;//暂时储存被修改的top和q[fg+1]
    for(i=h[x];i;i=ne[i]){
        if(to[i]==las)continue;
        dis[to[i]]=dis[x]+lo[i],dfs(to[i],x);
    }
    top=kltop,q[fg+1]=kls;//改回来
}
int main()
{
    //freopen("harbingers.in","r",stdin);
    //freopen("harbingers.out","w",stdout);
    int i,x,y;LL z;
    n=read();
    for(i=1;i<n;i++)x=read(),y=read(),z=read(),add(x,y,z),add(y,x,z);
    for(i=2;i<=n;i++)s[i]=read(),v[i]=read();
    dfs(1,-1);
    for(i=2;i<=n;i++)printf("%lld%c",f[i],i!=n?' ':'\n');
    return 0;
}
