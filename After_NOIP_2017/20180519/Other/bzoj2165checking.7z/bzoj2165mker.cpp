#include<bits/stdc++.h>
typedef long long int lli;
using namespace std;

inline lli _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int T = 10 , n = 95;
    printf("%d\n",T);
    while(T--) {
        int nn = n + T;
        printf("%d %lld\n",nn,_(1e18)+1e18);
        for(int i=1;i<=nn;i++) for(int j=1;j<=nn;j++) printf("%d%c",_(10)-1,j!=nn?' ':'\n');
    }
    return 0;
}