/*by SilverN*/
#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<vector>
#define LL long long
using namespace std;
const LL INF=1e18;
const int mxn=105;
LL read(){
    LL x=0,f=1;char ch=getchar();
    while(ch<'0' || ch>'9'){if(ch=='-')f=-1;ch=getchar();}
    while(ch>='0' && ch<='9'){x=x*10+ch-'0';ch=getchar();}
    return x*f;
}
int n,ed;
LL m;
struct Mat{
    LL x[mxn][mxn];
    friend Mat operator *(Mat a,Mat c){
        Mat res;
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                res.x[i][j]=-INF;
                 for(int k=1;k<=n;k++){
                    res.x[i][j]=max(res.x[i][j],a.x[i][k]+c.x[k][j]);
                 }
                if(res.x[i][j]>m)res.x[i][j]=m;
            }
        }
        return res;
    }
}f[62],now,t;
inline bool check(Mat *a){
    for(int i=1;i<=n;i++)
        if(a->x[1][i]>=m)return 1;
    return 0;
}
int main(){
    int i,j;
    int T=read();
    while(T--){
        n=read();m=read();
        for(i=1;i<=n;i++)
            for(j=1;j<=n;j++){
                f[1].x[i][j]=read();
                if(!f[1].x[i][j])f[1].x[i][j]=-INF;
            }
        ed=1;
        for(i=2;i<62;i++){
            f[i]=f[i-1]*f[i-1];
            ed=i;
            if(check(&f[i]))break;
        }
        t=f[1];
        LL ans=1;
        for(i=ed;i;i--){
            now=t*f[i];
            if(!check(&now)){
                t=now;
                ans+=1LL<<(i-1);
            }
        }
        printf("%lld\n",ans+1);
    }
    return 0;
}
