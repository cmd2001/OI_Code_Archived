#include<bits/stdc++.h>
using namespace std;
const int maxn=5e3+1e2;

int in[maxn],n,m,l,r,k;

inline int calc(int l,int r,int k) {
    int ret = 0;
    for(int i=l;i<=r;i++) if( in[i] == k ) ++ret;
    return ret;
}

int main() {
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++) scanf("%d",in+i);
    for(int i=1,o,l,r,k;i<=m;i++) {
        scanf("%d%d%d",&o,&l,&r);
        if( o == 1 ) scanf("%d",&k) , printf("%d\n",calc(l,r,k));
        else if( o == 2 ) in[l] = r;
    }
    return 0;
}
