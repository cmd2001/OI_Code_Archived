#include<bits/stdc++.h>
using namespace std;
const int maxn=5e5+1e2;

int dat[maxn];

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char);
    static int n = 5e5;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) dat[i] = _();
    sort(dat+1,dat+1+n);
    for(int i=1;i<=n;i++) printf("%d %d\n",dat[i],_(3));
    return 0;
}
