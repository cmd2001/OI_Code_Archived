#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long LL;
const int N=2000010;
int n;
LL X[N],R[N];
const int MOD=1e9+7;
struct qq
{
    int x,y,last;
}s[N*8];int Num,last[N];
int ll[N],rr[N];
void init (int x,int y)
{
    Num++;
    s[Num].x=x;s[Num].y=y;
    s[Num].last=last[x];
    last[x]=Num;
    return ;
}
void Ins ()
{
    Num=0;memset(last,-1,sizeof(last));
    scanf("%d",&n);
    for (int u=1;u<=n;u++)
        scanf("%lld%lld",&X[u],&R[u]);
}
struct qr
{
    int l,r;
    int s1,s2;
}tr[N];int num;
int pos[N];
void bt (int l,int r)
{
    int a=++num;
    tr[a].l=l;tr[a].r=r;
    ll[a]=l;rr[a]=r;
    if (l==r) 
    {
        pos[l]=a;
        return ;
    }
    int mid=(l+r)>>1;
    tr[a].s1=num+1;bt(l,mid);
    tr[a].s2=num+1;bt(mid+1,r);
    init(a,tr[a].s1);init(a,tr[a].s2);
}
void Link (int now,int l,int r,int x)
{
    if (tr[now].l==l&&tr[now].r==r)
    {
        init(x,now);
        return ;
    }
    int mid=(tr[now].l+tr[now].r)>>1;
    int s1=tr[now].s1,s2=tr[now].s2;
    if (r<=mid) Link(s1,l,r,x);
    else if (l>mid) Link(s2,l,r,x);
    else Link(s1,l,mid,x),Link(s2,mid+1,r,x);
}
void Bt ()
{
    num=0;bt(1,n);
    //for (int u=1;u<=n;u++) printf("%d ",pos[u]);
    for (int u=1;u<=n;u++)
    {
        int l=1,r=u;
        int p;
        while (l<=r)
        {
            int mid=(l+r)>>1;
            if (X[mid]+R[u]>=X[u]) {p=mid;r=mid-1;}
            else l=mid+1;
        }
        if (p!=u) Link(1,p,u-1,pos[u]);
    //  printf("%d %d %d\n",p,u-1,pos[u]);
        l=u;r=n;
        while (l<=r)
        {
            int mid=(l+r)>>1;
            if (X[mid]-R[u]<=X[u]) {p=mid;l=mid+1;}
            else r=mid-1;
        }
        if (p!=u) Link(1,u+1,p,pos[u]);
    //  printf("%d %d %d\n",u+1,u-1,pos[u]);
    }
}
bool vis[N];
int mymax (int x,int y){return x>y?x:y;}
int mymin (int x,int y){return x<y?x:y;}
int L1[N],R1[N];
void dfs (int x)
{
    vis[x]=true;
    for (int u=last[x];u!=-1;u=s[u].last)
    {
        int y=s[u].y;
        if (vis[y]==false) dfs(y);
        L1[x]=mymin(L1[x],L1[y]);
        R1[x]=mymax(R1[x],R1[y]);
    }
}
int dfn[N],low[N],belong[N],cnt,sta[N],lalal,shen;
bool in[N];
void dfs1 (int x)
{
    dfn[x]=low[x]=++lalal;
    sta[++cnt]=x;
    in[x]=true;
    for (int u=last[x];u!=-1;u=s[u].last)
    {
        int y=s[u].y;
        if (dfn[y]==-1)
        {
            dfs1(y);
            low[x]=mymin(low[x],low[y]);
        }
        else if (in[y]) low[x]=mymin(dfn[y],low[x]);
    }
    if (low[x]==dfn[x])
    {
        shen++;
        L1[shen]=1<<30;
        R1[shen]=0;
        int now;
        do
        {
            now=sta[cnt--];
            belong[now]=shen;
            L1[shen]=mymin(ll[now],L1[shen]);
            R1[shen]=mymax(rr[now],R1[shen]);
            in[now]=false;
        }while (now!=x);
    }
}
void solve ()
{
    shen=lalal=cnt=0;
    memset(dfn,-1,sizeof(dfn));
    memset(in,false,sizeof(in));
    for (int u=1;u<=num;u++)
        if (dfn[u]==-1)
            dfs1(u);
   // for (int u=1;u<=num;u++) printf("%d %d\n",u,belong[u]);
    num=0;memset(last,-1,sizeof(last));
    for (int u=1;u<=Num;u++)
        if (belong[s[u].x]!=belong[s[u].y])
        {
            int X=belong[s[u].x],Y=belong[s[u].y];
            num++;
            s[num].x=X;s[num].y=Y;
            s[num].last=last[X];
            last[X]=num;
        }
    memset(vis,false,sizeof(vis));
    for (int u=1;u<=shen;u++) 
        dfs(u);
    long long ans=0;
    for (int u=1;u<=n;u++) 
    {
        ans=(ans+(long long)u*(R1[belong[pos[u]]]-L1[belong[pos[u]]]+1)%MOD)%MOD;
    }
    printf("%lld\n",ans);
}
int main()
{
    Ins();
    Bt();
    solve();
    return 0;
}
