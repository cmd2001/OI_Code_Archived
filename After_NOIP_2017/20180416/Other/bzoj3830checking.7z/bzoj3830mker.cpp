#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+1e2;

int dat[maxn];

inline int ___() {
    return rand() ^ ( (long long)rand() << 16 ) ^ ( (long long)rand() << 32 ) ^ ( (long long)rand() << 48 ) ;
}
inline int _(int r) {
    return ___() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = 100000 , t = _(n);
    printf("%d %d\n",n,t);
    for(int i=1;i<=n;i++) dat[i] = _(n<<1);
    sort(dat+1,dat+1+n);
    for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    return 0;
}
