#include<bits/stdc++.h>
#define I int
using namespace std;

 _(I x) {
    return rand()%x+1;
}

I main() {
    srand((unsigned long long)new char);
    I n = 1e5 , m = 1e5;
    printf("%d %d\n",n,m);
    for(I i=2;i<=n;i++)
        printf("%d %d\n",_(i-1),i);
    for(I i=1;i<=m;i++) {
        I x = _(n) , y = _(n);
        //while( x == y ) x = _(n) , y = _(n);
        printf("%d %d\n",x,y);
    }
    return 0;
}
