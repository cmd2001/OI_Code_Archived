#include<bits/stdc++.h>
using namespace std;
const int maxn=110;

bitset<maxn> can[maxn];
int id[maxn];

int main() {
    srand((unsigned long long)new char);
    static int n = 100;
    for(int i=1;i<=n;i++) id[i] = i;
    random_shuffle(id+1,id+1+n);
    for(int i=1;i<=n;i++) for(int j=i+1;j<=n;j++) can[i][j] = rand() & 1;
    printf("%d\n",n);
    for(int i=1;i<=n;i++) {
        printf("%llu ",can[id[i]].count());
        for(int j=id[i]+1;j<=n;j++) if( can[id[i]][j] ) printf("%d ",j);
        puts("");
    }
    return 0;
}
