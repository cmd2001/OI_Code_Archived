#include<bits/stdc++.h>
using namespace std;
const int str = 1001;

inline int _(int r=str) {
    return rand() % r;
}

int main() {
    static int n = 200 , m = 199;
    srand((unsigned long long)new char);
    int l = _() , r = _();
    if( l > r ) swap(l,r);
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) printf("%d%c",_(),j!=m?' ':'\n');
    printf("%d %d\n",l,r);
    return 0;
}

