#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define debug cout
#define N 131072
#define pi acos(-1)
using namespace std;
int n; 
struct complex
{
    double r,i;
    complex(double x=0.0,double y=0.0){r=x,i=y;}
    complex operator + (const complex a)
    {return complex(a.r+r,a.i+i);}
    complex operator - (const complex a) 
    {return complex(r-a.r,i-a.i);}
    complex operator * (const complex a)
    {return complex(r*a.r-i*a.i,r*a.i+i*a.r);}
}a[N+10],b[N+10],c[N+10],d[N+10];
int rev[N+10];
void FFT(complex *a,int f)
{
    for(int i=0;i<n;i++)if(i<rev[i])swap(a[i],a[rev[i]]);
    for(int h=2;h<=n;h<<=1)
    {
        complex wn(cos(2*pi*f/h),sin(2*pi*f/h));
        for(int i=0;i<n;i+=h)
        {
            complex w(1,0);
            for(int j=0;j<(h>>1);j++,w=w*wn)
            {
                complex t=a[i+j+(h>>1)]*w;
                a[i+j+(h>>1)]=a[i+j]-t;
                a[i+j]=a[i+j]+t;
            }
        }
    }
    if(f==-1)for(int i=0;i<n;i++)a[i].r/=n;
}
int main()
{
    int ma=-1;
    scanf("%d",&n);n--;
    for(int i=0;i<=n;i++)
    {
        int x;
        scanf("%d",&x);
        a[x].r=1,b[2*x].r=1,c[3*x].r=1;
        ma=max(ma,3*x);
    }
    int m=ma,L=0;
    for(n=1;n<=m;n<<=1)L++;
    for(int i=0;i<n;i++)rev[i]=(rev[i>>1]>>1)|((i&1)<<(L-1));
    FFT(a,1),FFT(b,1),FFT(c,1);
    //for(int i=0;i<n;i++) debug<<a[i].r<<" ";debug<<endl;
    for(int i=0;i<=n;i++)
    {
        complex tmp(1.0/6.0,0);
        complex tmp2(3.0,0);
        complex tmp3(2.0,0);
        complex tmp4(1.0/2.0,0);
        d[i]=d[i]+(a[i]*a[i]*a[i]-tmp2*a[i]*b[i]+tmp3*c[i])*tmp;
        d[i]=d[i]+(a[i]*a[i]-b[i])*tmp4;
        d[i]=d[i]+a[i];
    }
    //for(int i=0;i<n;i++) debug<<d[i].r<<" ";debug<<endl;
    FFT(d,-1);
    for(int i=0;i<=n;i++)
    {
        int print=(int)(d[i].r+0.1);
        if(print!=0)printf("%d %d\n",i,print);
    } 
}
