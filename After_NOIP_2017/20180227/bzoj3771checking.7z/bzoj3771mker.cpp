#include<bits/stdc++.h>
using namespace std;

inline int _(int r=40000) {
    return rand() % r + 1;
}
bitset<40010> s;

int main() {
    static int n=10000;
    printf("%d\n",n);
    for(int i=1,x;i<=n;i++) {
        x = _();
        while( s[x] ) x = _();
        s[x] = 1 , printf("%d\n",x);
    }
    return 0;
}
