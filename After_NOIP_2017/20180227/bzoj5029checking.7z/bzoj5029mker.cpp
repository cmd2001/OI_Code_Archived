#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e7) {
    return ( rand() + (long long)(rand()<<15) ) % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5;
    printf("%d\n",n);
    for(int i=1,x,y;i<=n;i++) {
        x = _(5) , y = _(5);
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
