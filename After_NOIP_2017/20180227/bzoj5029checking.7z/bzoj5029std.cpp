#include<cstdio>  
#include<cstdlib>  
#include<cstring>  
#include<iostream>  
#include<algorithm>  
using namespace std;  
const int N=300100;  
int n,num=0;  
struct node{  
    int x,num,id;  
}sa[N<<1];  
int ss[N][3];  
bool cmp(node x,node y)  
{  
    return x.x<y.x;  
}  
struct node1{  
    int l,r,c,lazy;  
}tr[N<<1];  
void bt(int x,int l,int r)  
{  
    tr[x].l=l;tr[x].r=r;tr[x].c=tr[x].lazy=0;  
    if(l<r)  
    {  
        int mid=(l+r)>>1;  
        bt(x<<1,l,mid);  
        bt(x<<1|1,mid+1,r);  
    }  
}  
void update(int x)  
{  
    int c=tr[x].lazy;  
    tr[x<<1].c=tr[x<<1|1].c=tr[x<<1].lazy=tr[x<<1|1].lazy=c;  
    tr[x].lazy=0;  
}  
void change(int rt,int x,int y,int l,int r,int c)  
{  
    if(x==l&&y==r){tr[rt].c=tr[rt].lazy=c;return;}  
    if(tr[rt].lazy!=0) update(rt);  
    int mid=(x+y)>>1;  
    if(r<=mid) change(rt<<1,x,mid,l,r,c);  
    else if(l>mid) change(rt<<1|1,mid+1,y,l,r,c);  
    else change(rt<<1,x,mid,l,mid,c),change(rt<<1|1,mid+1,y,mid+1,r,c);  
    if(tr[rt<<1].c!=tr[rt<<1|1].c) tr[rt].c=-1;  
    else tr[rt].c=tr[rt<<1].c;  
}  
bool check[110010];  
int ans=0;  
void solve(int x)  
{  
    int yu=tr[x].c;  
    if(yu!=-1)  
    {  
        if(!check[yu]) ans++;  
        check[yu]=1;  
        return;  
    }  
    solve(x<<1);solve(x<<1|1);  
}  
int main()  
{  
    scanf("%d",&n);  
    for(int i=1;i<=n;i++)  
    {  
        scanf("%d%d",&sa[i].x,&sa[i+n].x);  
        sa[i].num=sa[i+n].num=i;  
        sa[i].id=1;sa[i+n].id=2;  
    }  
    sort(sa+1,sa+1+2*n,cmp);  
    for(int i=1;i<=2*n;i++)  
    {  
        if(i==1||sa[i].x!=sa[i-1].x) num++;  
        ss[sa[i].num][sa[i].id]=num;  
    }  
    bt(1,1,n);  
    for(int i=1;i<=n;i++)  
    change(1,1,num,ss[i][1],ss[i][2],i);
    solve(1);  
    printf("%d\n",ans);  
}  
