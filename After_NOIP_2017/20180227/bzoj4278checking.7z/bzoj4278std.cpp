#include<cstdio>
#include<algorithm>
using namespace std;
const int maxn=400005;
int sa[maxn],rank[maxn];
int tmp1[maxn],tmp2[maxn],key[maxn],sum[maxn];
int a[maxn];
void getsa(int n,int m){
  int *rk=tmp1,*res=tmp2,i,j,p;
  for(i=0;i<m;++i)sum[i]=0;
  for(i=0;i<n;++i)sum[rk[i]=a[i]]++;
  for(i=1;i<m;++i)sum[i]+=sum[i-1];
  for(i=n-1;i>=0;--i){
    sa[--sum[rk[i]]]=i;
  }
  for(j=1,p=0;p<n;j<<=1,m=p){
    for(p=0,i=n-j;i<n;++i)res[p++]=i;
    for(i=0;i<n;++i)if(sa[i]>=j)res[p++]=sa[i]-j;
    for(i=0;i<n;++i)key[i]=rk[res[i]];
    for(i=0;i<m;++i)sum[i]=0;
    for(i=0;i<n;++i)sum[rk[i]]++;
    for(i=1;i<m;++i)sum[i]+=sum[i-1];
    for(i=n-1;i>=0;--i)sa[--sum[key[i]]]=res[i];
    for(res[sa[0]]=0,p=1,i=1;i<n;++i){
      if(sa[i]+j<n&&sa[i-1]+j<n&&rk[sa[i]]==rk[sa[i-1]]&&rk[sa[i]+j]==rk[sa[i-1]+j])res[sa[i]]=p-1;
      else res[sa[i]]=p++;
    }
    swap(rk,res);
  }
  for(int i=0;i<n;++i)rank[sa[i]]=i;
}
int main(){
  int n,m;scanf("%d",&n);
  for(int i=0;i<n;++i)scanf("%d",&a[i]);
  a[n]=100000;
  scanf("%d",&m);
  for(int i=1;i<=m;++i)scanf("%d",&a[n+i]);
  a[n+m+1]=100000;
  getsa(n+m+2,100001);
  
  int pt1=0,pt2=n+1;
  int lim=n+m;
  for(int i=1;i<=lim;++i){
    printf("%d ",rank[pt1]>rank[pt2]?a[pt2++]:a[pt1++]);
  }
  return 0;
}
