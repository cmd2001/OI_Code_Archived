#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000) {
    return rand() % r + 1;
}
inline void make(int len) {
    printf("%d\n",len);
    for(int i=1;i<=len;i++) printf("%d%c",_(),i!=len?' ':'\n');
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2e5 , m = 2e5;
    make(n),make(m);
    return 0;
}
