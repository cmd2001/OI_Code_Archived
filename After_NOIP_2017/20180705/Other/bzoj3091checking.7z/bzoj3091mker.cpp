#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 10000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    for(int i=1,o;i<=m;i++) {
        o = _(4);
        if( o <= 3 ) o = 3;
        if( o != 3 ) {
            int x = _(n) , y = _(n);
            while( x == y ) x = _(n) , y = _(n);
            printf("%d %d %d\n",o,x,y);
        } else printf("%d %d %d %d\n",o,_(n),_(n),_());
    }
    return 0;
}