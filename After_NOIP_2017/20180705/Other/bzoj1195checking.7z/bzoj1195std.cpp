#include<bits/stdc++.h>
using namespace std;
char s[55];
int n,cnt,fa[2000005],path[2000005];
bool b[1005][1<<12];
struct Node{
    Node *ch[26],*nex;
    int state,id;
    Node(){
        for(int i=0;i<26;++i)ch[i]=NULL;
        nex=NULL;state=0;id=++cnt;
    }
}*root=new Node;
inline void Insert(char s[],int id){
    Node *x=root;
    for(int i=1;s[i];++i){
        int to=s[i]-'A';
        if(!x->ch[to])  x->ch[to]=new Node;
        x=x->ch[to];
    }
    x->state|=1<<id>>1;
}
inline void GetFail(){
    queue<Node*>q;
    root->nex=root;
    for(int i=0;i<26;++i){
        if(root->ch[i])     q.push(root->ch[i]),root->ch[i]->nex=root;
        else    root->ch[i]=root;
    }
    while(!q.empty()){
        Node *x=q.front();q.pop();
        for(int i=0;i<26;++i){
            if(x->ch[i])    q.push(x->ch[i]),x->ch[i]->nex=x->nex->ch[i];
            else    x->ch[i]=x->nex->ch[i];
        }
        Node *tmp=x->nex;
        while(tmp!=root && !tmp->state) tmp=tmp->nex;
        x->state|=tmp->state;
    }
}
struct data{
    Node *node;
    int state,id;
    data(){}
    data(Node *a,int x,int y){node=a;state=x;id=y;}
};
void print(int x){
    if(!x)  return;
    print(fa[x]);
    printf("%c",path[x]+'A');
}
inline void bfs(){
    queue<data>q;
    q.push(data(root,root->state,cnt=0));b[root->id][root->state]=true;
    while(!q.empty()){
        data x=q.front();q.pop();
        if(x.state==(1<<n)-1){
            print(x.id);
            return;
        }
        for(int i=0;i<26;++i){
            int now=x.state|x.node->ch[i]->state;
            if(b[x.node->ch[i]->id][now])       continue;
            b[x.node->ch[i]->id][now]=true;
            fa[++cnt]=x.id;path[cnt]=i;
            q.push(data(x.node->ch[i],now,cnt));
        }
    }
}
int main(){
    scanf("%d",&n);
    for(int i=1;i<=n;++i){
        scanf("%s",s+1);
        Insert(s,i);
    }
    GetFail();  bfs() , puts("");
    return 0;
}