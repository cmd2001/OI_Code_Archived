#include<bits/stdc++.h>
using namespace std;

inline int _(int r=3) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5;
    printf("%d\n",n);
    while(n--) {
        int siz = _(5);
        while(siz--) putchar('A'+_()-1);
        putchar('\n');
    }
    return 0;
}
