#include<bits/stdc++.h>
using namespace std;
const int maxn=110;

char s[maxn];
double o[maxn][maxn];

inline double __() {
    return rand();
}
inline double _() {
    double x = __() , y = __();
    return y ? x / y : x;
}


int main() {
    srand((unsigned long long)new char);
    static int n = 100;
    printf("%d\n",n);
    for(int i=1;i<n;i++) for(int j=1;j<n;j++){
        sprintf(s,"%0.1lf",_());
        sscanf(s,"%lf",o[i]+j);
        o[i][n] += o[i][j] , o[n][j] += o[i][j];
     }
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=n;j++) printf("%0.1lf%c",o[i][j],j!=n?' ':'\n');
    }
    return 0;
}
