#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<cstdio>
#include<vector>
#include<queue>
#include<cmath>
#include<set>
#include<map>
#define N 40006
#define mx 1111111111
using namespace std;
int q[N],dis[N],du[N];
int head[N],nxt[N],lst[N],c[N];
double a[111][111];
int n,m,s,t,S,T,tot=1,sum,ans;
void insert(int x,int y,int z)
{
    lst[++tot]=y;nxt[tot]=head[x];head[x]=tot;c[tot]=z;
    lst[++tot]=x;nxt[tot]=head[y];head[y]=tot;c[tot]=0;
}
bool BFS()
{
    for(int i=1;i<=T;i++)dis[i]=0;
    dis[q[1]=S]=1;
    for(int l=1,r=2;l<r;l++)
    {
        int x=q[l];
        for(int i=head[x];i;i=nxt[i])
            if(c[i]&&!dis[lst[i]])
                dis[q[r++]=lst[i]]=dis[x]+1;
    }
    return dis[T];
}
int dfs(int x,int f)
{
    //cout << x <<" "<< f<< endl;
    if(x==T)return f;
    int ww=0,w;
    for(int i=head[x];i;i=nxt[i])
        if(c[i]&&dis[lst[i]]==dis[x]+1)
        {
            w=dfs(lst[i],min(c[i],f-ww));
            c[i]-=w,c[i^1]+=w,ww+=w;
            if(ww==f)return ww;
        }
    if(!ww)dis[x]=0;
    return ww;
}
void del(int x)
{
    for(int i=head[x];i;i=nxt[i])
        c[i]=c[i^1]=0;
}
int main()
{
    cin>>n;s=2*n+1,t=2*n+2,S=2*n+3,T=2*n+4;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
            scanf("%lf",&a[i][j]);
    for(int i=1;i<n;i++)
        for(int j=1;j<n;j++)
        {
            if(a[i][j]!=(int)a[i][j])insert(i,j+n,1);
            du[i]-=(int)a[i][j],du[j+n]+=(int)a[i][j];
        }
    for(int i=1;i<n;i++)
    {
        if(a[i][n]!=(int)a[i][n])insert(s,i,1);
        du[i]+=(int)a[i][n],du[s]-=(int)a[i][n];
    }
    for(int i=1;i<n;i++)
    {
        if(a[n][i]!=(int)a[n][i])insert(i+n,t,1);
        du[t]+=(int)a[n][i],du[i+n]-=(int)a[n][i];
    }
    for(int i=1;i<=t;i++)
        if(du[i]>0) insert(S,i,du[i]),sum+=du[i];
        else if(du[i]<0) insert(i,T,-du[i]);
    insert(t,s,mx);
    while(BFS())ans+=dfs(S,mx);
    //cout<<sum<<" "<< ans<<endl;
    if(ans!=sum)
    {
        puts("No");
        return 0;
    }
    del(S),del(T);
    S=s,T=t;ans=0;
    while(BFS())ans+=dfs(S,mx);
    cout<<ans*3;
    return 0;
}
