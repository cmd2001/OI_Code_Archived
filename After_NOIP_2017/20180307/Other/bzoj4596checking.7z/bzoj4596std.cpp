#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
#define Mod 1000000007
#define LL long long

int n,m[20],d[20];
struct data{int x,y;}e[20][400];
LL a[20][20];
LL ans;

LL fast_pow(LL a,int p)
{
    LL ans=1;
    for (;p;p>>=1,a=a*a%Mod)
        if (p&1)
            ans=ans*a%Mod;
    return ans;
}
LL gauss(int n)
{
    int flag=1;
    for (int i=1;i<=n;++i)
    {
        int num=i;
        for (int j=i+1;j<=n;++j)
            if (a[j][i]>a[num][i]) num=j;
        if (num!=i)
        {
            flag=-flag;
            for (int j=1;j<=n;++j) swap(a[i][j],a[num][j]);
        }
        for (int j=i+1;j<=n;++j)
        {
            LL t=a[j][i]*fast_pow(a[i][i],Mod-2)%Mod;
            for (int k=1;k<=n;++k)
                a[j][k]-=a[i][k]*t%Mod,a[j][k]=(a[j][k]%Mod+Mod)%Mod;
        }
    }
    LL ans=1;
    for (int i=1;i<=n;++i) ans=ans*a[i][i]%Mod;
    if (flag==-1) ans=(Mod-ans)%Mod;
    return ans;
}
int main()
{
    scanf("%d",&n);
    for (int i=1;i<n;++i)
    {
        scanf("%d",&m[i]);
        for (int j=1;j<=m[i];++j) scanf("%d%d",&e[i][j].x,&e[i][j].y);
    }
    for (int i=0;i<1<<(n-1);++i)
    {
        int opt=0;
        memset(d,0,sizeof(d));
        memset(a,0,sizeof(a));
        for (int j=0;j<n-1;++j)
            if ((i>>j)&1)
            {
                ++opt;
                for (int k=1;k<=m[j+1];++k)
                {
                    int x=e[j+1][k].x,y=e[j+1][k].y;
                    --a[x][y];--a[y][x];
                    ++d[x];++d[y];
                }
            }
        opt=n-1-opt;
        for (int i=1;i<=n;++i) a[i][i]=d[i];
        for(int i=1;i<=n;i++) for(int j=1;j<=n;j++) a[i][j] = ( a[i][j] % Mod + Mod ) % Mod;
        /*for(int i=1;i<=n;i++) {
            for(int j=1;j<=n;j++) printf("%d ",a[i][j]);
            puts("");
        }*/
        LL t=gauss(n-1);
        //printf("t = %lld\n",t);
        if (opt&1) ans-=t;
        else ans+=t;
        ans=(ans%Mod+Mod)%Mod;
    }
    printf("%lld\n",ans);
}
