#include<bits/stdc++.h>
const int maxn=21;

inline int _(int r) {
    return rand() % r + 1;
}
int v[maxn][maxn];

int main() {
    srand((unsigned long long)new char);
    static int n = 17;
    printf("%d\n",n);
    for(int i=1;i<n;i++) {
        memset(v,0,sizeof(v));
        for(int i=1;i<=n;i++) v[i][i] = 1;
        int t = _(n*n>>2);
        printf("%d%c",t,t?' ':'\n');
        while(t--) {
            int x = _(n) , y = _(n);
            while( v[x][y] ) x = _(n) , y = _(n);
            v[x][y] = v[y][x] = 1;
            printf("%d %d%c",x,y,t?' ':'\n');
        }
    }
    return 0;
}
