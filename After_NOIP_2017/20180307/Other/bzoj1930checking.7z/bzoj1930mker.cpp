#include<bits/stdc++.h>
using namespace std;

inline int _(int r = 100) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int t = 3;
    printf("%d\n",t);
    while(t--) printf("%d %d\n",_(),_());
    return 0;
}
