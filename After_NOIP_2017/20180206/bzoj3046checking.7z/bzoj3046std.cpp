#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<queue>

using namespace std;

const double pi=acos(-1.0);
const double big=4-0.5*pi;
const double small=0.25*pi;

int map[101][101];
int col[101][101][3]={0};
int list[501][501];

double all[10001];

struct P{
    int x,y,k;
}now;
queue<P> q;

int n,m,qq;

inline void flod(int x,int y,int k,int cnt)
{
    now.x=x;
    now.y=y;
    now.k=k;
    q.push(now);
    while(!q.empty())
    {
        now=q.front();
        q.pop();
        if(col[now.x][now.y][now.k])
            continue;
        col[now.x][now.y][now.k]=cnt;
        if(now.k!=1)
            all[cnt]+=small;
        else
            all[cnt]+=big;
        if(map[now.x][now.y]==0)
        {
            if(now.k==0)
            {
                if(now.x-1)
                {
                    if(map[now.x-1][now.y]==0)
                        q.push((P){now.x-1,now.y,1});
                    else
                        q.push((P){now.x-1,now.y,2});
                }
                if (now.y-1)
                {
                    if(map[now.x][now.y-1]==0)
                        q.push((P){now.x,now.y-1,1});
                    else
                        q.push((P){now.x,now.y-1,0});
                }
            }
            if(now.k==1)
            {
                if(now.x-1)
                {
                    if(map[now.x-1][now.y]==0)
                        q.push((P){now.x-1,now.y,2});
                    else
                        q.push((P){now.x-1,now.y,1});
                }
                if (now.y-1)
                {
                    if(map[now.x][now.y-1]==0)
                        q.push((P){now.x,now.y-1,2});
                    else
                        q.push((P){now.x,now.y-1,1});
                }
                if(now.x+1<=n)
                {
                    if(map[now.x+1][now.y]==0)
                        q.push((P){now.x+1,now.y,0});
                    else
                        q.push((P){now.x+1,now.y,1});
                }
                if (now.y+1<=m)
                {
                    if(map[now.x][now.y+1]==0)
                        q.push((P){now.x,now.y+1,0});
                    else
                        q.push((P){now.x,now.y+1,1});
                }
            }
            if(now.k==2)
            {
                if(now.x+1<=n)
                {
                    if(map[now.x+1][now.y]==0)
                        q.push((P){now.x+1,now.y,1});
                    else
                        q.push((P){now.x+1,now.y,0});
                }
                if(now.y+1<=m)
                {
                    if(map[now.x][now.y+1]==0)
                        q.push((P){now.x,now.y+1,1});
                    else
                        q.push((P){now.x,now.y+1,2});
                }
            }
        }
        else
        {
            if(now.k==0)
            {
                if(now.x-1)
                {
                    if(map[now.x-1][now.y]==0)
                        q.push((P){now.x-1,now.y,2});
                    else
                        q.push((P){now.x-1,now.y,1});
                }
                if(now.y+1<=m)
                {
                    if(map[now.x][now.y+1]==0)
                        q.push((P){now.x,now.y+1,0});
                    else
                        q.push((P){now.x,now.y+1,1});
                }
            }
            if(now.k==1)
            {
                if(now.x-1)
                {
                    if(map[now.x-1][now.y]==0)
                        q.push((P){now.x-1,now.y,1});
                    else
                        q.push((P){now.x-1,now.y,2});
                }
                if(now.y-1)
                {
                    if(map[now.x][now.y-1]==0)
                        q.push((P){now.x,now.y-1,1});
                    else
                        q.push((P){now.x,now.y-1,0});
                }
                if(now.x+1<=n)
                {
                    if(map[now.x+1][now.y]==0)
                        q.push((P){now.x+1,now.y,1});
                    else
                        q.push((P){now.x+1,now.y,0});
                }
                if(now.y+1<=m)
                {
                    if(map[now.x][now.y+1]==0)
                        q.push((P){now.x,now.y+1,1});
                    else
                        q.push((P){now.x,now.y+1,2});
                }
            }
            if(now.k==2)
            {
                if(now.x+1<=n)
                {
                    if(map[now.x+1][now.y]==0)
                        q.push((P){now.x+1,now.y,0});
                    else
                        q.push((P){now.x+1,now.y,1});
                }
                if(now.y-1)
                {
                    if(map[now.x][now.y-1]==0)
                        q.push((P){now.x,now.y-1,2});
                    else
                        q.push((P){now.x,now.y-1,1});
                }
            }
        }
    }
}
int main()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;++i)
        for (int j=1;j<=m;++j)
        {
            char ch;ch=getchar();
            while(ch!='1'&&ch!='0')
                ch=getchar();
            map[i][j]=ch-'0';
        }
    scanf("%d",&qq);
    int cnt=0;
    for(int i=1;i<=n;++i)
        for(int j=1;j<=m;++j)
            for(int k=0;k<=2;++k)
                if(!col[i][j][k])
                    flod(i,j,k,++cnt);
    for(int i=1;i<=n;++i)
        for(int j=1;j<=m;++j)
        {
            int xx=i-1,yy=j-1;
            if (map[i][j]==0)
            {
                list[xx*2][yy*2]=col[i][j][0];
                list[xx*2+1][yy*2+1]=col[i][j][1];
                list[xx*2+2][yy*2]=col[i][j][1];
                list[xx*2][yy*2+2]=col[i][j][1];
                list[xx*2+2][yy*2+2]=col[i][j][2];
            }
            if (map[i][j])
            {
                list[xx*2][yy*2]=col[i][j][1];
                list[xx*2+1][yy*2+1]=col[i][j][1];
                list[xx*2+2][yy*2+2]=col[i][j][1];
                list[xx*2+2][yy*2]=col[i][j][2];
                list[xx*2][yy*2+2]=col[i][j][0];
            }
        }
    while (qq--)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        if((x%2)!=(y%2))
        {
            printf("0.0000\n");
            continue;
        }
        printf("%.4f\n",all[list[x][y]]);
    }
}
