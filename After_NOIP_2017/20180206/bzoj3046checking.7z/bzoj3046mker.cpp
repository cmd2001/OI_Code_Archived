#include<bits/stdc++.h>
using namespace std;

inline int _(int x) {
    return rand() % x;
}

int main() {
    srand((unsigned long long)new char);
    int n = 100 , m = 100 , q = 250000;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) putchar('0'+_(2));
        puts("");
    }
    printf("%d\n",q);
    while( q-- ) {
        int t = _(n*2+1) , p = _(m*2+1);
        if( q & 1 ) while( ( t&1) != (p&1) ) t = _(n*2+1) , p = _(m*2+1);
        printf("%d %d\n",t,p);
    }
    return 0;
}
