#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e6;
    printf("%d\n",n);
    for(int i=1;i<=n;i++)
        printf("%d%c",_(n),i!=n?' ':'\n');
    return 0;
}
