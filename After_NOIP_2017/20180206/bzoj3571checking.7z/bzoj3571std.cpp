#include<cstdio>  
#include<cstring>  
#include<iostream>  
#include<algorithm>  
const int maxn=75,inf=1061109567;  
using namespace std;  
struct poi{int x,y;}le,ri;  
int cas,n,A[maxn][maxn],B[maxn][maxn],g[maxn][maxn],lx[maxn],ly[maxn],mat[maxn],sla[maxn];  
bool vx[maxn],vy[maxn];  
bool operator ==(poi a,poi b){return a.x==b.x&&a.y==b.y;}  
  
bool dfs(int x){  
    vx[x]=1;  
    for (int y=1;y<=n;y++)  
        if (!vy[y]){  
            int t=lx[x]+ly[y]-g[x][y];  
            if (!t){  
                vy[y]=1;  
                if (!mat[y]||dfs(mat[y])){mat[y]=x;return 1;}  
            }  
            else sla[y]=min(sla[y],t);  
        }  
    return 0;  
}  
  
poi KM(){  
    memset(lx,0,sizeof(lx)),memset(ly,0,sizeof(ly)),memset(mat,0,sizeof(mat));  
    for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) lx[i]=max(lx[i],g[i][j]);  
    for (int x=1;x<=n;x++){  
        memset(sla,63,sizeof(sla));  
        for (;;){  
            memset(vx,0,sizeof(vx));memset(vy,0,sizeof(vy));  
            if (dfs(x)) break;  
            int d=inf;  
            for (int i=1;i<=n;i++) if (!vy[i]) d=min(d,sla[i]);  
            for (int i=1;i<=n;i++){  
                if (vx[i]) lx[i]-=d;  
                if (vy[i]) ly[i]+=d;  
            }  
        }  
    }  
    poi ans=(poi){0,0};  
    for (int i=1;i<=n;i++) ans.x+=A[mat[i]][i],ans.y+=B[mat[i]][i];  
    return ans;  
}  
  
int solve(poi l,poi r){  
    for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) g[i][j]=A[i][j]*(r.y-l.y)+B[i][j]*(l.x-r.x);  
    poi mid=KM();
    //printf("%d %d\n",mid.x,mid.y);
    if (l==mid||r==mid) return min(l.x*l.y,r.x*r.y);
    return min(solve(l,mid),solve(mid,r));  
}  
  
int main(){  
    scanf("%d",&cas);  
    for (int pp=1;pp<=cas;pp++){  
        scanf("%d",&n);  
        for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) scanf("%d",&A[i][j]);  
        for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) scanf("%d",&B[i][j]);  
        for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) g[i][j]=-A[i][j];le=KM();  
        for (int i=1;i<=n;i++) for (int j=1;j<=n;j++) g[i][j]=-B[i][j];ri=KM();  
        //printf("%d %d\n%d %d\n",le.x,le.y,ri.x,ri.y);
        printf("%d\n",solve(le,ri));  
    }  
    return 0;  
}  
