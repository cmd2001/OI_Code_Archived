#include<bits/stdc++.h>
using namespace std;

int main() {
    srand((unsigned long long)new char);
    static int T = 7 , n = 10;
    printf("%d\n",T);
    while(T--) {
        printf("%d\n",n);
        for(int tt=0;tt<2;tt++)
            for(int i=1;i<=n;i++) {
                for(int j=1;j<=n;j++) printf("%d%c",rand()%101+100,j!=n?' ':'\n');
            }
    }
    return 0;
}
