#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli Rand() {
    return rand() | (rand()<<15);
}

int main() {
    freopen("dat.txt","w",stdout);
    int n = 500;
    printf("%d\n",n);
    for(int i=1;i<=n;i++)
        printf("%lld %lld\n",Rand(),Rand());
    return 0;
}
