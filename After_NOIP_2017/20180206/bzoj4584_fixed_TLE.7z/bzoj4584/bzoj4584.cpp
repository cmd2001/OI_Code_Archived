#pragma GCC optimize(3)
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cctype>
#define lli long long int
const int maxn=1e3+1e2+1;
const int mod=1e9+7;

int l[maxn],r[maxn],srt[maxn],cnt[maxn][maxn],len;
lli f[maxn][maxn],sum[maxn][maxn],c[maxn][maxn],cp[maxn][maxn],inv[maxn],ans;
int n;

inline void gen() {
    for(int i=1;i<=n;i++)
        srt[++len] = l[i] , srt[++len] = r[i] + 1;
    std::sort(srt+1,srt+1+len) , len = std::unique(srt+1,srt+1+len) - srt - 1;
    for(int i=1;i<=n;i++)
        l[i] = std::lower_bound(srt+1,srt+1+len,l[i]) - srt ,
        r[i] = std::lower_bound(srt+1,srt+1+len,r[i]+1) - srt ;
    c[0][0] = 1;
    for(int i=1;i<=n;i++) {
        c[i][0] = 1;
        for(int j=1;j<=i;j++)
            c[i][j] = ( c[i-1][j] + c[i-1][j-1] ) % mod;
    }
    inv[0] = inv[1] = 1;
    for(int i=2;i<=n;i++) inv[i] = ( mod - mod / i ) * inv[mod%i] % mod;
    for(int i=1;i<len;i++) {
        cp[i][0] = 1;
        for(int j=1;j<=n;j++)
            cp[i][j] = cp[i][j-1] * ( srt[i+1] - srt[i] - j + 1 ) % mod * inv[j] % mod;
    }
    for(int i=1;i<len;i++)
        for(int j=1;j<=n;j++)
            for(int k=0;k<j;k++)
                sum[i][j] = ( sum[i][j] + cp[i][k+1] * c[j-1][k] % mod ) % mod;
}
inline void dp() {
    for(int i=0;i<len;i++) f[0][i] = 1;
    for(int i=1;i<=n;i++) {
        memcpy(cnt[i],cnt[i-1],sizeof(cnt[i-1]));
        for(int j=l[i];j<r[i];j++) {
            ++cnt[i][j];
            for(int k=i;k;k--) {
                f[i][j] += f[k-1][j-1] * sum[j][cnt[i][j]-cnt[k-1][j]] % mod;
            }
        }
        for(int j=1;j<len;j++)
            f[i][j] = ( f[i][j] + f[i][j-1] ) % mod;
    }
    for(int i=1;i<=n;i++)
        ans = ( ans + f[i][len-1] ) % mod;
    printf("%lld\n",ans);
}

inline char nextchar() {
    #define BS (1<<15)
    static char buf[BS],*st=buf+BS,*ed=buf+BS;
    if( st == ed ) ed = buf + fread(st=buf,1,BS,stdin);
    return st == ed ? -1 : *st++;
}
inline int getint() {
    int ret = 0 , ch;
    while( !isdigit(ch=nextchar()) );
    do ret=ret*10+ch-'0'; while( isdigit(ch=nextchar()) );
    return ret;
}
int main() {
    n = getint();
    for(int i=1;i<=n;i++)
        l[i] = getint() , r[i] = getint();
    gen();
    dp();
    
    return 0;
}


