#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli lli_rand() {
    return rand() | (rand()<<15) | ((lli)rand()<<31);
}
int main() {
    srand((unsigned long long)new char);
    static int n = 999 , m = 99;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++)
            printf("%lld ",lli_rand()%1000000000+1);
        puts("");
    }
    return 0;
}
