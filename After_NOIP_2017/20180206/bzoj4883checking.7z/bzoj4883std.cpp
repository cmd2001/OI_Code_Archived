#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
typedef long long ll;
int n,m,now,cnt;
ll ans,temp;
int va[200010],vb[200010],to[200010],next[200010],head[200010],from[200010];
ll la[200010],lb[200010],val[200010];
int rd()
{
    int ret=0;  char gc=getchar();
    while(gc<'0'||gc>'9') gc=getchar();
    while(gc>='0'&&gc<='9')   ret=ret*10+gc-'0',gc=getchar();
    return ret;
}
void add(int a,int b,int c)
{
    to[cnt]=b,val[cnt]=c,next[cnt]=head[a],head[a]=cnt++;
}
int dfs(int x)
{
    va[x]=now;
    for(int i=head[x];i!=-1;i=next[i])
    {
        if(vb[to[i]]!=now)
        {
            if(!(la[x]+lb[to[i]]-val[i]))
            {
                vb[to[i]]=now;
                if(!from[to[i]]||dfs(from[to[i]]))
                {
                    from[to[i]]=x;
                    return 1;
                }
            }
            else    temp=min(temp,la[x]+lb[to[i]]-val[i]);
        }
    }
    return 0;
}
int main()
{
    n=rd(),m=rd();
    int i,j,a;
    ll b;
    memset(head,-1,sizeof(head));
    memset(la,0x80,sizeof(la));
    for(i=1;i<=n;i++)
        for(j=1;j<=m;j++)
            a=(i-1)*m+j,b=-rd(),add(i,a,b),la[i]=max(la[i],b),add(j+n,a,b),la[j+n]=max(la[j+n],b);
    //for(int i=1;i<=n+m;i++) printf("%d ",la[i]);puts("");
    for(i=1;i<=n+m;i++)
    {
        while(1)
        {
            now++;
            temp=1ll<<60;
            if(dfs(i))  break;
            //printf("i = %d\n",i);
            //printf("tp = %lld\n",temp);
            for(j=1;j<=n+m;j++)  if(va[j]==now)  la[j]-=temp;
            for(j=1;j<=n*m;j++)  if(vb[j]==now)  lb[j]+=temp;
        }
    }
    for(i=1;i<=n+m;i++)  ans+=la[i] ;//, printf("%d ",la[i]); puts("");
    for(i=1;i<=n*m;i++)  ans+=lb[i] ;//, printf("%d ",lb[i]); puts("");
    printf("%lld",-ans);
    return 0;
}
