#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

struct Node {
    int x,y;
    friend bool operator < (const Node &a,const Node &b) {
        return a.x != b.x ? a.x < b.x : a.y < b.y;
    }
};

multiset<Node> ns;

int main() {
    freopen("dat.txt","w",stdout);
    srand((unsigned long long)new char^time(0));
    static int n = 1000 , m = 1000 , q = 1000;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    printf("%d\n",m);
    for(int i=1,a,b;i<=m;i++) a = _(n) , b = _(n) , printf("%d %d\n",a,b) , ns.insert((Node){min(a,b),max(a,b)});
    printf("%d\n",q);
    for(int i=1,a,b;i<=q;i++) {
        int o = _(3);
        if( o == 1 && !ns.size() ) o = _(2) + 1;
        if( o == 1 || o == 2 ) o = 3 - o;
        o = 1;
        if( o == 2 ) {
            int d = _(ns.size()) - 1;
            auto t = ns.begin();
            while(d--) ++t;
            printf("2 %d %d\n",t->x,t->y) , ns.erase(t);
        } else if( o == 1 ) a = _(n) , b = _(n) , printf("1 %d %d\n",a,b) , ns.insert((Node){min(a,b),max(a,b)});
        else {
            a = _(n) , b = _(n);
            while( a == b ) a = _(n) , b = _(n);
            printf("3 %d %d\n",a,b);
        }
    }
    return 0;
}