#include<bits/stdc++.h>
#define debug cout
using namespace std;
const int maxn=3e3+1e2;

struct Node {
    int x,y;
    friend bool operator < (const Node &a,const Node &b) {
        return a.x != b.x ? a.x < b.x : a.y < b.y;
    }
};

multiset<Node> ns;

int s[maxn],t[maxn<<1],nxt[maxn<<1];
int dep[maxn],fa[maxn],col[maxn];

inline void addedge(int from,int to) {
    static int cnt;
    t[++cnt] = to , nxt[cnt] = s[from] , s[from] = cnt;
}
inline void pre(int pos) {
    for(int at=s[pos];at;at=nxt[at]) if( t[at] != fa[pos] ) dep[t[at]] = dep[fa[t[at]]=pos] + 1 , pre(t[at]);
}
inline int lca(int x,int y) {
    if( dep[x] < dep[y] ) swap(x,y);
    while( dep[x] > dep[y] ) x = fa[x];
    if( x == y ) return x;
    while( fa[x] != fa[y] ) x = fa[x] , y = fa[y];
    return fa[x];
}
inline void mrkchain(int f,int s,int c) {
    s = fa[s];
    while( s != f ) col[s] = c , s = fa[s];
}
inline void dfs(int pos,int fa,int c) {
    col[pos] = c;
    for(int at=s[pos];at;at=nxt[at]) if( t[at] != fa && col[t[at]] != -1 ) dfs(t[at],pos,c);
}
inline int query(int x,int y) {
    int l = lca(x,y) , ret = 0;
    if( l != x && l != y ) {
        mrkchain(l,x,-1) , mrkchain(l,y,-1) , col[l] = -1;
        dfs(x,y,1) , dfs(y,x,2);
        for(auto &t:ns) if( ( col[t.x] == 1 && col[t.y] == 2 ) || ( col[t.x] == 2 && col[t.y] == 1 ) ) ++ret;
        dfs(x,y,0) , dfs(y,x,0); 
        mrkchain(l,x,0) , mrkchain(l,y,0) , col[l] = 0;
    } else {
        if( l != x ) swap(x,y);
        mrkchain(x,y,-1);
        dfs(x,y,1) , dfs(y,x,2);
        for(auto &t:ns) if( ( col[t.x] == 1 && col[t.y] == 2 ) || ( col[t.x] == 2 && col[t.y] == 1 ) ) ++ret;
        dfs(x,y,0) , dfs(y,x,0); 
        mrkchain(x,y,-0);
    }
    return ret;
}

int main() {
    static int n,m;
    scanf("%d",&n);
    for(int i=1,a,b;i<n;i++) scanf("%d%d",&a,&b) , addedge(a,b) , addedge(b,a);
    pre(1) , scanf("%d",&m);
    for(int i=1,a,b;i<=m;i++) scanf("%d%d",&a,&b) , ns.insert((Node){min(a,b),max(a,b)});
    scanf("%d",&m);
    for(int i=1,o,x,y;i<=m;i++) {
        scanf("%d%d%d",&o,&x,&y);
        if( o == 1 ) ns.insert((Node){min(x,y),max(x,y)});
        else if( o == 2 ) ns.erase(ns.find((Node){min(x,y),max(x,y)}));
        else if( o == 3 ) assert(x!=y) , printf("%d\n",query(x,y)); // if x == y , it will be an undefined input data .
    }
    return 0;
}
