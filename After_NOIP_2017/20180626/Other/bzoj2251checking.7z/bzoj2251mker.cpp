#include<bits/stdc++.h>
using namespace std;

inline int _(int r=2) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3000;
    printf("%d\n",n);
    while(n--) putchar('0'+_());
    puts("");
    return 0;
}