#include <cstdio>  
#include <cstring>  
#include <algorithm>  
  
using namespace std;  
  
const int MAX_N = 3005;  
  
int n;  
char s[MAX_N];  
  
void init()  
{  
    scanf("%d%s", &n, s + 1);   
}  
  
struct Trie {  
    int ch[2], cnt;  
} t[MAX_N * MAX_N];  
int sz = 0;  
  
void insert(char *s)  
{  
    int u = 0, l = strlen(s);  
    for (int i = 0; i < l; i ++) {  
        int c = s[i] - '0';  
        if (!t[u].ch[c]) t[u].ch[c] = ++ sz;  
        u = t[u].ch[c];  
        t[u].cnt ++;  
    }  
}  
  
void dfs(int u)  
{  
    if (t[u].cnt > 1) printf("%d\n", t[u].cnt);  
    if (t[t[u].ch[0]].cnt > 1) dfs(t[u].ch[0]);  
    if (t[t[u].ch[1]].cnt > 1) dfs(t[u].ch[1]);  
}  
  
void doit()  
{  
    for (int i = 1; i <= n; i ++)   
        insert(s + i);  
    dfs(0);  
}  
  
int main()  
{  
    //freopen("bzoj2251.in", "r", stdin);  
    init();  
    doit();  
    return 0;  
}  