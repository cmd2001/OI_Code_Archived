#include<bits/stdc++.h>
using namespace std;
bitset<120000> vis;

inline double _() {
    return (double) (rand()-rand()) / (rand()-rand());
}
int main() {
    srand((unsigned long long)new char);
    static int n = 1.2e5 , siz = 0 , cnt = 0;
    printf("%d\n",n);
    for(int i=1,o,tim=0;i<=n;i++) {
        //if( ! ( i % 1000) ) cerr<<"i = "<<i<<endl;
        o = rand() % 3;
        if( !o ) {
            ++siz , ++cnt;
            if( ( rand() & 3 ) == 1 ) {
                double x = _();
                printf("0 %lf %lf %lf %lf\n",x,_(),x,_());
            }
            else printf("0 %lf %lf %lf %lf\n",_(),_(),_(),_());
        } else if( o == 1 ) {
            if( ( ( rand() & 15 ) != 1 ) || !cnt ) {
                --i ; continue;
            }
            --cnt , tim = 0;
            int p = rand() % siz + 1;
            while( vis[p] && tim <= 100 ) p = rand() % siz + 1 , ++tim;
            if( vis[p] ) {
                p = 1;
                while( vis[p] ) ++p;
            }
            vis[p] = 1;
            printf("1 %d\n",p);
        } else printf("2\n");
    }
    return 0;
}
