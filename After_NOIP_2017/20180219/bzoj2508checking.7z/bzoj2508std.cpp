#include<cstdio>
#include<cmath>
#define N 120010
int n,q,op,i,m;
double X1,X2,Y1,Y2,a,b,c,d,aa[N],bb[N],cc[N],ab[N],ac[N],bc[N],saa,sbb,scc,sab,sac,sbc,eps=1e-8,ans;
inline bool zero(double x){return std::fabs(x)<eps;}
inline double solve(double a,double b,double c){
  if(zero(a))return c;
  double x=-b/(2.0*a);
  return a*x*x+b*x+c;
}
int main(){
  scanf("%d",&q);
  while(q--){
    scanf("%d",&op);
    if(op==0){
      scanf("%lf%lf%lf%lf",&X1,&Y1,&X2,&Y2);
      if(zero(X1-X2))a=1,b=0,c=-X1;else a=(Y2-Y1)/(X2-X1),b=-1,c=Y1-a*X1;
      d=a*a+b*b;
      aa[++n]=a*a/d,bb[n]=b*b/d,cc[n]=c*c/d,ab[n]=a*b/d,ac[n]=a*c/d,bc[n]=b*c/d;
      saa+=aa[n],sbb+=bb[n],scc+=cc[n],sab+=ab[n],sac+=ac[n],sbc+=bc[n];
      m++;
    }
    if(op==1){
      scanf("%d",&i);
      saa-=aa[i],sbb-=bb[i],scc-=cc[i],sab-=ab[i],sac-=ac[i],sbc-=bc[i];
      m--;
    }
    if(op==2){
      if(!m){puts("0.00");continue;}
      if(zero(sbb))a=b=0;else a=-sab/sbb,b=-sbc/sbb;
      ans=solve(saa+2.0*a*sab+a*a*sbb,2.0*(b*sab+sac+a*b*sbb+a*sbc),b*b*sbb+2.0*b*sbc+scc);
      if(zero(ans))ans=0;
      printf("%.2f\n",ans);
    }
  }
  return 0;
}
