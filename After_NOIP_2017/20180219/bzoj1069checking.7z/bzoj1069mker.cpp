#include<bits/stdc++.h>
using namespace std;

inline double _() {
    if( rand() & 1 ) return (double)( ( ( rand() & 1 ) ?  1e5 : -1e5 ) + rand()-rand()) / ( rand() % 10 + 1);
    else return ( (double) rand() - rand() ) / ( rand() - rand() );
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2e3;
    printf("%d\n",n);
    while( n-- ) printf("%lf %lf\n",_(),_());
    return 0;
}
