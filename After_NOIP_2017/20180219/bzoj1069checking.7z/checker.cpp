#include<bits/stdc++.h>
using namespace std;

int main() {
    static int cse = 0;
    while( 1 ) {
        printf("Making Data\n");
        system("bzoj1069mker.exe > dat.txt");
        printf("Data Made\n");
        printf("Running Mine\n");
        system("bzoj1069.exe < dat.txt > my.txt");
        printf("Running std\n");
        system("bzoj1069std.exe < dat.txt > std.txt");
        if( system("fc my.txt std.txt") ) {
            puts("====================!!!WA!!!===================");
            getchar() , getchar();
        }
    }
}
