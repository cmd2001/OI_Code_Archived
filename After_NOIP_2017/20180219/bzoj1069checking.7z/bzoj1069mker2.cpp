#include<bits/stdc++.h>
using namespace std;

inline void moveu(double &x,double &y,const double &k,const double &dis) {
    const double full = sqrt( k * k + 1 );
    x += dis / full , y += dis * k / full;
}
inline void moved(double &x,double &y,const double &k,const double &dis) {
    const double full = sqrt( k * k + 1 );
    x -= dis / full , y += dis * k / full;
}
inline double dslop() {
    return (double)rand()/1e4;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 2000;
    double x = rand() , y = rand() , k = rand() , dis = 100;
    printf("%d\n",n);
    for(int i=1;i<=n/2;i++) {
        printf("%lf %lf\n",x,y); 
        moveu(x,y,k,dis) , k -= dslop();
    }
    k = -rand();
    for(int i=1;i<=n/2;i++) {
        moved(x,y,k,dis) , k +=dslop();
        printf("%lf %lf\n",x,y);
    }
    return 0;
}
