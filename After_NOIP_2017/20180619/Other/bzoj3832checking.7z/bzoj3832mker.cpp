#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 7;
    for(int i=1;i<=m;i++) {
        int a = _(n) , b = _(n);
        while( a == b ) a = _(n) , b = _(n);
        printf("%d %d\n",min(a,b),max(a,b));
    }
    return 0;
}
