#include <cstdio>  
#include <cstring>  
#include <iostream>  
#include <algorithm>  
#define M 1001001  
using namespace std;  
struct abcd{  
    int to,next;  
}table[M<<1];  
int head[M],_head[M],tot;  
int n,m,ans,ans_len=0x3f3f3f3f;  
int degree[M],a[M],f[M],g[M];  
void Add(int head[],int x,int y)  
{  
    table[++tot].to=y;  
    table[tot].next=head[x];  
    head[x]=tot;  
}  
namespace Heap{  
    int heap[M],mark[M],top;  
    void Insert(int x)  
    {  
        if(mark[x])  
        {  
            --mark[x];  
            return ;  
        }  
        heap[++top]=x;  
        int t=top;  
        while(t>1)  
        {  
            if(heap[t]>heap[t>>1])  
                swap(heap[t],heap[t>>1]),t>>=1;  
            else  
                break;  
        }  
    }  
    void Delete(int x)  
    {  
        mark[x]++;  
    }  
    void Pop()  
    {  
        heap[1]=heap[top--];  
        int t=2;  
        while(t<=top)  
        {  
            if( t<top && heap[t+1]>heap[t] )  
                t++;  
            if(heap[t]>heap[t>>1])  
                swap(heap[t],heap[t>>1]),t<<=1;  
            else  
                break;  
        }  
    }  
    int Top()  
    {  
        while(mark[heap[1]])  
            mark[heap[1]]--,Pop();  
        return heap[1];  
    }  
}  
void Topology_Sort()  
{  
    static int q[M],r,h;  
    int i;  
    for(i=1;i<=n;i++)  
        if(!degree[i])  
            q[++r]=i;  
    while(r!=h)  
    {  
        int x=q[++h];  
        for(i=head[x];i;i=table[i].next)  
            if(!--degree[table[i].to])  
                q[++r]=table[i].to;  
    }  
    memcpy(a,q,sizeof a);  
}  
int main()  
{  
    using namespace Heap;  
    int i,j,x,y;  
    cin>>n>>m;  
    for(i=1;i<=m;i++)  
    {  
        scanf("%d%d",&x,&y);  
        degree[y]++;  
        Add(head,x,y);  
        Add(_head,y,x);  
    }  
    Topology_Sort();  
    for(j=1;j<=n;j++)  
    {  
        x=a[j];  
        f[x]=max(f[x],1);  
        for(i=head[x];i;i=table[i].next)  
            f[table[i].to]=max(f[table[i].to],f[x]+1);  
    }  
    for(j=n;j;j--)  
    {  
        x=a[j];  
        g[x]=max(g[x],1);  
        for(i=head[x];i;i=table[i].next)  
            g[x]=max(g[x],g[table[i].to]+1);  
    }  
    for(i=1;i<=n;i++)  
        Insert(g[i]);  
    Insert(0);  
    for(j=1;j<=n;j++)  
    {  
        x=a[j];  
        for(i=_head[x];i;i=table[i].next)  
            Delete(f[table[i].to]+g[x]);  
        Delete(g[x]);  
        if(Top()<ans_len)  
            ans_len=Top(),ans=x;  
        for(i=head[x];i;i=table[i].next)  
            Insert(f[x]+g[table[i].to]);  
        Insert(f[x]);  
    }  
    cout<<ans<<' '<<ans_len-1<<endl;  
    return 0;  
}  
