#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define M 200200
using namespace std;

struct abcd{
    int to,next;
}table[M<<1];
int head[M],tot;

int n,m,d;
int degree[M];
bool deleted[M];
int v[M];
int q[M],r,h;
int size,ans,ans_point;
int stack[M],top;

void Add(int x,int y)
{
    table[++tot].to=y;
    table[tot].next=head[x];
    head[x]=tot;
}

void DFS(int x)
{
    int i;
    if(v[x]||deleted[x])
        return ;
    v[x]=1;++size;
    for(i=head[x];i;i=table[i].next)
        DFS(table[i].to);
}

void Output_Ans(int x)
{
    int i;
    if(v[x]==2||deleted[x])
        return ;
    v[x]=2;
    stack[++top]=x;
    for(i=head[x];i;i=table[i].next)
        Output_Ans(table[i].to);
}

int main()
{
    int i,x,y;
    cin>>n>>m>>d;
    for(i=1;i<=m;i++)
    {
        scanf("%d%d",&x,&y);
        Add(x,y);Add(y,x);
        degree[x]++;
        degree[y]++;
    }
    for(i=1;i<=n;i++)
        if(degree[i]<d)
            q[++r]=i;
    while(r!=h)
    {
        int x=q[++h];deleted[x]=true;
        for(i=head[x];i;i=table[i].next)
            if(degree[table[i].to]--==d)
                q[++r]=table[i].to;
    }
    if(r==n)
    {
        puts("NIE");
        return 0;
    }
    for(i=1;i<=n;i++)
        if(!deleted[i]&&!v[i])
        {
            size=0;
            DFS(i);
            if(size>ans)
                ans=size,ans_point=i;
        }
    cout<<ans<<endl;
    Output_Ans(ans_point);
    sort(stack+1,stack+top+1);
    for(i=1;i<=top;i++)
        printf("%d%c",stack[i],i==top?'\n':' ');
    return 0;
}