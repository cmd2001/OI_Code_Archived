#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char ^ time(0));
    static int n = 100000 , m = 200000 , d = _(10)+1;
    printf("%d %d %d\n",n,m,d);
    for(int i=1,a,b;i<=m;i++) {
        a = _(n) , b = _(n);
        while( a==b ) a = _(n) , b = _(n);
        printf("%d %d\n",a,b);
    }
}