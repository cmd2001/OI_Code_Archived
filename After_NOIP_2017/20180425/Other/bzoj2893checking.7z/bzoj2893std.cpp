#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
using namespace std;
int read()
{
    int x=0,f=1; char ch=getchar();
    while (ch<'0' || ch>'9') {if (ch=='-') f=-1; ch=getchar();}
    while (ch>='0' && ch<='9') {x=x*10+ch-'0'; ch=getchar();}
    return x*f;
}
#define maxm 100100
#define maxn 2010
int n,m,A,B,t,ans,cost;
struct Edgenode{int to,next,cap,cost,from;}edge[maxm];
int head[maxn],cnt;
inline void add(int u,int v,int w,int c) 
{ 
    cnt++; edge[cnt].next=head[u]; head[u]=cnt; 
    edge[cnt].from=u; edge[cnt].to=v; edge[cnt].cap=w; edge[cnt].cost=c; 
} 
inline void insert(int u,int v,int w,int c) 
{add(u,v,w,c); add(v,u,0,-c);} 
struct Roadnode{int to,next;}road[maxm];
int last[maxn],cnr;
inline void Add(int u,int v) 
{ 
    cnr++; road[cnr].next=last[u]; last[u]=cnr; road[cnr].to=v;
} 
#define inf 0x7fffffff
int S,T; int dis[maxn]; queue<int>q; bool mark[maxn];
inline bool spfa() 
{ 
    
    memset(mark,0,sizeof(mark)); 
    for (int i=0; i<=S; i++) dis[i]=-1; 
    q.push(T); mark[T]=1; dis[T]=0; 
    while (!q.empty()) 
        { 
            int now=q.front(); q.pop(); 
            for (int i=head[now]; i; i=edge[i].next) 
                if (edge[i^1].cap && dis[edge[i].to]<dis[now]+edge[i^1].cost) 
                    { 
                        dis[edge[i].to]=dis[now]+edge[i^1].cost; 
                        if (!mark[edge[i].to]) 
                            mark[edge[i].to]=1,q.push(edge[i].to); 
                    } 
            mark[now]=0; 
          //  printf("%d %d %d\nhahahaha",now,he,ta);
        } 
    return dis[S]!=-1; 
} 
inline int dfs(int loc,int low) 
{ 
    mark[loc]=1; 
    if (loc==T) return low; 
    int w,used=0; 
    for (int i=head[loc]; i; i=edge[i].next) 
        if (edge[i].cap && dis[edge[i].to]==dis[loc]-edge[i].cost && !mark[edge[i].to]) 
            { 
                w=dfs(edge[i].to,min(low-used,edge[i].cap)); 
                edge[i].cap-=w; edge[i^1].cap+=w; used+=w; 
                cost+=w*edge[i].cost; if (used==low) return low; 
            } 
    return used; 
} 
inline void zkw() 
{ 
    while (spfa()) 
        { 
            int pre=cost;
            mark[T]=1; 
            while (mark[T]) 
                {memset(mark,0,sizeof(mark)); dfs(S,inf);}
            insert(S,0,1,0);
            if (pre==cost) break; else ans++;
        }
//    printf("%d %d %d\n",cnt,cost,ans);
}
int stack[maxn],top,dfn[maxn],low[maxn],tot,qcnt,belong[maxn]; bool visit[maxn];
void Tarjan(int x) 
{ 
    dfn[x]=low[x]=++tot; 
    visit[x]=1; stack[++top]=x; 
    for (int i=last[x]; i; i=road[i].next) 
        { 
            if (!dfn[road[i].to]) 
                { 
                    Tarjan(road[i].to); 
                    if (low[road[i].to]<low[x]) low[x]=low[road[i].to]; 
                } 
            else 
                if(visit[road[i].to] && dfn[road[i].to]<low[x]) 
                    low[x]=dfn[road[i].to]; 
        } 
    if (dfn[x]==low[x]) 
        { 
            int uu=0;qcnt++; 
            while (x!=uu) 
                uu=stack[top--],visit[uu]=0,belong[uu]=qcnt;  
        } 
} 
inline void init()
{
    memset(dfn,0,sizeof(dfn));
    memset(head,0,sizeof(head));
    memset(last,0,sizeof(last)); 
    cnt=1; cnr=top=tot=qcnt=cost=ans=0;
}
int cans[maxn],cant[maxn];
inline void rebuild()
{
    T=2*qcnt+1;S=T+1;
    for (int i=1; i<=A; i++) insert(0,belong[cans[i]],inf,0);
    for (int i=1; i<=B; i++) insert(belong[cant[i]]+qcnt,T,inf,0);
    for (int u=1; u<=n; u++)
        for (int i=last[u]; i; i=road[i].next)
            if (belong[u]!=belong[road[i].to])
                insert(belong[u]+qcnt,belong[road[i].to],inf,0);
    for (int i=1; i<=qcnt; i++) insert(i,i+qcnt,1,1),insert(i,i+qcnt,inf,0);
    insert(S,0,1,0);
}
int main()
{
//    freopen("sail.in","r",stdin);
//    freopen("sail.out","w",stdout);
    t=read();
    while (t--)
        {
            init();
            n=read(),m=read(),A=read(),B=read();
            for (int i=1; i<=A; i++) cans[i]=read();
            for (int i=1; i<=B; i++) cant[i]=read();
            for (int u,v,i=1; i<=m; i++) u=read(),v=read(),Add(u,v);
            for (int i=1; i<=n; i++) if (!dfn[i]) Tarjan(i);
            rebuild();
            zkw();
            if (cost!=qcnt) puts("no solution");
                else printf("%d\n",ans);
        }
    return 0;
}