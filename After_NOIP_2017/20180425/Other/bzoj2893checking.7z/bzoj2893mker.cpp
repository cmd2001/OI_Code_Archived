#include<bits/stdc++.h>
using namespace std;
const int maxn=1e3+1e2;

inline int _(int r) {
    return rand() % r + 1;
}
int as[maxn],bs[maxn];

int main() {
    //static int T = 2 , n = 5 , m = 7 , a = 2 , b = 2;
    static int T = 10 , n = 1000 , m = 10000 , a = 50 , b = 50;
    printf("%d\n",T) , srand((unsigned long long)new char ^ time(0));
    while(T--) {
        printf("%d %d %d %d\n",n,m,a,b);
        for(int i=1;i<=n;i++) as[i] = bs[i] = i;
        random_shuffle(as+1,as+1+n) , random_shuffle(bs+1,bs+1+n);
        for(int i=1;i<=a;i++) printf("%d%c",as[i],i!=a?' ':'\n');
        for(int i=1;i<=b;i++) printf("%d%c",bs[i],i!=b?' ':'\n');
        for(int i=1,x,y;i<=m;i++) {
            x = _(n) , y = _(n);
            while( x == y ) x = _(n) , y = _(n);
            printf("%d %d\n",x,y);
        }
    }
    return 0;
}