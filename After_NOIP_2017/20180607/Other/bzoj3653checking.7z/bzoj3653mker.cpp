#include<bits/stdc++.h>
using namespace std;
constexpr int n = 300000;

inline int _(int r=n) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char ^ time(0));
    static int m = 300000;
    printf("%d %d\n",n,m);
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    while(m--) printf("%d %d\n",_(),_(n+1)-1);
    return 0;
}