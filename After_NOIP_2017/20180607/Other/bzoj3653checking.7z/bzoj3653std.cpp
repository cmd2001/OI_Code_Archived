#include<queue>
#include<cstdio>
#include<cstring>
#include<iostream>
#define inf 1000000000
#define pa pair<int,int>
#define ll long long 
using namespace std;
int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x;
}
int n,Q,cnt,ind,sz;
int last[300005],q[300005];
int deep[300005],size[300005];
int l[300005],r[300005],root[300005];
int ls[6000005],rs[6000005];
ll sum[6000005];
struct edge{
	int to,next;
}e[600005];
void insert(int u,int v)
{
	e[++cnt].to=v;e[cnt].next=last[u];last[u]=cnt;
	e[++cnt].to=u;e[cnt].next=last[v];last[v]=cnt;
}
void dfs(int x,int fa)
{
	l[x]=++ind;
	q[ind]=x;
	for(int i=last[x];i;i=e[i].next)
		if(e[i].to!=fa)
		{
			deep[e[i].to]=deep[x]+1;
			dfs(e[i].to,x);
			size[x]+=size[e[i].to]+1;
		}
	r[x]=ind;
}
void build(int &x,int y,int l,int r,int pos,int val)
{
	x=++sz;
	sum[x]=sum[y]+val;
	if(l==r)return;
	ls[x]=ls[y];rs[x]=rs[y];
	int mid=(l+r)>>1;
	if(pos<=mid)build(ls[x],ls[y],l,mid,pos,val);
	else build(rs[x],rs[y],mid+1,r,pos,val);
}
ll query(int k,int l,int r,int x,int y)
{
	if(y>r)y=r;
	if(!k)return 0;
	if(l==x&&y==r)return sum[k];
	int mid=(l+r)>>1;
	if(y<=mid)return query(ls[k],l,mid,x,y);
	else if(x>mid)return query(rs[k],mid+1,r,x,y);
	else return query(ls[k],l,mid,x,mid)+query(rs[k],mid+1,r,mid+1,y);
}
int main()
{
	n=read();Q=read();
	for(int i=1;i<n;i++)
	{
		int u=read(),v=read();
		insert(u,v);
	}
	dfs(1,0);
	int mx=0;
	for(int i=1;i<=n;i++)mx=max(deep[i],mx);
	for(int i=1;i<=n;i++)
		build(root[i],root[i-1],0,mx,deep[q[i]],size[q[i]]);
    while(Q--)
	{
		int P=read(),K=read();
		ll ans=0;
		ans+=(ll)size[P]*min(deep[P],K);
		ans+=query(root[r[P]],0,mx,deep[P]+1,deep[P]+K);
		ans-=query(root[l[P]-1],0,mx,deep[P]+1,deep[P]+K);
		printf("%lld\n",ans);
	}
	return 0;
}