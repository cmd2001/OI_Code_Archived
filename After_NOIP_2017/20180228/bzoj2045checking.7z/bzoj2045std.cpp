#include<cstdio>  
#include<iostream>  
#include<algorithm>  
#include<cctype>  
using namespace std;  
const int maxn=1e6+5;  
typedef long long LL;  
LL n,m,d;  
LL prime[maxn],p[maxn],u[maxn];  
void get_mu(){  
    u[1]=1;  
    for(LL i=2;i<=m;i++){  
        if(!p[i]){  
            prime[++prime[0]]=i;  
            u[i]=-1;      
        }for(LL j=1;i*prime[j]<=n&&j<=prime[0];j++){  
            p[i*prime[j]]=1;  
            if(i%prime[j]==0){  
                u[i*prime[j]]=0;  
                break;  
            }else u[i*prime[j]]=-u[i];            
        }  
    }for(LL i=2;i<=m;i++)u[i]+=u[i-1];  
}  
int main(){  
    cin>>n>>m>>d;  
    n/=d;m/=d;  
    if(n>m)swap(n,m);  
    get_mu();  
    LL ans=0,pos=0;  
    for(LL i=1;i<=n;){  
        pos=min(n/(n/i),m/(m/i));  
        ans+=(u[pos]-u[i-1])*(n/i)*(m/i);  
        i=pos+1;  
    }cout<<ans<<endl;  
    return 0;  
}  
