#include<bits/stdc++.h>
#define lli long long int
using namespace std;

inline lli _r() {
    return rand() | ( (long long)rand() << 16 ) | ( (long long)rand() << 32 );
}
inline int _(int r=1000000) {
    return _r() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static lli n,m,d;
    n = _()  , m = _() , d = _(min(min(n,m),1000ll));
    printf("%lld %lld %lld\n",n,m,d);
    return 0;
}
