#include<bits/stdc++.h>
using namespace std;
const int maxn=1e2+1e1;

inline int _(int r=1e5) {
    return rand() % r + 1;
}

inline void make_case() {
    int n = 1e5 , m = 1e5;
    printf("%d 0 %d\n",n,m);
    for(int i=2;i<=n;i++) printf("%d%c",_(i-1),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) {
        if( rand() & 1 ) printf("%d %d %d\n",_(n),_(),_(n));
        else printf("%d 0 0\n",_(n));
    }
}

int main() {
    static int T = 6;
    srand((unsigned long long)new char);
    printf("%d\n",T);
    while(T--)
        make_case();
    return 0;
}
