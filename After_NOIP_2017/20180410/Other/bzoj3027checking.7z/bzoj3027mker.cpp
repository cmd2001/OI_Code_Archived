#include<bits/stdc++.h>
using namespace std;
const int lim=1e7;

inline int _(int r=lim) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = 10 , a = _() , b = _();
    if( a > b ) swap(a,b);
    printf("%d %d %d\n",n,a,b);
    while(n--) printf("%d\n",_(1e6));
    return 0;
}
