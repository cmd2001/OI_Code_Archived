#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define p 2004
#define LL long long 
using namespace std;
int n,a,b,ans,m,v[20];
int C(int n,int m)
{
    if (n<m) return 0;
    LL t=1; LL p1=1;
    for (int i=1;i<=m;i++) p1=p1*i;
    LL mod=(LL)p*p1;
    for (int i=n-m+1;i<=n;i++) t=(LL)t*i%mod;
    return (t/p1)%p;
}
void dfs(int x,int cnt,int sum)
{
    if (x==n+1) {
        if (cnt&1) ans-=C(n+m-sum,n);
        else ans+=C(n+m-sum,n);
        return;
    }
    dfs(x+1,cnt,sum);
    dfs(x+1,cnt+1,sum+v[x]);
}
int solve(int x)
{
    ans=0; m=x; 
    dfs(1,0,0); 
    return ans;
}
int main()
{
    scanf("%d%d%d",&n,&a,&b);
    for (int i=1;i<=n;i++) scanf("%d",&v[i]),v[i]++;
    int t=solve(b)-solve(a-1);
    printf("%d\n",(t%p+p)%p);
}
