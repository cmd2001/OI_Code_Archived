#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;

inline int _(int r=mod) {
    return rand() % mod;
}
inline int __() {
    return _() - _();
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1000000000 , k = 2000;
    printf("%d %d\n",n,k);
    for(int i=1;i<=k;i++) printf("%d%c",_(),i!=k?' ':'\n');
    for(int i=1;i<=k;i++) printf("%d%c",_(),i!=k?' ':'\n');
    return 0;
}
