#include<cstdio>
#include<algorithm>
#define fo(i,a,b) for(i=a;i<=b;i++)
#define fd(i,a,b) for(i=a;i>=b;i--)
using namespace std;
int a[40],b[40];
int i,j,k,l,t,n,m,ans,num;
int main(){
    scanf("%d",&n);
    fo(i,1,n){
        scanf("%d",&t);
        fd(j,31,0){
            if ((t&(1<<j))!=0){
                if (!a[j]){
                    a[j]=t;
                    break;
                }
                t^=a[j];
            }
        }
    }
    fd(i,31,0){
        if ((ans&(1<<i))==0){
            ans^=a[i];
            b[i]=1;
        }
    }
    printf("%d ",ans);
    fo(i,0,31){
        num=0;
        fd(j,31,i+1)
            if (b[j]) num^=a[j];
        if (!b[i]) num^=a[i];
        fd(j,i-1,0)
            if ((num&(1<<j))==0) num^=a[j];
        if (num<ans) break;
    }
    printf("%d\n",num);
}
