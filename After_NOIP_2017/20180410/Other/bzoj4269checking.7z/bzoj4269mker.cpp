#include<bits/stdc++.h>
using namespace std;

inline int _() {
    return rand() % 2147483648ll;
}

int main() {
    static int n = 100000;
    printf("%d\n",n);
    while(n--) printf("%d\n",_());
    return 0;
}
