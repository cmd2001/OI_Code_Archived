#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000000000) {
    return rand() % r + 1;
}

inline bool isprime(int t) {
    for(int i=2;i<t;i++) if( t % i == 0 ) return 0;
    return 1;
}

int main() {
    srand((unsigned long long)new char);
    int n = _() , m = _() , t = _(15) , mod = _(100000);
    while( !isprime(mod) ) mod = _(100000);
    printf("%d %d %d %d\n",n,t,m,mod);
    for(int i=1;i<=t;i++) printf("%d%c",_(),i!=t?' ':'\n');
    return 0;
}
