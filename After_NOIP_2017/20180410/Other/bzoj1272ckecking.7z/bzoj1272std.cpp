#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
#define LL long long 
using namespace std;
LL n,m,t,p,a[20];
LL jc[1000003],inv[1000003];
LL quickpow(LL num,int x)
{
    LL base=num%p; LL ans=1;
    while (x) {
        if (x&1) ans=ans*base%p;
        x>>=1;
        base=base*base%p;
    }
    return ans;
}
LL C(LL n,LL m)
{
    return jc[n]*inv[m]%p*inv[n-m]%p;
}
LL calc(LL n,LL m)
{
    if (m==0) return 1;
    return calc(n/p,m/p)*C(n%p,m%p)%p;
}
int main()
{
    scanf("%lld%lld%lld%lld",&n,&t,&m,&p); jc[0]=1;
    for (LL i=1;i<=p;i++) jc[i]=(LL)jc[i-1]*i%p;
    for (LL i=0;i<=p;i++) inv[i]=quickpow(jc[i],p-2);
    for (LL i=1;i<=t;i++) scanf("%lld",&a[i]);
    LL ans=0;
    for (int i=0;i<(1<<t);i++){
        LL sum=0; int cnt=0;
        for (int j=0;j<t;j++)
         if ((i>>j)&1) sum+=(a[j+1]+1),cnt++;
        if (sum>m) continue;
        sum=m-sum;
        LL c=calc(n+sum,n);
        if (cnt&1) ans=(ans-c+p)%p;
        else ans=(ans+c)%p;
    }
    printf("%lld\n",(ans%p+p)%p);
}
