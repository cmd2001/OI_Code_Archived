#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+1e2;

int dat[maxn];

int main() {
    srand((unsigned long long)new char);
    static int n = 10;
    for(int i=1;i<=n;i++) dat[i] = i;
    random_shuffle(dat+1,dat+1+n);
    printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    return 0;
}
