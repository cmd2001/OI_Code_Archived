#include<iostream>  
#include<cstring>  
#include<ctime>  
#include<cmath>  
#include<algorithm>  
#include<iomanip>  
#include<cstdlib>  
#include<cstdio>  
#include<map>  
#include<bitset>  
#include<set>  
#include<stack>  
#include<vector>  
#include<queue>  
using namespace std;  
#define MAXN 100010  
#define MAXM 1010  
#define ll long long  
#define eps 1e-8  
#define MOD 998244353  
#define INF 1000000000  
#define lb(x) x&-x  
set<int>s;  
int c[MAXN];  
int ans=1;  
int n;  
int ask(int x){  
    int re=0;  
    for(;x;x-=lb(x)){  
        re=max(re,c[x]);  
    }  
    return re;  
}  
void change(int x,int y){  
    for(;x<=n;x+=lb(x)){  
        c[x]=max(c[x],y);  
    }  
}  
int main(){  
    int i,x;  
    scanf("%d",&n);  
    for(i=1;i<=n;i++){  
        scanf("%d",&x);  
        int t=ask(n-x);  
        if(t==2){  
            printf("0\n");  
            return 0;  
        }  
        change(n-x+1,t+1);  
        int mx=x;  
        set<int>::iterator p=s.upper_bound(x);  
        while(p!=s.end()){  
            mx=max(mx,*p);  
            set<int>::iterator tmp=p;  
            p++;  
            s.erase(tmp);  
        }  
        s.insert(mx);  
    }  
    x=s.size();  
    while(x){  
        (ans<<=1)%=MOD;  
        x--;  
    }  
    printf("%d\n",ans);  
    return 0;  
}  