#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e8) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 10 , m = 20;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(5e7),i!=n?' ':'\n');
    for(int i=1;i<=m;i++) printf("%d%c",_(),i!=m?' ':'\n');
    return 0;
}
