#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define GET (ch>='0'&&ch<='9')
#define MAXN 16777216+2
#define lowbit(x)   (x&(-x))
using namespace std;
int n,m,tmp;
int f[MAXN],g[MAXN],a[MAXN],c[101];//f_i 最少用几个包 g_i 最后一个包的剩余容量 
bool cmp(int a,int b)   {return a>b;}
int main()
{
    scanf("%d%d",&n,&m);int sum=(1<<n);
    for (int i=1;i<=n;i++)  scanf("%d",&a[i]);
    for (int i=1;i<=m;i++)  scanf("%d",&c[i]);sort(c+1,c+m+1,cmp);
    for (int i=n;i;i--) a[(1<<(i-1))]=a[i];
    for (int i=1;i<sum;i++)
    {
        f[i]=m+1;g[i]=-1;
        for (int j=i;j;j-=tmp)
        {
            tmp=lowbit(j);int x=i-tmp;
            if (a[tmp]<=g[x]&&(f[x]<f[i]||(f[x]==f[i]&&g[x]-a[tmp]>g[i])))  f[i]=f[x],g[i]=g[x]-a[tmp];//装得下 
            else
            if ((f[x]+1<f[i]||(f[x]+1==f[i]&&c[f[x]+1]>g[i]+a[tmp]))&&c[f[x]+1]>=a[tmp])    f[i]=f[x]+1,g[i]=c[f[i]]-a[tmp];//装不下  
        }
    }
    if (f[sum-1]>m) puts("NIE");    else    printf("%d\n",f[sum-1]);
}