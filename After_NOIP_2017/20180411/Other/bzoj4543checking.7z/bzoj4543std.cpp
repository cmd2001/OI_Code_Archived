#include<cstdio>
#include<iostream>
#define debug cout
#define gm 100005
using namespace std;
typedef long long ll;
inline ll* __alloc(size_t size)
{
    static ll pool[gm<<2];
    static ll* ptr=pool;
    ll* res=ptr;ptr+=size;
    return res;
}
struct e
{
    int t;
    e *n;
    e(int t,e *n):t(t),n(n){}
}*p[gm];
int dep[gm],son[gm],len[gm],fa[gm];
ll *F[gm],*G[gm];
void dfs(int x)
{
    son[x]=x;
    for(e *i=p[x];i;i=i->n)
    {
        if(i->t==fa[x]) continue;
        fa[i->t]=x;
        dep[i->t]=dep[x]+1;
        dfs(i->t);
        if(dep[son[i->t]]>dep[son[x]]) son[x]=son[i->t];
    }
    len[x]=dep[son[x]]-dep[x]+1;
    for(e *i=p[x];i;i=i->n)
    {
        if(i->t==fa[x]) continue;
        if(son[i->t]!=son[x])
        {
            int y=son[i->t];
            F[y]=__alloc(len[i->t])+len[i->t]-1;
            G[y]=__alloc(len[i->t]<<1);
        }
    }
    if(x==1)
    {
        int y=son[x];
        F[y]=__alloc(len[x])+len[x]-1;
        G[y]=__alloc(len[x]<<1);
    }
}
ll ans=0;
void DP(int x)
{
    ll *&f=F[x],*&g=G[x];
    for(e *i=p[x];i;i=i->n)
    {
        if(i->t==fa[x]) continue;
        DP(i->t);
        if(son[x]==son[i->t])
        {
            f=F[i->t]-1;
            g=G[i->t]+1;
        }
    }
    ans+=g[0];
    ++f[0];
    for(e *i=p[x];i;i=i->n)
    {
        if(i->t==fa[x]||son[i->t]==son[x]) continue;
        ll *fs=F[i->t],*gs=G[i->t];
        ans+=fs[0]*g[1];
        for(int w=1;w<len[i->t];++w)
            ans+=fs[w]*g[w+1]+gs[w]*f[w-1];
        g[1]+=fs[0]*f[1];
        f[1]+=fs[0];
        for(int w=1;w<len[i->t];++w)
        {
            g[w+1]+=fs[w]*f[w+1];
            g[w-1]+=gs[w];
            f[w+1]+=fs[w];
        }
    }
    /*debug<<"x = "<<x<<"len = "<<len[x]<<endl;
    for(int i=0;i<len[x];i++) debug<<f[i]<<" "; debug<<endl;
    for(int i=0;i<len[x];i++) debug<<g[i]<<" "; debug<<endl;*/
}
int n;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<n;++i)
    {
        int u,v;
        scanf("%d%d",&u,&v);
        p[u]=new e(v,p[u]);
        p[v]=new e(u,p[v]);
    }
    dfs(1);
    //for(int i=1;i<=n;i++) debug<<son[i]<<" "; debug<<endl;
    DP(1);
    printf("%lld\n",ans);
    return 0;
}

