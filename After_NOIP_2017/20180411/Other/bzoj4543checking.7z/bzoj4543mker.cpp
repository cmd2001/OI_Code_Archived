#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 100000;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d\n",_(i-1),i);
    return 0;
}