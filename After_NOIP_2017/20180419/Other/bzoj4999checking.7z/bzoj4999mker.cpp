#include<bits/stdc++.h>
using namespace std;

inline int _(int r=3) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 5;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    for(int i=1;i<=m;i++)
        if( _(2) & 1 ) printf("Q %d %d %d\n",_(n),_(n),_());
        else printf("C %d %d\n",_(n),_());
    return 0;
}
