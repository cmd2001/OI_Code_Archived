#include<bits/stdc++.h>
using namespace std;

struct Edge {
    int x,y,len;
};
vector<Edge> es;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 20;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) es.push_back((Edge){i,_(i-1),_()});
    for(auto& t : es ) printf("%d %d %d\n",t.x,t.y,t.len);
    return 0;
}
