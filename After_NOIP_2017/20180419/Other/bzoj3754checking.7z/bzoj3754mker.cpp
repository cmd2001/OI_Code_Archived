#include<bits/stdc++.h>
using namespace std;

struct Node {
    int x,y,v;
};
inline int _(int r=100) {
    return rand() % r + 1;
}
vector<Node> ns;
int main() {
    srand((unsigned long long)new char);
    static int n = 100 , m = 2000;
    printf("%d %d\n",n,m);
    for(int i=2;i<=n;i++) ns.push_back((Node){i,_(i-1),_()});
    while( (signed)ns.size() < m ) ns.push_back((Node){_(n),_(n),_()});
    random_shuffle(ns.begin(),ns.end());
    for(auto t : ns ) printf("%d %d %d\n",t.x,t.y,t.v);
    return 0;
}
