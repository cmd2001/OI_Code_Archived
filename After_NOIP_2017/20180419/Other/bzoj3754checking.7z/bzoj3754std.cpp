#include <cmath>
#include <cstdio>
#include <algorithm>
using namespace std;
struct data
{
    int x , y , z;
    bool operator<(const data &a)const {return z < a.z;}
}a[2010];
bool v[2010];
int f[110];
int find(int x)
{
    return x == f[x] ? f[x] : f[x] = find(f[x]);
}
int main()
{
    int n , m , i , j , k , now , p = 1;
    double s , t , ans = 1 << 30;
    scanf("%d%d" , &n , &m);
    for(i = 1 ; i <= m ; i ++ ) scanf("%d%d%d" , &a[i].x , &a[i].y , &a[i].z);
    sort(a + 1 , a + m + 1);
    for(i = 0 ; i <= (n - 1) * 100 ; i ++ )
    {
        while(p <= m && a[p].z * (n - 1) < i ) p ++ ;
        for(j = 1 ; j <= n ; j ++ ) f[j] = j;
        for(j = 1 ; j <= m ; j ++ ) v[j] = 0;
        j = p - 1 , k = p , s = t = 0;
        while(j || k <= m)
        {
            if(k > m || (j && i - a[j].z * (n - 1) < a[k].z * (n - 1) - i)) now = j -- ;
            else now = k ++ ;
            if(find(a[now].x) != find(a[now].y))
                f[f[a[now].x]] = f[a[now].y] , s += a[now].z , v[now] = 1;
        }
        s /= (n - 1);
        for(j = 1 ; j <= m ; j ++ )
            if(v[j])
                t += (a[j].z - s) * (a[j].z - s);
        //printf("per = %0.4lf , su = %0.4lf\n",(double)i/(n-1),s);
        ans = min(ans , t);
    }
    printf("%.4lf\n" , sqrt(ans / (n - 1)));
    return 0;
}
