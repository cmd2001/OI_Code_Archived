#include<bits/stdc++.h>
using namespace std;

inline int _(int r=4) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    printf("%lld\n",rand()%(long long)1e18);
    int len = _(1e5-4)+4;
    printf("ABCD");
    for(int i=1;i<=len;i++) putchar('A'+_());
    puts("");
    return 0;
}

