#include<iostream>  
#include<cstring>  
#include<cstdio>  
#include<algorithm>  
#include<cmath>  
#define N 300005  
#define M 4  
#define LL long long   
using namespace std;  
LL m,mu[N][6];  
const LL inf=1e18;
int n,ch[N][6],fa[N],l[N],np,q,cnt,root,nq,p,vis[N],last;  
char s[N];  
struct data{  
    LL a[20][20];  
}num;  
void extend(int x)  
{  
    int c=s[x]-'A'+1;  
    p=last; np=last=++cnt; l[np]=l[p]+1;  
    for (;p&&!ch[p][c];p=fa[p]) ch[p][c]=np;  
    if (!p) fa[np]=root;  
    else {  
        int q=ch[p][c];  
        if (l[q]==l[p]+1) fa[np]=q;  
        else {  
            nq=++cnt; l[nq]=l[p]+1;  
            memcpy(ch[nq],ch[q],sizeof(ch[q]));  
            fa[nq]=fa[q];  
            fa[q]=fa[np]=nq;  
            for (;ch[p][c]==q;p=fa[p]) ch[p][c]=nq;  
        }  
    }  
}  
void clear(data &a,LL x)  
{  
    for (int i=1;i<=M;i++)  
     for (int j=1;j<=M;j++)  
      a.a[i][j]=x;  
}  
data mul(data a,data b)  
{  
    data c; clear(c,inf);  
    for (int i=1;i<=M;i++)  
     for (int j=1;j<=M;j++)   
      for (int k=1;k<=M;k++)  
       c.a[i][j]=min(c.a[i][j],a.a[i][k]+b.a[k][j]);  
    return c;  
}  
data quickpow(data num,LL x)  
{  
    data ans; clear(ans,0);  
    data base; base=num;  
    while (x) {  
        if (x&1) ans=mul(ans,base);  
        x>>=1;  
        base=mul(base,base);  
    }  
    return ans;  
} 
void dfs(int x)
{
   if (vis[x]) return;
   vis[x]=1;
   for (int i=1;i<=4;i++)
    if (ch[x][i]) dfs(ch[x][i]),mu[x][i]=inf;
   for (int i=1;i<=4;i++) {
     if (!ch[x][i]) {
         mu[x][i]=1;
         continue;
        }
     for (int j=1;j<=4;j++)
      mu[x][j]=min(mu[x][j],mu[ch[x][i]][j]+1);
   }
} 
void build()  
{ 
    dfs(root); 
    for (int i=1;i<=M;i++)
     for (int j=1;j<=M;j++)
      num.a[i][j]=mu[ch[1][i]][j]; 
}  
bool check(LL x)  
{  
    data ans1=quickpow(num,x);  
    LL mx=inf;  
    for (int i=1;i<=M;i++)  
     for (int j=1;j<=M;j++) mx=min(mx,ans1.a[i][j]);  
    return mx>=m;  
}  
int main()  
{ 
    scanf("%lld",&m);  
    scanf("%s",s+1);  
    n=strlen(s+1);  
    root=last=++cnt;  
    for (int i=1;i<=n;i++) extend(i);  
    build();  
    LL l=1; LL r=m; LL ans=m+1;  
    while (l<=r) {  
        LL mid=(l+r)/2;  
        if (check(mid)) ans=min(ans,mid),r=mid-1;  
        else l=mid+1; 
    }  
    if (ans==m+1) printf("0\n");
	else printf("%lld\n",ans);  
}  
