#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3 , m = 4;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",_()+10,i!=n?' ':'\n');
    for(int i=1,x,y;i<=m;i++) {
        do x = _(n) , y = _(n); while( x == y );
        printf("%d %d %d\n",x,y,_());
    }
    return 0;
}

