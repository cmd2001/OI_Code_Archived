#include<bits/stdc++.h>
#define debug cout
using namespace std;
const int maxn=1e3+1e2;

int s[maxn],t[maxn<<1],nxt[maxn<<1],l[maxn<<1];
int fa[maxn],fal[maxn],dep[maxn],mx[maxn];

inline void coredge(int from,int to,int len) {
    static int cnt;
    t[++cnt] = to , l[cnt] = len , nxt[cnt] = s[from] , s[from] = cnt;
}
inline void addedge(int a,int b,int l) {
    coredge(a,b,l) , coredge(b,a,l);
}
inline void dfs(int pos) {
    for(int at=s[pos];at;at=nxt[at]) if( t[at] != fa[pos] ) {
        dep[t[at]] = dep[pos] + 1 , fa[t[at]] = pos , fal[t[at]] = l[at] , dfs(t[at]);
    }
}
inline int calc(int x,int y) {
    int ret = 0;
    while( x != y ) {
        if( dep[x] < dep[y] ) swap(x,y);
        ret ^= fal[x] , x = fa[x];
    }
    return ret;
}
inline void markchain(int x,int y,int v) {
    while( x != y ) {
        if( dep[x] < dep[y] ) swap(x,y);
        mx[x] = max( mx[x] , v ) , x = fa[x];
    }
    mx[x] = max( mx[x] , v );
}

int main() {
    static int n;
    scanf("%d",&n);
    for(int i=1,a,b,l;i<n;i++) scanf("%d%d%d",&a,&b,&l) , addedge(a,b,l);
    dfs(1);
    for(int i=1;i<=n;i++) for(int j=1;j<i;j++) markchain(i,j,calc(i,j));
    for(int i=1;i<=n;i++) printf("%d\n",mx[i]);
    return 0;
}
