#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e9) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5;
    printf("%d\n",n);
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,_(i-1),_());
    return 0;
}
