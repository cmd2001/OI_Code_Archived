#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+1e2;

int dat[maxn];
int main() {
    srand((unsigned long long)new char);
    static int n = 100000;
    for(int i=1;i<=n*4;i++) dat[i] = i;
    random_shuffle(dat+1,dat+1+n*4) , printf("%d\n",n);
    for(int i=1;i<=n;i++) printf("%d %d %d %d\n",dat[i*4-3],dat[i*4-2],dat[i*4-1],dat[i]);
    return 0;
}

