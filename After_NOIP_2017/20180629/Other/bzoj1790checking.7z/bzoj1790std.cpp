#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <iostream>
#define MAXN 200010
#define Max(a, b) ((a) > (b) ? (a) : (b))

using namespace std;

int n, rank[MAXN], ans;
bool is_ok[MAXN], Left[MAXN];

struct Data{
    int a, b, c, d;
    int id;
}rec[MAXN];

int tree[MAXN<<2];

bool Cmpa(Data A, Data B){
    return A.a < B.a;
}

bool Cmpb(Data A, Data B){
    return A.b < B.b;
}

bool Cmpc(Data A, Data B){
    return A.c > B.c;
}

void update(int root, int L, int R, int x, int v){
    if(x > R || x < L)  return;
    if(L == x && x == R){
      tree[root] += v;
      return;
    }

    int mid = (L + R) >> 1, Lson = root << 1, Rson = root << 1 | 1;
    update(Lson, L, mid, x, v);
    update(Rson, mid+1, R, x, v);

    tree[root] = Max(tree[Lson], tree[Rson]);
}

int query(int root, int L, int R, int x, int y){
    if(x > R || y < L)  return 0LL;
    if(x <= L && y >= R)  return tree[root];

    int mid = (L + R) >> 1, Lson = root << 1, Rson = root << 1 | 1;
    int temp1 = query(Lson, L, mid, x, y);
    int temp2 = query(Rson, mid+1, R, x, y);

    return Max(temp1, temp2);
}

void CDQ(int L, int R){

    if(L == R)  return;
    int mid = (L + R) >> 1;

    for(int i = L; i <= mid; i++)  Left[rec[i].id] = true;

    sort(rec+L, rec+R+1, Cmpb);

    for(int i = L; i <= R; i++){
      if(Left[rec[i].id])  update(1, 1, n, rank[rec[i].id], rec[i].d);
      else{
        int temp = query(1, 1, n, 1, rank[rec[i].id]);
        if(temp > rec[i].d)  is_ok[rec[i].id] = true;
      }
    }

    for(int i = L; i <= R; i++)  
      if(Left[rec[i].id]){  
        update(1, 1, n, rank[rec[i].id], -rec[i].d);
        Left[rec[i].id] = false;
     }

    sort(rec+L, rec+R+1, Cmpa);

    CDQ(L, mid);
    CDQ(mid+1, R);
}

int main(){


    scanf("%d", &n);

    for(int i = 1; i <= n; i++){
      rec[i].id = i;
      scanf("%d%d%d%d", &rec[i].a, &rec[i].b, &rec[i].c, &rec[i].d);
    }

    sort(rec+1, rec+n+1, Cmpc);

    for(int i = 1; i <= n; i++)  rank[rec[i].id] = i;

    sort(rec+1, rec+n+1, Cmpa);
    CDQ(1, n);

    for(int i = 1; i <= n; i++)  if(is_ok[i])  ans ++;

    printf("%d\n", ans);
    return 0;
}
