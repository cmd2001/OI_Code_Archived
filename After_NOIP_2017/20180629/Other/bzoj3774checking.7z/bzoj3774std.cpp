#include<cmath>
#include<queue>
#include<cctype>
#include<cstdio>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=55*55*2,maxm=maxn*4,inf=1e9;
int np,first[maxn];
struct edge{
    int from,to,next,cap,flow;
}E[maxm<<1];
void add(int u,int v,int c)
{
    //cout<<u<<" "<<v<<" "<<c<<endl;
    E[++np]=(edge){u,v,first[u],c,0};
    first[u]=np;
    E[++np]=(edge){v,u,first[v],0,0};
    first[v]=np;
}
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
int n,m,s,t,nm,sum;
#define getId(x,y) ((x)-1)*m+(y)
void Init()
{
    //(i+j)&1==1的点为黑色结点 
    np=-1;
    memset(first,-1,sizeof(first));
    int id,a,ni,nj;
    scanf("%d%d",&n,&m);
    nm=n*m,s=2*nm+1,t=s+1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            scanf("%d",&a);
            if((i+j)&1)
                add(s,getId(i,j),a);
            else
                add(getId(i,j),t,a);
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=m;j++)
        {
            scanf("%d",&a);sum+=a;
            id=getId(i,j);

            if((i+j)&1)
                add(id,id+nm,a);
            else
                add(id+nm,id,a);

            id+=nm;
            for(int k=0;k<4;k++)
            {
                ni=i+dx[k],nj=j+dy[k];
                if(ni<1 || nj<1 || ni>n || nj>m)continue;
                if((i+j)&1)
                    add(id,getId(ni,nj),inf);
                else
                    add(getId(ni,nj),id,inf);
            }
        }
    }
}
int dist[maxn],gap[maxn];
int SAP(int i,int lim)
{
    if(i==t)return lim;
    int flow=0,tmp;
    for(int p=first[i];p!=-1;p=E[p].next)if(E[p].cap-E[p].flow)
    {
        int j=E[p].to;
        if(dist[i]==dist[j]+1)
        {
            tmp=SAP(j,min(lim-flow,E[p].cap-E[p].flow));
            E[p].flow+=tmp;
            E[p^1].flow-=tmp;
            flow+=tmp;
            if(dist[s]>=t || lim==flow)return flow;
        }
    }
    if(flow==0)
    {
        if(--gap[dist[i]]==0)dist[s]=t;
        gap[++dist[i]]++;
    }
    return flow;
}
void maxFlow()
{
    memset(gap,0,sizeof(gap));
    memset(dist,0,sizeof(dist));
    gap[0]=t;
    int ret=0;
    while(dist[s]<t)
        ret+=SAP(s,inf);
    printf("%d\n",sum-ret);
}
int main()
{
    //freopen("in.txt","r",stdin);
    Init();
    maxFlow();
    return 0;
}
