#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char ^ (std::hash<string>()("KurenaiKisaragi")));
    static int n = 50 , m = 50;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) printf("%d%c",_(),j!=m?' ':'\n');
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) printf("%d%c",_(),j!=m?' ':'\n');
    return 0;
}

