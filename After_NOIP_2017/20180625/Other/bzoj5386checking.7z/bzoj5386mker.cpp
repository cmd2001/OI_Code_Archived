#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 10 , t = 5;
    printf("%d %d\n",n,t);
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    return 0;
}