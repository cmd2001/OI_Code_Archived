#include<cstdio>
const int N=1000010;
int n,m,k,i,x,y,deg[N],d[N],g[N],v[N<<1],nxt[N<<1],ed,h,t,q[N],ans,vis[N];
inline void add(int x,int y){deg[x]++;v[++ed]=y;nxt[ed]=g[x];g[x]=ed;}
inline void ext(int x,int y){
  deg[x]--;
  if(deg[x]>1)return;
  if(!d[x])d[q[++t]=x]=y;
}
int main(){
  scanf("%d%d",&n,&m);
  for(i=1;i<n;i++)scanf("%d%d",&x,&y),add(x,y),add(y,x);
  for(h=i=1;i<=n;i++)if(deg[i]<=1)ext(i,1);
  while(h<=t){
    x=q[h++];
    for(i=g[x];i;i=nxt[i])ext(v[i],d[x]+1);
  }
  for(i=1;i<=n;i++)if(d[i]*2<=m)vis[i]=1;
  for(i=1;i<=n;i++)if(!vis[i]&&(m&1)){vis[i]=1;break;}
  for(i=1;i<=n;i++)if(vis[i])ans++;
  printf("%d",ans);
}