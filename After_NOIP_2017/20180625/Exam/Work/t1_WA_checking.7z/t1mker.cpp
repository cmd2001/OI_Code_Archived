#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3 , m = 3;
    printf("%d %d\n",n,m);
    for(int i=2;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) printf("%d%c",_(),j!=m?' ':'\n');
    return 0;
}