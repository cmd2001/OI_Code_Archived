#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
#include<cassert>
#define debug cerr
typedef long long int lli;
using namespace std;
const int maxe=1e6+1e2,maxn=5e3+1e2;
const int inf=0x3f3f3f3f;

int n,m;
struct Array {
    int dat[maxe];
    inline int* operator [] (const int &x) {
        return dat + n * ( x - 1 );
    }
}in; // in[kind][pos] .

deque<int> q[maxn]; // q[kind]

lli su[maxn],ans;

inline void push_All(const int &rit) {
    for(int i=1;i<=m;i++) {
        while( q[i].size() && in[i][q[i].back()] <= in[i][rit] ) q[i].pop_back();
        q[i].push_back(rit);
    }
}
inline lli calc_All(const int &rit) {
    lli ret = 0;
    int mi = inf;
    for(int i=1;i<=m;i++) ret += in[i][q[i].front()] , mi = min( mi , q[i].front() );
    return ret - su[rit] + su[mi];
}
inline int find_Min() {
    int ret = inf;
    for(int i=1;i<=m;i++) ret = min( ret , q[i].front() );
    return ret;
}
inline lli calc_Without_Min(const int &rit,const int &mi) {
    lli ret = 0;
    int mi2 = inf;
    for(int i=1;i<=m;i++) {
        if( q[i].front() != mi ) ret += in[i][q[i].front()] , mi2 = min( mi2 , q[i].front() );
        else ret += in[i][q[i][1]] , mi2 = min( mi2 , q[i][1] );
    }
    return ret - su[rit] + su[mi2];
}
inline void pop_Min(const int &mi) {
    for(int i=1;i<=m;i++) if( q[i].front() == mi ) q[i].pop_front();
}

inline char nextchar() {
    static const int BS = 1 << 21;
    static char buf[BS],*st,*ed;
    if( st == ed ) ed = buf + fread(st=buf,1,BS,stdin);
    return st == ed ? -1 : *st++;
}
inline int getint() {
    int ret = 0 , ch;
    while( !isdigit(ch=nextchar()) ) ;
    do ret = ret * 10 + ch - '0'; while( isdigit(ch=nextchar()) );
    return ret;
}

int main() {
    n = getint() , m = getint();
    for(int i=2;i<=n;i++) su[i] = su[i-1] + getint();
    for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) in[j][i] = getint();
    for(int r=1;r<=n;r++) {
        push_All(r);
        while(1) {
            lli cur = calc_All(r); ans = max(ans,cur);
            int mi = find_Min();
            debug<<"r = "<<r<<"mi = "<<mi<<endl;
            for(int i=1;i<=m;i++) debug<<q[i].front()<<" "; debug<<endl;
            if( mi == r || calc_Without_Min(r,mi) < cur ) break;
            else pop_Min(mi);
        }
    }
    printf("%lld\n",ans);
    return 0;
}
