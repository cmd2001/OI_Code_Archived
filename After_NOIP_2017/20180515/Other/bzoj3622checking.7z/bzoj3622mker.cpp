#include<bits/stdc++.h>
using namespace std;
int dat[5010];

int main() {
    srand((unsigned long long)new char);
    static int n = 10 , m = 2;
    for(int i=1;i<=n<<1;i++) dat[i] = i;
    random_shuffle(dat+1,dat+1+(n<<1)) , printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    for(int i=1;i<=n;i++) printf("%d%c",dat[n+i],i!=n?' ':'\n');
    return 0;
}