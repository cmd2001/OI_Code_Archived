#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 1e5;
    for(int i=1;i<=n;i++) putchar('a'+_(2));
    puts("");
    return 0;
}