#include <cstdio>
#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int maxn=100010;
int inf=1000000000;
int n,m,cnt,tot;
int to[maxn<<1],nxt[maxn<<1],head[maxn],fa[19][maxn],dep[maxn],rt[maxn],p[maxn],ref[maxn];
int v[maxn*50],s[maxn*50],ls[maxn*50],rs[maxn*50];
struct node
{
    int a,b,c;
}q[maxn];
bool cmp(node a,node b)
{
    return a.c<b.c;
}
int rd()
{
    int ret=0;  char gc=getchar();
    while(gc<'0'||gc>'9') gc=getchar();
    while(gc>='0'&&gc<='9')   ret=ret*10+gc-'0',gc=getchar();
    return ret;
}
void add(int a,int b)
{
    to[++cnt]=b,nxt[cnt]=head[a],head[a]=cnt;
}
void dfs(int x)
{
    p[++p[0]]=x;
    for(int i=head[x];i;i=nxt[i])
        if(to[i]!=fa[0][x]) fa[0][to[i]]=x,dep[to[i]]=dep[x]+1,dfs(to[i]);
}
int lca(int a,int b)
{
    if(dep[a]<dep[b])    swap(a,b);
    for(int i=18;i>=0;i--)   if(dep[fa[i][a]]>=dep[b])    a=fa[i][a];
    if(a==b)    return a;
    for(int i=18;i>=0;i--)   if(fa[i][a]!=fa[i][b])  a=fa[i][a],b=fa[i][b];
    return fa[0][a];
}
void pushup(int x)
{
    v[x]=max(v[ls[x]],v[rs[x]]);
    s[x]=(v[ls[x]]>=v[rs[x]])?s[ls[x]]:s[rs[x]];
}
void insert(int &x,int a,int b,int l,int r)
{
    if(!x)  x=++tot;
    if(l==r)
    {
        v[x]+=b,s[x]=ref[l];
        return ;
    }
    int mid=l+r>>1;
    if(a<=mid)   insert(ls[x],a,b,l,mid);
    else    insert(rs[x],a,b,mid+1,r);
    pushup(x);
}
void merge(int &a,int b,int l,int r)
{
    if(!b)  return ;
    if(!a)
    {
        a=b;
        return ;
    }
    if(l==r)
    {
        v[a]+=v[b];
        return ;
    }
    int mid=l+r>>1;
    merge(ls[a],ls[b],l,mid),merge(rs[a],rs[b],mid+1,r);
    pushup(a);
}
int main()
{
    int i,j,a,b,c,d;
    n=rd(),m=rd();
    for(i=1;i<=n;i++)    rt[i]=++tot;
    for(i=1;i<n;i++) a=rd(),b=rd(),add(a,b),add(b,a);
    dep[1]=1,dfs(1);
    for(j=1;(1<<j)<=n;j++) for(i=1;i<=n;i++)    fa[j][i]=fa[j-1][fa[j-1][i]];
    for(i=1;i<=m;i++)    q[i].a=rd(),q[i].b=rd(),q[i].c=rd();
    sort(q+1,q+m+1,cmp);
    for(d=0,i=1;i<=m;i++)
    {
        a=q[i].a,b=q[i].b,c=lca(a,b);
        if(q[i].c>q[i-1].c)  ref[++d]=q[i].c;
        insert(rt[a],d,1,0,m),insert(rt[b],d,1,0,m),insert(rt[c],d,-1,0,m);
        if(c!=1)    insert(rt[fa[0][c]],d,-1,0,m);
    }
    for(i=n;i>1;i--) merge(rt[fa[0][p[i]]],rt[p[i]],0,m);
    for(i=1;i<=n;i++)    printf("%d\n",s[rt[i]]);
    return 0;
}