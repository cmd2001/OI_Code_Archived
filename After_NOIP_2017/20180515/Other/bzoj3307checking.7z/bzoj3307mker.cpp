#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1000) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1e5 , m = 1e5;
    printf("%d %d\n",n,m);
    for(int i=2;i<=n;i++) printf("%d %d\n",i,_(i-1));
    for(int i=1;i<=m;i++) printf("%d %d %d\n",_(n),_(n),_());
    return 0;
}