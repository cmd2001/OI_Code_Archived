#include<bits/stdc++.h>
using namespace std;
const int maxn=2e5+1e2;

int dat[maxn];
inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 2e5 , m = 2e5;
    for(int i=1;i<=n>>1;i++) dat[i] = _(2e5);//dat[i] = dat[i+(n>>1)] = i - 1;
    random_shuffle(dat+1,dat+1+n);
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) printf("%d%c",dat[i],i!=n?' ':'\n');
    for(int i=1,x,y;i<=m;i++) {
        x = _(n) , y = _(n);
        if( ! ( rand() & 3 ) ) x = y;
        if( x > y ) swap(x,y);
        printf("%d %d\n",x,y);
    }
    return 0;
}
