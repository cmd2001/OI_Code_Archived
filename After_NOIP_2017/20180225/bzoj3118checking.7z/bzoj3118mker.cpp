#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10000) {
    return rand() % r + 1;
}
struct Edge {
    int u,v,w,t,a,b;
};
vector<Edge> es;


int main() {
    srand((unsigned long long)new char);
    static int n = 200 , m = 1000;
    for(int i=2;i<=n;i++) es.push_back((Edge){i,_(i-1),_(),1,_(),_()});
    for(int i=n,x,y;i<=m;i++) {
        x = _(n) , y = _(n);
        if( x == y ) x = _(n) , y = _(n);
        es.push_back((Edge){x,y,_(),0,_(),_()});
    }
    /*for(int i=2;i<=n;i++) es.push_back((Edge){i,i-1,_(),1,_(),_()});
    for(int i=n,x,y;i<=m;i++) {
        x = 1 , y = n;
        es.push_back((Edge){x,y,_(),0,_(),_()});
    }*/
    random_shuffle(es.begin(),es.end());
    printf("%d %d\n",n,m);
    for(int i=0;i<m;i++) printf("%d %d %d %d %d %d\n",es[i].u,es[i].v,es[i].w,es[i].t,es[i].a,es[i].b);
    return 0;
}
