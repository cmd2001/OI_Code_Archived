#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<queue>
#define mp(x,y) make_pair(x,y)
using namespace std;

typedef pair<int,int> pa;

const int N=705;
const double pi=acos(-1);
const int inf=1000000000;

int n,m,L,rev[N*N*3],dx[4]={0,1,0,-1},dy[4]={1,0,-1,0};
bool vis[N][N];
char ma[N][N];
queue<pa> que;
struct com
{
    double x,y;
    com operator + (const com &d) const {return (com){x+d.x,y+d.y};}
    com operator - (const com &d) const {return (com){x-d.x,y-d.y};}
    com operator * (const com &d) const {return (com){x*d.x-y*d.y,x*d.y+y*d.x};}
    com operator / (const double &d) const {return (com){x/d,y/d};}
}a[N*N*3],b[N*N*3];

void fft(com *a,int f)
{
    for (int i=0;i<L;i++) if (i<rev[i]) swap(a[i],a[rev[i]]);
    for (int i=1;i<L;i<<=1)
    {
        com wn=(com){cos(pi/i),f*sin(pi/i)};
        for (int j=0;j<L;j+=(i<<1))
        {
            com w=(com){1,0};
            for (int k=0;k<i;k++)
            {
                com u=a[j+k],v=a[j+k+i]*w;
                a[j+k]=u+v;a[j+k+i]=u-v;
                w=w*wn;
            }
        }
    }
    if (f==-1) for (int i=0;i<L;i++) a[i]=a[i]/L;
}

void bfs(int sx,int sy)
{
    que.push(mp(sx,sy));
    vis[sx][sy]=0;
    while (!que.empty())
    {
        int x=que.front().first,y=que.front().second;
        a[(x-1)*m+y-1]=(com){1,0};
        que.pop();
        for (int i=0;i<4;i++)
        {
            int p=x+dx[i],q=y+dy[i];
            if (vis[p][q]) vis[p][q]=0,que.push(mp(p,q));
        }
    }
}

int main()
{
    scanf("%d%d",&n,&m);
    for (int i=1;i<=n;i++) scanf("%s",ma[i]+1);
    int x1=inf,y1=inf,x2=0,y2=0;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++)
            if (ma[i][j]=='o') x1=min(x1,i),y1=min(y1,j),x2=max(x2,i),y2=max(y2,j);
            else if (ma[i][j]=='#') a[n*m-(i-1)*m-j]=(com){1,0};
    if( x1 == inf || x2 == inf ) return puts("0"),0;
    for (int i=1;i<=n;i++)
        for (int j=1;j<=m;j++)
            if (ma[i][j]=='o') b[(i-x1)*m+j-y1]=(com){1,0};
    int lg=0;
    for (L=1;L<=n*m*2;L<<=1,lg++);
    for (int i=0;i<L;i++) rev[i]=(rev[i>>1]>>1)|((i&1)<<(lg-1));
    fft(a,1);fft(b,1);
    for (int i=0;i<L;i++) a[i]=a[i]*b[i];
    fft(a,-1);
    for (int i=1;i<=n-(x2-x1);i++)
        for (int j=1;j<=m-(y2-y1);j++)
            if ((int)(a[n*m-(i-1)*m-j].x+0.1)==0) vis[i][j]=1;
    for (int i=0;i<L;i++) a[i]=(com){0,0};
    bfs(x1,y1);
    fft(a,1);
    for (int i=0;i<L;i++) a[i]=a[i]*b[i];
    fft(a,-1);
    int ans=0;
    for (int i=0;i<n*m;i++) if ((int)(a[i].x+0.1)>0) ans++;
    printf("%d\n",ans);
    return 0;
}