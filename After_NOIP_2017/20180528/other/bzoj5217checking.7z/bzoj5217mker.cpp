#include<bits/stdc++.h>
using namespace std;

inline int _(int r) {
    return rand() % r + 1;
}
int main() {
    srand((unsigned long long)new char);
    static int n = 700 , m = 700;
    printf("%d %d\n",n,m);
    for(int i=1;i<=n;i++) {
        for(int j=1;j<=m;j++) {
            int t = _(8);
            /*if( t <= 1 ) putchar('#');
            else*/ if ( t == 3 ) putchar('o');
            else putchar('.');
        }
        puts("");
    }
    return 0;
}