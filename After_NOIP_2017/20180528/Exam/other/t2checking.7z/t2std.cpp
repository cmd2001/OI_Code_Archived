#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define debug cout
typedef long long int lli;
using namespace std;
const int maxn=3e5+1e2;

struct Node {
    lli val,siz;
    friend Node operator + (const Node &a,const Node &b) {
        return (Node){a.val+b.val,a.siz+b.siz};
    }
    friend Node operator - (const Node &a,const Node &b) {
        return (Node){a.val-b.val,a.siz-b.siz};
    }
    friend bool operator < (const Node &a,const Node &b) {
        return a.val != b.val ? a.val < b.val : a.siz < b.siz;
    }
}f[maxn][2],per;

int s[maxn],t[maxn<<1],nxt[maxn<<1],l[maxn<<1],cnt;
int n,k,c;
lli sum;

inline void addedge(int from,int to,int len) {
    t[++cnt] = to , l[cnt] = len ,
    nxt[cnt] = s[from] , s[from] = cnt;
}

inline void dfs(int pos,int fa) {
    f[pos][0] = (Node){0,0} , f[pos][1] = per; // only access point pos by car .
    for(int at=s[pos];at;at=nxt[at]) if( t[at] != fa ) {
        dfs(t[at],pos);
        const Node w = (Node){l[at],0};
        const Node tp0 = std::min( f[pos][1] + f[t[at]][1] - per , f[pos][0] + f[t[at]][0] + w );
        // access t[at] and other sons by car and walk back , access t[at] and other sons on foot and walk back .
        const Node tp1 = std::min( f[pos][1] + f[t[at]][0] + w , f[pos][0] + f[t[at]][1] );
        // access other t[at] on foot first and access other sons by car , access other sons on foot first and access t[at] by car .
        f[pos][0] = std::min( tp0 , tp1 ) , f[pos][1] = std::min( tp0 + per , tp1 );
    }
}

inline Node calc(lli cost) {
    per = (Node){cost,1};
    dfs(1,-1);
    return f[1][0];
}
inline void bin() {
    Node now;
    if( ( now = calc(c) ).siz <= k ) return void(printf("%lld\n",sum+now.val));
    lli ll = 0 , rr = 1e12 , mid;
    while( rr > ll + 1 ) {
        mid = ( ll + rr ) >> 1;
        if( ( now = calc(mid) ).siz <= k ) rr = mid;
        else ll = mid;
    }
    now = calc(rr);
    printf("%lld\n",sum+now.val-k*(rr-c));
}


int main() {
    scanf("%d%d%d",&n,&k,&c);
    for(int i=1,a,b,l;i<n;i++) {
        scanf("%d%d%d",&a,&b,&l) , sum += l;
        addedge(a,b,l) , addedge(b,a,l);
    }
    bin();
    return 0;
}
