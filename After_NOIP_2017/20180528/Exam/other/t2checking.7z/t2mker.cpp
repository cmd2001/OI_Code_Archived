#include<bits/stdc++.h>
using namespace std;

inline int _(int r=1e5) {
    return rand() % r;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 3e5;
    printf("%d %d %d\n",n,_(n),_(1e3));
    for(int i=2;i<=n;i++) printf("%d %d %d\n",i,_(i-1)+1,_());
    return 0;
}
