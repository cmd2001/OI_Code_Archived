#include<bits/stdc++.h>
using namespace std;

inline int _(int r=32768) {
    return rand() % r + 1;
}
inline void makeseq(int n) {
    for(int i=1;i<=n;i++) printf("%d%c",_(),i!=n?' ':'\n');
}

int main() {
    srand((unsigned long long)new char);
    static int n = 1000;
    printf("%d\n",n);
    makeseq(n) , makeseq(n);
    return 0;
}