#include<bits/stdc++.h>
#define debug cout
typedef long long int lli;
using namespace std;
const int maxn=1e5+1e2;
const lli mul = 2e13;

lli ina[maxn],inb[maxn],f[maxn],add,ans,sel,lst;
lli stk[maxn],cst[maxn],id[maxn];
int n,top;

int main() {
    freopen("dat.wa3.txt","r",stdin);
    scanf("%d",&n) , add = (lli) n * ( n + 1 ) >> 1;
    for(int i=1;i<=n;i++) scanf("%lld",ina+i) , ina[i] -= i;
    for(int i=1;i<=n;i++) {
        scanf("%lld",inb+i);
        if( ina[i] >= 0 ) {
            stk[++top] = ina[i] , cst[top] = mul - inb[i] , id[top] = i;
        }
    }
    for(int i=1;i<=top;i++) {
        for(int j=0;j<i;j++)
            if( stk[j] <= stk[i] ) {
                //if( i == 6 ) debug<<"query = "<<f[j] + stk[j] * ( n - id[i] + 1 )<<endl;
                f[i] = max( f[i] , f[j] + stk[j] * ( n - id[i] + 1 ) );
            }
        f[i] += cst[i] - stk[i] * ( n - id[i] + 1 ) , ans = max( ans , f[i] );
    }
    //for(int i=1;i<=n;i++) debug<<f[i]<<" "; debug<<endl;
    ans -= add;
    sel = ( ans + mul ) / mul;
    lst = mul * sel - ans;
    printf("%lld %lld\n",sel,lst);
    return 0;
}