#include<bits/stdc++.h>
using namespace std;

inline int _(int r=5) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 5 , m = 5;
    printf("%d %d\n",n,m);
    while(n--) printf("%d %d\n",_(),_());
    while(m--) {
        int x = _() , y = _() , xx = _() , yy = _();
        if( x > xx ) swap(x,xx);
        if( y > yy ) swap(y,yy);
        printf("%d %d %d %d\n",x,y,xx,yy);
    }
    return 0;
}