#include<bits/stdc++.h>
using namespace std;

inline int _(int r=32768) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 10;
    printf("%d\n",n);
    while(n--) printf("%d %d\n",_(5),_(5));
    return 0;
}
