#include<bits/stdc++.h>
using namespace std;

const int N = 1500 + 10;

typedef long long ll;

struct Point{
    ll x, y;
    Point(){};
    Point(ll a, ll b){x = a, y = b;}
    bool operator == (const Point &a) const{
        return a.x == x && a.y == y;
    }
    ll operator * (const Point &a) const{
        return x * a.y - y * a.x;
    }
    Point operator - (const Point &a) const{
        return Point(x - a.x, y - a.y);
    }
    Point operator + (const Point &a) const{
        return Point(x + a.x, y + a.y);
    }
    inline void print() const {
        printf("%lld %lld\n",x,y);
    }
}pt[N];
struct Line{
    ll len;
    Point p1, p2, mdp;
    bool operator < (const Line &a) const{
        if(len == a.len)
            return (mdp.x < a.mdp.x) || (mdp.x == a.mdp.x && mdp.y < a.mdp.y);
        else return len < a.len;
    }
}ln[N*N>>1];
int n, tot;

ll sqr(ll x){return x * x;}
ll dist(Point a, Point b){
    return sqr(a.x - b.x) + sqr(a.y - b.y);
}
ll labs(ll x){return x > 0 ? x : -x;}

void init(){
    scanf("%d", &n);
    for(int i = 1; i <= n; i++){
        scanf("%lld%lld", &pt[i].x, &pt[i].y);
        for(int j = 1; j < i; j++){
            ln[++tot].p1 = pt[i];
            ln[tot].p2 = pt[j];
            ln[tot].len = dist(pt[i], pt[j]);
            ln[tot].mdp = pt[i] + pt[j];
        }
    }
}

void work(){
    ll ans = 0, s;
    sort(ln+1, ln+tot+1);
    for(int i = 1; i <= tot; i++)
    for(int j = i-1; ln[i].mdp == ln[j].mdp && ln[i].len == ln[j].len && j; j--){
        //cout << "in a group"<<endl;
        //ln[j].p1.print() , ln[j].p2.print() , ln[i].p1.print() , ln[i].p2.print();
        s = labs((ln[j].p1 - ln[i].p1) * (ln[j].p2 - ln[i].p1));
        //cout << " s = " << s << endl;
        if(s > ans) ans = s;
    }
    printf("%lld\n", ans);
}

int main(){
    init();
    work();
    return 0;
}
