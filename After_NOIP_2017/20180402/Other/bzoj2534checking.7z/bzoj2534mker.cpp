#include<bits/stdc++.h>
using namespace std;

inline int _(int r=26) {
    return rand() % r;
}
int main() {
    srand((unsigned long long )new char ^ time(0));
    static int n = 50000 , m = _(min(n/2,10))+1;
    printf("%d\n",m);
    while(n--) putchar('a'+_(3));
    puts("");
    return 0;
}