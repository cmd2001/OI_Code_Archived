#include<iostream>  
#include<cstdio>  
#include<cstring>  
#define N 50005  
#define M 1000005  
using namespace std;  
  
int n,m,cnt,trtot,fst[N],nxt[N],sa[N],rnk[N<<1],sum[N],q[N<<1],dad[N],rt[N],sz[M],ls[M],rs[M]; char s[N];  
void ins(int &k,int l,int r,int x){  
    k=++trtot; sz[k]=1;  
    if (l==r) return; int mid=l+r>>1;  
    if (x<=mid) ins(ls[k],l,mid,x); else ins(rs[k],mid+1,r,x);  
}  
void find(int k,int l,int r){  
    if (!k) return; if (l==r){ q[++cnt]=l; return; }  
    int mid=l+r>>1;  
    find(ls[k],l,mid); find(rs[k],mid+1,r);  
}  
int qry(int k,int l,int r,int x,int y){  
    if (!k) return 0; if (x<=l && r<=y) return sz[k];  
    int mid=l+r>>1,tmp=0;  
    if (x<=mid) tmp+=qry(ls[k],l,mid,x,y); if (y>mid) tmp+=qry(rs[k],mid+1,r,x,y);  
    return tmp;  
}  
int merge(int x,int y){  
    if (!x || !y) return x|y;  
    ls[x]=merge(ls[x],ls[y]); rs[x]=merge(rs[x],rs[y]);  
    sz[x]+=sz[y]; return x;  
}  
void getsa(){  
    int i,j,k;  
    for (i=1; i<=n; i++) sum[s[i]]++;  
    for (i=1; i<128; i++) sum[i]+=sum[i-1];  
    for (i=n; i; i--) sa[sum[s[i]]--]=i;  
    for (i=1; i<=n; rnk[sa[i++]]=cnt)  
        if (i==1 || s[sa[i]]!=s[sa[i-1]]) cnt++;  
    for (k=1; cnt<n; k<<=1){  
        for (i=1; i<=k; i++) q[i]=n-k+i;  
        for (i=1,j=k; i<=n; i++) if (sa[i]>k) q[++j]=sa[i]-k;  
        memset(sum,0,sizeof(sum));  
        for (i=1; i<=n; i++) sum[rnk[i]]++;  
        for (i=2; i<=cnt; i++) sum[i]+=sum[i-1];  
        for (i=n; i; i--) sa[sum[rnk[q[i]]]--]=q[i];  
        for (i=1,cnt=0; i<=n; q[sa[i++]]=cnt)  
            if (i==1 || rnk[sa[i]]!=rnk[sa[i-1]] || rnk[sa[i]+k]!=rnk[sa[i-1]+k]) cnt++;  
        swap(q,rnk);  
    }  
}  
void gethgt(){  
    int i,j,k=0;  
    for (i=1; i<=n; i++){  
        if (k) k--; j=sa[rnk[i]-1];  
        while (i+k<=n && j+k<=n && s[i+k]==s[j+k]) k++;  
        if (rnk[i]>1){ nxt[i]=fst[k]; fst[k]=i; }  
    }  
}  
int getdad(int x){ return (x==dad[x])?x:dad[x]=getdad(dad[x]); }  
int solve(int x,int l,int r){  
    l=max(l,1); r=min(r,n); return (l<=r)?qry(rt[x],1,n,l,r):0;  
}  
int main(){  
    scanf("%d%s",&m,s+1); n=strlen(s+1);  
    getsa(); gethgt();  
    int i,j,k,x,y,ans=0;  
    for (i=1; i<=n; i++) dad[i]=i;  
    for (i=1; i<=n; i++) ins(rt[i],1,n,i);  
    for (i=n-1; i; i--)  
        for (j=fst[i]; j; j=nxt[j]){  
            x=getdad(j); y=getdad(sa[rnk[j]-1]);  
            if (sz[rt[x]]>sz[rt[y]]) swap(x,y);  
            cnt=0; find(rt[x],1,n);  
            for (k=1; k<=cnt; k++)  
                ans+=solve(y,q[k]+m+1,q[k]+m+i)+solve(y,q[k]-m-i,q[k]-m-1);  
            dad[x]=y; rt[y]=merge(rt[y],rt[x]);  
        }  
    printf("%d\n",ans);  
    return 0;  
}  