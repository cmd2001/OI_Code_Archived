#include<bits/stdc++.h>
using namespace std;

inline int _(int r=10) {
    return rand() % r + 1;
}

int main() {
    srand((unsigned long long)new char);
    static int n = 50;
    printf("%d %d\n",n,_(n*n>>1));
    while(n--) printf("%d %d\n",_(),_());
    return 0;
}
