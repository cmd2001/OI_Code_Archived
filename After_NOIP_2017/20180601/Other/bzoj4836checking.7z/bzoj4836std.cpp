#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define mem(a) memset(a,0,sizeof(a))
typedef long long ll;
using namespace std;

const int N=500010;
const double pi=acos(-1.);
struct C{ double x,y; }A[N],B[N];
int a[N],b[N],rev[N],n,T,x,m,Q,mx,len1,len2;
ll ans[N];

C operator +(C &a,C &b){ return (C){a.x+b.x,a.y+b.y}; }
C operator -(C &a,C &b){ return (C){a.x-b.x,a.y-b.y}; }
C operator *(const C &a,const C &b){ return (C){a.x*b.x-a.y*b.y,a.x*b.y+a.y*b.x}; }

void DFT(C a[],int n,int f){
    for (int i=0; i<n; i++) if (i<rev[i]) swap(a[i],a[rev[i]]);
    for (int i=1; i<n; i<<=1){
        C wn=(C){cos(pi/i),f*sin(pi/i)};
        for (int p=i<<1,j=0; j<n; j+=p){
            C w=(C){1,0};
            for (int k=0; k<i; k++,w=w*wn){
                C x=a[j+k],y=w*a[i+j+k]; a[j+k]=x+y; a[i+j+k]=x-y;
            }
        }
    }
    if (f==1) return;
    for (int i=0; i<n; i++) a[i].x/=n;
}

void CDQ(int l,int r){
    if (l==r) return;
    int mid=(l+r)>>1,n,L=0;
    for (n=1; n<=r-l+1; n<<=1) L++;
    for (int i=0; i<n; i++) rev[i]=(rev[i>>1]>>1)|((i&1)<<(L-1));
    
    for (int i=0; i<n; i++) A[i]=B[i]=(C){0,0};
    for (int i=l; i<=mid; i++) A[i-l].x=a[i];
    for (int i=mid+1; i<=r; i++) B[i-mid-1].x=b[i];
    DFT(A,n,1); DFT(B,n,1);
    for (int i=0; i<n; i++) A[i]=A[i]*B[i];
    DFT(A,n,-1);
    for (int i=0; i<n; i++) ans[i+mid+1+l]+=(ll)(A[i].x+0.5);
    
    for (int i=0; i<n; i++) A[i]=B[i]=(C){0,0};
    for (int i=mid+1; i<=r; i++) A[i-mid-1].x=a[i];
    for (int i=l; i<=mid; i++) B[mid-i].x=b[i];
    DFT(A,n,1); DFT(B,n,1);
    for (int i=0; i<n; i++) A[i]=A[i]*B[i];
    DFT(A,n,-1);
    for (int i=0; i<n; i++) ans[i+1]+=(ll)(A[i].x+0.5);
    CDQ(l,mid); CDQ(mid+1,r);
}

int main(){
    for (scanf("%d",&T); T--; ){
        scanf("%d%d%d",&n,&m,&Q); mem(ans); mem(a); mem(b); len1=len2=0;
        for (int i=1; i<=n; i++) scanf("%d",&x),a[x]++,len1=max(len1,x);
        for (int i=1; i<=m; i++) scanf("%d",&x),b[x]++,len2=max(len2,x);
        for (int i=1; i<=len1 && i<=len2; i++) ans[0]+=1ll*a[i]*b[i];
        CDQ(0,max(len1,len2));
        for (int i=1; i<=Q; i++) scanf("%d",&x),printf("%lld\n",ans[x]);
    }
    return 0;
}