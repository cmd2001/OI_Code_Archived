#include<bits/stdc++.h>
using namespace std;

inline int _(int r=5e4) {
    return rand() % r + 1;
}

int main() {
    static int T = 1;
    srand((unsigned long long)new char) , printf("%d\n",T);
    while(T--) {
        int n = 5e4 , m = 5e4 , q = 5e4;
        printf("%d %d %d\n",n,m,q);
        for(int i=1;i<=n;i++) printf("%d%c",1,i!=n?' ':'\n');
        for(int i=1;i<=m;i++) printf("%d%c",2,i!=m?' ':'\n');
        for(int i=1;i<=q;i++) printf("%d%c",_(1e5),i!=q?' ':'\n');
    }
    return 0;
}