#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+1e2;

int ran[maxn];
vector<int> dat[maxn];

int main() {
    static int n = 10000;
    for(int i=1;i<=n;i++) ran[i] = rand() % 9 + 1;
    for(int i=1;i<=n;i++) {
        for(int j=i;j<=n;j++) dat[i].push_back(ran[j]);
        for(int j=1;j<i;j++) dat[i].push_back(ran[j]);
    }
    sort(dat+1,dat+1+n);
    printf("%d 9\n",n);
    for(int i=1;i<=n;i++) printf("%d%c",*dat[i].rbegin(),i!=n?' ':'\n');
    return 0;
}