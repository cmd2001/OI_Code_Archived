#include<cstdio>  
#include<cstring>  
#include<cstdlib>  
#include<cmath>  
#include<iostream>  
#include<algorithm>  
#define maxn 200010  
    
using namespace std;  
    
pair<int,int> a[maxn];  
int n,m;  
    
int main()  
{  
    scanf("%d%d",&n,&m);  
    for (int i=0;i<=n;i++)  
    {  
        scanf("%d",&a[i].first);  
        a[i].second=i;  
    }  
    sort(a,a+n+1);  
    int t=a[0].second;  
    for (int i=1;i<=n;i++)  
    {  
        printf("%d ",a[t].first);  
        t=a[t].second;  
    }  
    putchar('\n');
    return 0;  
}  