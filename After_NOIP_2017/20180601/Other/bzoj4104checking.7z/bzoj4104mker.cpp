#include<bits/stdc++.h>
using namespace std;
const int maxn=1e4+1e2;

int ran[maxn];
vector<int> dat[maxn];

int main() {
    srand((unsigned long long)new char);
    static int n = 2e3;
    for(int i=1;i<=n;i++) ran[i] = rand() % 3 + 1;
    ran[++n] = 0;
    for(int i=1;i<=n;i++) {
        for(int j=i;j<=n;j++) dat[i].push_back(ran[j]);
        for(int j=1;j<i;j++) dat[i].push_back(ran[j]);
    }
    sort(dat+1,dat+1+n);
    printf("%d 3\n",n-1);
    for(int i=1;i<=n;i++) printf("%d%c",*dat[i].rbegin(),i!=n?' ':'\n');
    return 0;
}
